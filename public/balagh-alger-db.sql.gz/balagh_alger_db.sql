/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: balagh_alger
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-6 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `model` varchar(100) NOT NULL,
  `model_id` bigint(20) unsigned DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_action` (`action`),
  KEY `idx_model` (`model`,`model_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1863 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 14:07:21'),
(2,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:12:50'),
(3,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:12:51'),
(4,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:12:51'),
(5,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:12:59'),
(6,NULL,'register','User',6,NULL,NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-15 14:14:29'),
(7,6,'login','User',6,NULL,NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-15 14:14:49'),
(8,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 14:37:17'),
(9,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:37:56'),
(10,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 14:39:23'),
(11,6,'login','User',6,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:43:16'),
(12,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 14:49:19'),
(13,6,'logout','User',6,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:52:36'),
(14,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 14:57:33'),
(15,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 14:58:24'),
(16,6,'login','User',6,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 14:59:56'),
(17,6,'logout','User',6,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 15:00:12'),
(18,NULL,'register','User',7,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 15:00:40'),
(19,7,'login','User',7,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 15:00:46'),
(20,NULL,'register','User',8,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-15 15:00:53'),
(21,8,'login','User',8,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-15 15:01:11'),
(22,7,'logout','User',7,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 15:04:48'),
(23,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-15 15:04:58'),
(24,8,'logout','User',8,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-15 15:05:31'),
(25,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-15 15:05:50'),
(26,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-15 15:06:21'),
(27,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 15:09:09'),
(28,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-15 15:09:36'),
(29,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-dz.dz\"}',NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-15 16:29:12'),
(30,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-dz.com\"}',NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-15 16:48:11'),
(31,6,'login','User',6,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-15 16:50:05'),
(32,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-15 18:44:29'),
(33,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-16 07:04:29'),
(34,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-16 07:23:55'),
(35,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-16 07:25:08'),
(36,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-16 07:26:19'),
(37,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 08:35:40'),
(38,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 08:38:58'),
(39,NULL,'register','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 08:40:43'),
(40,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 08:41:00'),
(41,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 08:44:10'),
(42,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 08:44:44'),
(43,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 08:50:02'),
(44,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 08:50:05'),
(45,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 08:58:12'),
(46,NULL,'login_failed','User',NULL,'{\"email\":\"usaplay1406@gmail.com\"}',NULL,'::1','curl/8.20.0','2026-07-16 08:58:13'),
(47,6,'login','User',6,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:06:47'),
(48,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:09:50'),
(49,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:10:04'),
(50,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:11:26'),
(51,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:13:26'),
(52,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:26:18'),
(53,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:32:36'),
(54,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:34:08'),
(55,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:34:49'),
(56,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:40:13'),
(57,11,'login','User',11,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:40:26'),
(58,11,'login','User',11,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:41:08'),
(59,12,'login','User',12,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:41:23'),
(60,13,'login','User',13,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:41:36'),
(61,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:45:17'),
(62,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:45:32'),
(63,1,'close','Report',7,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:45:32'),
(64,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:46:32'),
(65,1,'update','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:48:38'),
(66,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:50:22'),
(67,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:50:30'),
(68,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:50:56'),
(69,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:51:03'),
(70,1,'status_change','Report',7,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:51:24'),
(71,1,'status_change','Report',7,NULL,'{\"status\":\"submitted\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:51:38'),
(72,1,'status_change','Report',7,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:51:47'),
(73,1,'create','Report',8,NULL,'{\"tracking_code\":\"BA-2026-681739\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:54:21'),
(74,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:54:27'),
(75,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:54:37'),
(76,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:54:54'),
(77,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:55:00'),
(78,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:56:02'),
(79,NULL,'login_failed','User',NULL,'{\"email\":\"resp.asrouter@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:56:06'),
(80,NULL,'login_failed','User',NULL,'{\"email\":\"resp.asrouter@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:56:17'),
(81,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:56:24'),
(82,1,'update','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:56:35'),
(83,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:56:37'),
(84,NULL,'login_failed','User',NULL,'{\"email\":\"resp.asrouter@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:56:55'),
(85,NULL,'login_failed','User',NULL,'{\"email\":\"resp.asrouter@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:57:05'),
(86,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:57:11'),
(87,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:57:33'),
(88,1,'assign','Report',8,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:58:20'),
(89,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:58:24'),
(90,NULL,'login_failed','User',NULL,'{\"email\":\"test@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:58:31'),
(91,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:58:40'),
(92,9,'status_change','Report',8,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:59:02'),
(93,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 09:59:09'),
(94,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:59:30'),
(95,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 09:59:33'),
(96,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:01:06'),
(97,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 10:03:19'),
(98,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 10:23:51'),
(99,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:25:58'),
(100,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:34:02'),
(101,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:34:12'),
(102,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:34:31'),
(103,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:34:34'),
(104,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:39:46'),
(105,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:39:58'),
(106,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:40:28'),
(107,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:40:32'),
(108,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:40:45'),
(109,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:40:58'),
(110,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:41:55'),
(111,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:42:02'),
(112,1,'create','Report',9,NULL,'{\"tracking_code\":\"BA-2026-727751\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:43:03'),
(113,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:52:54'),
(114,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:53:25'),
(115,1,'status_change','Report',7,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:56:02'),
(116,1,'assign','Report',7,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 10:56:04'),
(117,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:06:18'),
(118,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 11:07:57'),
(119,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 11:09:09'),
(120,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 11:09:47'),
(121,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:10:19'),
(122,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:12:03'),
(123,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:12:32'),
(124,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-16 11:15:35'),
(125,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:15:41'),
(126,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:15:45'),
(127,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:16:45'),
(128,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:16:54'),
(129,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:17:15'),
(130,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:17:17'),
(131,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:19:24'),
(132,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:22:27'),
(133,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:23:00'),
(134,1,'create','Report',16,NULL,'{\"tracking_code\":\"BA-2026-653539\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:26:59'),
(135,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:27:29'),
(136,NULL,'login_failed','User',NULL,'{\"email\":\"resp.asrouter@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:27:35'),
(137,NULL,'login_failed','User',NULL,'{\"email\":\"resp.asrouter@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:27:43'),
(138,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:27:50'),
(139,10,'assign','Report',16,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:28:21'),
(140,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:29:41'),
(141,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:29:48'),
(142,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:30:26'),
(143,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:30:31'),
(144,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:30:56'),
(145,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:31:07'),
(146,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:32:17'),
(147,12,'login','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:32:27'),
(148,12,'logout','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:33:09'),
(149,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:33:12'),
(150,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:33:26'),
(151,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:33:33'),
(152,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:37:14'),
(153,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:37:55'),
(154,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 11:38:03'),
(155,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:47:20'),
(156,NULL,'register','User',43,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:49:30'),
(157,43,'login','User',43,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:49:48'),
(158,43,'create','Report',17,NULL,'{\"tracking_code\":\"BA-2026-358666\",\"organization_id\":8}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 11:50:38'),
(159,NULL,'login_failed','User',NULL,'{\"email\":\"adminbalagh_alger@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-16 12:00:04'),
(160,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-16 12:06:10'),
(161,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-07-16 14:19:45'),
(162,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-16 14:38:26'),
(163,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:28:19'),
(164,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:30:51'),
(165,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:31:09'),
(166,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:31:34'),
(167,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:31:36'),
(168,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:32:06'),
(169,12,'login','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:32:17'),
(170,12,'logout','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:33:24'),
(171,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:33:28'),
(172,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:33:43'),
(173,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:33:50'),
(174,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:34:17'),
(175,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:34:19'),
(176,1,'update','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:34:50'),
(177,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:34:55'),
(178,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:35:05'),
(179,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:35:39'),
(180,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:35:41'),
(181,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:50:22'),
(182,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:50:58'),
(183,NULL,'login_failed','User',NULL,'{\"email\":\"yacine.bensalem@gmail.com\"}',NULL,'::1','curl/8.20.0','2026-07-19 09:50:58'),
(184,NULL,'login_failed','User',NULL,'{\"email\":\"usaplay1406@gmail.com\"}',NULL,'::1','curl/8.20.0','2026-07-19 09:52:28'),
(185,NULL,'login_failed','User',NULL,'{\"email\":\"karim@balagh-alger.dz\"}',NULL,'::1','curl/8.20.0','2026-07-19 09:52:29'),
(186,NULL,'login_failed','User',NULL,'{\"email\":\"usaplay1406@gmail.com\"}',NULL,'::1','curl/8.20.0','2026-07-19 09:52:39'),
(187,6,'login','User',6,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:53:54'),
(188,4,'login','User',4,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:53:54'),
(189,2,'login','User',2,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:53:55'),
(190,3,'login','User',3,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:53:55'),
(191,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:53:56'),
(192,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:53:56'),
(193,6,'login','User',6,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:55:23'),
(194,4,'login','User',4,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:55:24'),
(195,3,'login','User',3,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:55:24'),
(196,2,'login','User',2,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:55:25'),
(197,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:55:25'),
(198,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:55:26'),
(199,6,'login','User',6,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:56:05'),
(200,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:56:45'),
(201,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-19 09:57:39'),
(202,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:58:56'),
(203,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:58:58'),
(204,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:59:04'),
(205,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:59:16'),
(206,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:59:24'),
(207,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:59:45'),
(208,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:59:47'),
(209,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 09:59:57'),
(210,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:00:00'),
(211,11,'assign','Report',16,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:01:47'),
(212,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:01:53'),
(213,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:01:56'),
(214,1,'status_change','Report',17,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:02:27'),
(215,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:03:12'),
(216,2,'login','User',2,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:04:57'),
(217,2,'login','User',2,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:05:17'),
(218,2,'login','User',2,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:05:39'),
(219,2,'login','User',2,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:06:16'),
(220,2,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":3,\"commune_id\":1}','::1','curl/8.20.0','2026-07-19 10:06:16'),
(221,2,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":3,\"commune_id\":2}','::1','curl/8.20.0','2026-07-19 10:06:16'),
(222,2,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":12,\"commune_id\":3}','::1','curl/8.20.0','2026-07-19 10:06:16'),
(223,2,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":12,\"commune_id\":4}','::1','curl/8.20.0','2026-07-19 10:06:16'),
(224,2,'remove_commune','SectionCommune',NULL,'{\"user_id\":12,\"commune_id\":3}',NULL,'::1','curl/8.20.0','2026-07-19 10:06:27'),
(225,3,'login','User',3,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:06:49'),
(226,6,'login','User',6,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:06:49'),
(227,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:07:56'),
(228,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:08:18'),
(229,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:08:22'),
(230,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:08:46'),
(231,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:08:48'),
(232,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:08:57'),
(233,12,'login','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:09:00'),
(234,12,'logout','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:09:19'),
(235,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:10:28'),
(236,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:10:48'),
(237,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:10:51'),
(238,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:11:54'),
(239,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:11:56'),
(240,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:12:10'),
(241,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:12:13'),
(242,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:13:39'),
(243,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:13:41'),
(244,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:13:43'),
(245,NULL,'register','User',44,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:14:28'),
(246,44,'login','User',44,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:14:35'),
(247,44,'create','Report',18,NULL,'{\"tracking_code\":\"BA-2026-457733\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:16:01'),
(248,44,'logout','User',44,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:18:15'),
(249,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:18:21'),
(250,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:19:55'),
(251,44,'login','User',44,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:19:59'),
(252,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:20:07'),
(253,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:21:05'),
(254,44,'login','User',44,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:21:10'),
(255,44,'login','User',44,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:21:36'),
(256,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@balagh-alger.dz\"}',NULL,'::1','curl/8.20.0','2026-07-19 10:22:02'),
(257,44,'login','User',44,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:22:32'),
(258,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:22:39'),
(259,45,'login','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:23:31'),
(260,45,'login','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:24:38'),
(261,45,'create','Report',19,NULL,'{\"tracking_code\":\"BA-2026-128338\",\"organization_id\":2}','::1','curl/8.20.0','2026-07-19 10:26:09'),
(262,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','curl/8.20.0','2026-07-19 10:26:57'),
(263,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','curl/8.20.0','2026-07-19 10:27:05'),
(264,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','curl/8.20.0','2026-07-19 10:27:12'),
(265,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','curl/8.20.0','2026-07-19 10:27:32'),
(266,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:28:00'),
(267,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:28:45'),
(268,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:28:50'),
(269,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:28:57'),
(270,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:29:10'),
(271,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:29:20'),
(272,45,'create','Report',20,NULL,'{\"tracking_code\":\"BA-2026-020224\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:31:11'),
(273,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:31:21'),
(274,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:31:38'),
(275,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:31:40'),
(276,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:32:38'),
(277,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:32:46'),
(278,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:33:08'),
(279,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:33:10'),
(280,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:33:26'),
(281,NULL,'login_failed','User',NULL,'{\"email\":\"fatima@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:33:29'),
(282,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:33:38'),
(283,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:34:15'),
(284,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:34:17'),
(285,1,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":16,\"commune_id\":32}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:34:53'),
(286,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:36:35'),
(287,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:36:42'),
(288,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:36:58'),
(289,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:37:01'),
(290,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:37:47'),
(291,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:37:52'),
(292,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:38:07'),
(293,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:38:37'),
(294,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:40:21'),
(295,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:40:24'),
(296,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:40:28'),
(297,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:40:36'),
(298,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 10:41:35'),
(299,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:42:47'),
(300,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:42:56'),
(301,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:47:02'),
(302,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:47:11'),
(303,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:50:29'),
(304,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:50:31'),
(305,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:55:21'),
(306,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:55:32'),
(307,1,'status_change','Report',20,NULL,'{\"status\":\"acknowledged\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:57:47'),
(308,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 10:58:37'),
(309,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:00:45'),
(310,1,'update','Category',6,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:07:17'),
(311,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:34:31'),
(312,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:36:13'),
(313,45,'create','Report',21,NULL,'{\"tracking_code\":\"BA-2026-230859\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:38:43'),
(314,45,'create','Report',22,NULL,'{\"tracking_code\":\"BA-2026-660064\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:38:44'),
(315,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:40:19'),
(316,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:40:28'),
(317,1,'assign','Report',22,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:41:24'),
(318,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:48:57'),
(319,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:49:03'),
(320,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:49:12'),
(321,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:49:15'),
(322,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:49:24'),
(323,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:49:29'),
(324,11,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":12,\"commune_id\":3}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:51:54'),
(325,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:53:45'),
(326,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:53:48'),
(327,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:56:57'),
(328,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:58:15'),
(329,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-19 11:58:57'),
(330,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-19 11:59:16'),
(331,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 11:59:57'),
(332,12,'login','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:00:03'),
(333,12,'logout','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:00:12'),
(334,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:00:17'),
(335,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:00:25'),
(336,13,'login','User',13,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:00:32'),
(337,13,'logout','User',13,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:01:06'),
(338,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:01:12'),
(339,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:01:32'),
(340,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:01:41'),
(341,9,'status_change','Report',8,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:01:52'),
(342,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:02:02'),
(343,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:02:05'),
(344,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:08:18'),
(345,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:08:29'),
(346,11,'status_change','Report',22,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:08:49'),
(347,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:09:17'),
(348,12,'login','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:09:23'),
(349,12,'logout','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:10:07'),
(350,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:10:14'),
(351,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:11:24'),
(352,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:11:33'),
(353,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:12:16'),
(354,NULL,'login_failed','User',NULL,'{\"email\":\"test@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:12:19'),
(355,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:12:28'),
(356,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:12:40'),
(357,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:12:42'),
(358,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:13:11'),
(359,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:13:13'),
(360,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:13:26'),
(361,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:13:32'),
(362,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:13:59'),
(363,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:14:02'),
(364,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:14:44'),
(365,12,'login','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:14:52'),
(366,12,'logout','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:15:05'),
(367,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:15:08'),
(368,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:15:30'),
(369,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:15:36'),
(370,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:15:53'),
(371,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:15:58'),
(372,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:16:40'),
(373,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:16:50'),
(374,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:17:42'),
(375,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:17:47'),
(376,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:17:55'),
(377,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:18:11'),
(378,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:18:13'),
(379,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:18:27'),
(380,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:18:29'),
(381,1,'status_change','Report',22,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:18:57'),
(382,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:19:14'),
(383,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:19:20'),
(384,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:19:33'),
(385,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:19:42'),
(386,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:20:11'),
(387,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:20:23'),
(388,1,'close','Report',22,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:20:39'),
(389,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:20:44'),
(390,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:20:56'),
(391,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:21:31'),
(392,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:21:35'),
(393,1,'status_change','Report',21,NULL,'{\"status\":\"rejected\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 12:22:14'),
(394,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:20:39'),
(395,1,'assign','Report',21,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:33:45'),
(396,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:33:55'),
(397,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:34:06'),
(398,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:35:51'),
(399,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:35:57'),
(400,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 14:46:21'),
(401,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 14:47:02'),
(402,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 14:48:38'),
(403,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 14:48:59'),
(404,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 14:52:16'),
(405,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 14:57:33'),
(406,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:59:51'),
(407,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 14:59:56'),
(408,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 15:00:50'),
(409,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 15:01:01'),
(410,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 15:07:12'),
(411,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 15:07:19'),
(412,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 15:07:55'),
(413,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-19 15:07:57'),
(414,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Android 13; Mobile; rv:152.0) Gecko/152.0 Firefox/152.0','2026-07-19 15:16:12'),
(415,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-19 15:20:31'),
(416,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 08:56:30'),
(417,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:03:45'),
(418,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:03:46'),
(419,NULL,'login_failed','User',NULL,'{\"email\":\"testtest@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-20 09:05:36'),
(420,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:12:16'),
(421,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:12:33'),
(422,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:12:38'),
(423,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:12:50'),
(424,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:13:02'),
(425,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:13:07'),
(426,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:13:20'),
(427,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:13:22'),
(428,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:13:36'),
(429,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:13:45'),
(430,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:15:02'),
(431,45,'login','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:15:08'),
(432,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:15:17'),
(433,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:15:19'),
(434,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:16:30'),
(435,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:16:44'),
(436,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:17:23'),
(437,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:17:27'),
(438,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:17:48'),
(439,1,'remove_commune','SectionCommune',NULL,'{\"user_id\":12,\"commune_id\":3}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:19:08'),
(440,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:19:16'),
(441,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:19:25'),
(442,1,'toggle','Category',1,'{\"is_active\":1}','{\"is_active\":0}','::1','curl/8.20.0','2026-07-20 09:21:08'),
(443,45,'create','Report',23,NULL,'{\"tracking_code\":\"BA-2026-474010\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:21:39'),
(444,45,'create','Report',24,NULL,'{\"tracking_code\":\"BA-2026-188245\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:21:41'),
(445,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:22:13'),
(446,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:22:26'),
(447,1,'status_change','Report',23,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:22:52'),
(448,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:23:19'),
(449,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:23:27'),
(450,10,'status_change','Report',24,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:23:46'),
(451,10,'assign','Report',24,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:23:52'),
(452,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:24:10'),
(453,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:24:25'),
(454,11,'assign','Report',24,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:24:50'),
(455,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:25:47'),
(456,5,'login','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:25:53'),
(457,5,'status_change','Report',24,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:26:06'),
(458,5,'logout','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:26:32'),
(459,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:26:34'),
(460,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:27:01'),
(461,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:27:10'),
(462,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:28:53'),
(463,12,'login','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:28:58'),
(464,12,'logout','User',12,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:29:35'),
(465,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:29:39'),
(466,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:32:28'),
(467,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:32:38'),
(468,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:34:30'),
(469,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:34:33'),
(470,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:35:04'),
(471,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:35:09'),
(472,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:35:27'),
(473,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:35:30'),
(474,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:35:48'),
(475,5,'login','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:35:54'),
(476,5,'status_change','Report',24,NULL,'{\"status\":\"closed\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:36:21'),
(477,5,'logout','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:36:36'),
(478,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:36:38'),
(479,NULL,'login_failed','User',NULL,'{\"email\":\"balagh_Alger16@gmail.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-20 09:36:40'),
(480,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:36:47'),
(481,10,'login','User',10,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:36:47'),
(482,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:36:54'),
(483,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:37:27'),
(484,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:37:30'),
(485,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:37:48'),
(486,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-20 09:38:40'),
(487,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-20 09:38:45'),
(488,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:39:15'),
(489,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:41:01'),
(490,5,'login','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:41:12'),
(491,5,'logout','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:41:23'),
(492,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:41:25'),
(493,1,'create','Category',24,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:43:08'),
(494,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:43:21'),
(495,1,'create','Category',25,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:43:21'),
(496,1,'create','User',46,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:44:34'),
(497,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:44:41'),
(498,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:44:48'),
(499,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:44:59'),
(500,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:45:02'),
(501,1,'update','User',46,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:45:14'),
(502,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:45:16'),
(503,1,'create','Category',26,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:45:16'),
(504,1,'toggle','Category',1,'{\"is_active\":0}','{\"is_active\":1}','::1','curl/8.20.0','2026-07-20 09:45:16'),
(505,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:45:18'),
(506,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:45:23'),
(507,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:45:27'),
(508,1,'update','User',46,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:45:52'),
(509,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:45:55'),
(510,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:46:01'),
(511,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:46:11'),
(512,1,'toggle','Category',24,'{\"is_active\":1}','{\"is_active\":0}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:46:15'),
(513,1,'toggle','Category',24,'{\"is_active\":0}','{\"is_active\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:46:17'),
(514,1,'update','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:48:07'),
(515,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:48:09'),
(516,9,'login','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:48:17'),
(517,9,'logout','User',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:48:48'),
(518,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:48:50'),
(519,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:49:18'),
(520,15,'login','User',15,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:49:26'),
(521,45,'update_profile','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:50:32'),
(522,15,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":16,\"commune_id\":28}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:50:34'),
(523,15,'logout','User',15,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:50:44'),
(524,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:50:48'),
(525,45,'update_profile','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:50:52'),
(526,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:50:58'),
(527,45,'update_profile','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:51:08'),
(528,45,'login','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:51:09'),
(529,45,'update_profile','User',45,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:51:09'),
(530,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:51:43'),
(531,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 09:51:45'),
(532,2,'login','User',2,NULL,NULL,'::1','curl/8.20.0','2026-07-20 09:57:13'),
(533,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:12:26'),
(534,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:12:35'),
(535,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:12:42'),
(536,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:16:22'),
(537,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:16:27'),
(538,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:20:49'),
(539,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:20:58'),
(540,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:23:37'),
(541,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:23:59'),
(542,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:24:02'),
(543,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:53:02'),
(544,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 11:53:57'),
(545,1,'create','Report',25,NULL,'{\"tracking_code\":\"BA-2026-193242\",\"organization_id\":1}','::1','curl/8.20.0','2026-07-20 11:54:47'),
(546,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:57:38'),
(547,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 11:57:48'),
(548,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-20 11:59:59'),
(549,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:00:46'),
(550,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:00:48'),
(551,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:07:58'),
(552,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:08:29'),
(553,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:08:52'),
(554,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:08:52'),
(555,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:09:13'),
(556,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:10:15'),
(557,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:10:52'),
(558,1,'create','Report',26,NULL,'{\"tracking_code\":\"BA-2026-285364\",\"organization_id\":1}','::1','curl/8.20.0','2026-07-20 12:11:00'),
(559,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:12:25'),
(560,1,'create','Report',27,NULL,'{\"tracking_code\":\"BA-2026-225748\",\"organization_id\":1}','::1','curl/8.20.0','2026-07-20 12:12:25'),
(561,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:12:47'),
(562,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:12:49'),
(563,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:36:52'),
(564,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:39:34'),
(565,1,'create','Report',28,NULL,'{\"tracking_code\":\"BA-2026-189866\",\"organization_id\":1}','::1','curl/8.20.0','2026-07-20 12:39:47'),
(566,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:40:08'),
(567,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:40:32'),
(568,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:41:39'),
(569,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:43:31'),
(570,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:47:09'),
(571,1,'assign','Report',15,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:47:54'),
(572,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 12:48:44'),
(573,1,'create','Report',29,NULL,'{\"tracking_code\":\"BA-2026-886838\",\"organization_id\":1}','::1','curl/8.20.0','2026-07-20 12:48:44'),
(574,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:48:47'),
(575,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:49:00'),
(576,45,'create','Report',30,NULL,'{\"tracking_code\":\"BA-2026-144866\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:52:16'),
(577,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:52:29'),
(578,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:52:32'),
(579,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:53:03'),
(580,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:53:12'),
(581,10,'assign','Report',30,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:53:23'),
(582,10,'status_change','Report',30,NULL,'{\"status\":\"acknowledged\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:53:28'),
(583,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:53:54'),
(584,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:54:02'),
(585,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:54:15'),
(586,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:54:17'),
(587,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:54:47'),
(588,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:54:55'),
(589,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:55:22'),
(590,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:55:24'),
(591,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:55:36'),
(592,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:55:45'),
(593,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:56:06'),
(594,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:56:11'),
(595,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:56:41'),
(596,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:56:43'),
(597,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:57:23'),
(598,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:57:31'),
(599,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 12:58:32'),
(600,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:00:41'),
(601,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:00:53'),
(602,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:02:55'),
(603,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:03:27'),
(604,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 13:04:12'),
(605,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-20 13:05:53'),
(606,1,'redirect','Report',18,'{\"organization_id\":1}','{\"organization_id\":2}','::1','curl/8.20.0','2026-07-20 13:05:53'),
(607,1,'assign','Report',18,NULL,NULL,'::1','curl/8.20.0','2026-07-20 13:06:18'),
(608,11,'login','User',11,NULL,NULL,'::1','curl/8.20.0','2026-07-20 13:06:19'),
(609,11,'assign','Report',18,NULL,NULL,'::1','curl/8.20.0','2026-07-20 13:06:19'),
(610,12,'login','User',12,NULL,NULL,'::1','curl/8.20.0','2026-07-20 13:06:20'),
(611,12,'assign','Report',18,NULL,NULL,'::1','curl/8.20.0','2026-07-20 13:06:20'),
(612,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:08:00'),
(613,1,'redirect','Report',30,'{\"organization_id\":2}','{\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:08:21'),
(614,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:08:35'),
(615,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@test.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:08:40'),
(616,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:08:50'),
(617,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:09:15'),
(618,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:10:37'),
(619,1,'status_change','Report',3,NULL,'{\"status\":\"pending_review\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:13:12'),
(620,1,'status_change','Report',3,NULL,'{\"status\":\"validated\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:13:21'),
(621,1,'status_change','Report',3,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:13:26'),
(622,1,'status_change','Report',3,NULL,'{\"status\":\"validated\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:13:30'),
(623,1,'status_change','Report',3,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:13:39'),
(624,1,'status_change','Report',30,NULL,'{\"status\":\"validated\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:16:16'),
(625,1,'status_change','Report',30,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:16:29'),
(626,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:16:45'),
(627,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-20 13:19:31'),
(628,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-20 13:19:41'),
(629,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:42:08'),
(630,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:42:55'),
(631,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 13:49:01'),
(632,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 14:03:29'),
(633,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 14:21:50'),
(634,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 14:22:06'),
(635,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 14:22:16'),
(636,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 14:30:44'),
(637,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 14:40:51'),
(638,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 14:41:10'),
(639,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-20 15:16:53'),
(640,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-20 15:17:10'),
(641,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-20 15:17:26'),
(642,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 15:19:07'),
(643,1,'toggle','LandingGallery',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 15:19:24'),
(644,1,'toggle','LandingGallery',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 15:19:26'),
(645,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-20 15:20:03'),
(646,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:16:31'),
(647,1,'toggle','LandingGallery',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:18:29'),
(648,1,'toggle','LandingGallery',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:18:36'),
(649,1,'create','LandingGallery',7,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:22:09'),
(650,1,'delete','LandingGallery',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:22:15'),
(651,1,'delete','LandingGallery',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:22:50'),
(652,1,'create','LandingGallery',8,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:22:55'),
(653,1,'delete','LandingGallery',4,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:23:36'),
(654,1,'create','LandingGallery',9,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:23:42'),
(655,1,'delete','LandingGallery',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:24:03'),
(656,1,'create','LandingGallery',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:24:09'),
(657,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:27:20'),
(658,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:27:28'),
(659,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:27:42'),
(660,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:27:56'),
(661,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:28:05'),
(662,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:28:12'),
(663,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:28:27'),
(664,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:28:30'),
(665,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:29:23'),
(666,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:52:53'),
(667,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:53:29'),
(668,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:53:30'),
(669,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:53:34'),
(670,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:53:42'),
(671,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:54:00'),
(672,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:54:03'),
(673,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:54:09'),
(674,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:54:11'),
(675,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:55:28'),
(676,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:55:29'),
(677,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:55:37'),
(678,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:55:38'),
(679,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:56:20'),
(680,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:56:26'),
(681,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:57:13'),
(682,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:57:15'),
(683,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:57:22'),
(684,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:57:24'),
(685,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 07:57:34'),
(686,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:57:38'),
(687,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 07:57:50'),
(688,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 07:58:00'),
(689,NULL,'register','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:58:08'),
(690,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 07:58:47'),
(691,1,'logout','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 07:58:47'),
(692,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 07:58:52'),
(693,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 07:59:15'),
(694,47,'create','Report',31,NULL,'{\"tracking_code\":\"BA-2026-316710\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:01:13'),
(695,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:01:44'),
(696,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:01:50'),
(697,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:02:18'),
(698,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:02:26'),
(699,11,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":3,\"commune_id\":3}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:02:57'),
(700,11,'assign','Report',31,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:03:09'),
(701,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:03:26'),
(702,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:03:32'),
(703,3,'assign','Report',31,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:04:03'),
(704,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:04:17'),
(705,4,'login','User',4,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:04:23'),
(706,4,'status_change','Report',31,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:04:30'),
(707,4,'logout','User',4,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:05:58'),
(708,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:06:01'),
(709,10,'status_change','Report',31,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:06:27'),
(710,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:08:19'),
(711,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:08:28'),
(712,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 08:11:03'),
(713,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 08:11:50'),
(714,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:13:32'),
(715,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:13:35'),
(716,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-21 08:14:26'),
(717,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:15:13'),
(718,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:15:22'),
(719,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:15:58'),
(720,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:16:00'),
(721,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:18:20'),
(722,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:18:26'),
(723,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:18:30'),
(724,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:18:35'),
(725,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:18:40'),
(726,NULL,'login_locked','User',46,'{\"locked_until\":\"2026-07-21 09:33:40\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:18:44'),
(727,NULL,'login_locked','User',46,'{\"locked_until\":\"2026-07-21 09:33:40\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:18:59'),
(728,NULL,'login_failed','User',NULL,'{\"email\":\"dodo@gmail.com\"}',NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:19:16'),
(729,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:19:26'),
(730,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:20:25'),
(731,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:21:07'),
(732,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:21:53'),
(733,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:22:00'),
(734,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:22:23'),
(735,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:22:25'),
(736,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-21 08:22:34'),
(737,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:43:01'),
(738,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:52:58'),
(739,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:55:25'),
(740,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:55:34'),
(741,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:57:36'),
(742,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:59:28'),
(743,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 08:59:49'),
(744,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:00:29'),
(745,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:01:29'),
(746,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:01:31'),
(747,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:02:31'),
(748,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:02:38'),
(749,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:04:33'),
(750,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:04:38'),
(751,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:05:24'),
(752,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:05:27'),
(753,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 09:15:00'),
(754,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 10:34:01'),
(755,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 10:38:21'),
(756,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 10:38:28'),
(757,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 10:38:48'),
(758,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 10:39:09'),
(759,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 10:40:51'),
(760,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 10:41:02'),
(761,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:00:39'),
(762,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:21:40'),
(763,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:38:23'),
(764,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:38:54'),
(765,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:40:23'),
(766,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:40:31'),
(767,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:41:13'),
(768,NULL,'register','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:43:25'),
(769,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:43:31'),
(770,48,'update_profile','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:44:06'),
(771,48,'update_profile','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:44:14'),
(772,48,'create','Report',32,NULL,'{\"tracking_code\":\"BA-2026-577793\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:46:42'),
(773,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:47:05'),
(774,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:47:20'),
(775,1,'redirect','Report',32,'{\"organization_id\":1}','{\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 11:47:34'),
(776,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:03:08'),
(777,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:11:24'),
(778,NULL,'login_locked','User',46,'{\"locked_until\":\"2026-07-21 13:26:24\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:11:35'),
(779,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:11:48'),
(780,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:13:03'),
(781,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:13:09'),
(782,10,'assign','Report',32,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:13:37'),
(783,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:13:52'),
(784,5,'login','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:13:58'),
(785,5,'status_change','Report',32,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:14:16'),
(786,5,'logout','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:15:25'),
(787,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:15:40'),
(788,1,'status_change','Report',32,NULL,'{\"status\":\"validated\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:16:06'),
(789,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:16:16'),
(790,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:16:22'),
(791,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:19:32'),
(792,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-21 12:29:42'),
(793,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-21 12:32:13'),
(794,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:37:51'),
(795,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 12:53:14'),
(796,NULL,'register','User',49,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:11:22'),
(797,49,'login','User',49,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:11:29'),
(798,49,'logout','User',49,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:12:54'),
(799,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:13:05'),
(800,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:14:44'),
(801,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:14:53'),
(802,48,'create','Report',33,NULL,'{\"tracking_code\":\"BA-2026-343390\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:15:34'),
(803,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:15:48'),
(804,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:16:01'),
(805,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:16:05'),
(806,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:16:13'),
(807,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:16:33'),
(808,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:16:46'),
(809,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:18:15'),
(810,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:18:59'),
(811,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:21:07'),
(812,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 13:58:55'),
(813,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:01:17'),
(814,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:01:22'),
(815,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:01:55'),
(816,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:02:01'),
(817,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:02:33'),
(818,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:03:02'),
(819,46,'login','User',46,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:11:23'),
(820,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:20:55'),
(821,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:30:16'),
(822,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:30:30'),
(823,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:31:21'),
(824,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:31:24'),
(825,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:35:22'),
(826,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:35:25'),
(827,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:36:07'),
(828,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 14:36:10'),
(829,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:20:46'),
(830,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:21:01'),
(831,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:21:12'),
(832,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:23:23'),
(833,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:23:26'),
(834,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:24:03'),
(835,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:31:09'),
(836,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 15:41:25'),
(837,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 16:35:46'),
(838,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 16:35:56'),
(839,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 16:35:59'),
(840,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 16:47:39'),
(841,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 16:55:43'),
(842,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 16:59:30'),
(843,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-21 16:59:33'),
(844,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:08:11'),
(845,NULL,'register','User',50,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:08:17'),
(846,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:08:19'),
(847,NULL,'login_failed','User',NULL,'{\"email\":\"hamzachabane292@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:08:29'),
(848,NULL,'login_failed','User',NULL,'{\"email\":\"hamzachabane292@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:08:41'),
(849,NULL,'login_failed','User',NULL,'{\"email\":\"hamzachabane292@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:09:41'),
(850,NULL,'login_failed','User',NULL,'{\"email\":\"hamzachabane292@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:10:22'),
(851,1,'update','User',50,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:10:47'),
(852,NULL,'login_failed','User',NULL,'{\"email\":\"hamzachabane292@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:11:04'),
(853,NULL,'login_locked','User',50,'{\"locked_until\":\"2026-07-22 11:26:04\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:11:18'),
(854,1,'update','User',50,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:11:58'),
(855,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:12:07'),
(856,NULL,'login_locked','User',50,'{\"locked_until\":\"2026-07-22 11:26:04\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:12:14'),
(857,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:12:22'),
(858,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:12:50'),
(859,NULL,'login_locked','User',50,'{\"locked_until\":\"2026-07-22 11:26:04\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:13:08'),
(860,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:13:13'),
(861,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:13:28'),
(862,NULL,'login_failed','User',NULL,'{\"email\":\"hamza123@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:13:30'),
(863,47,'login','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:13:33'),
(864,47,'logout','User',47,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:13:39'),
(865,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:13:43'),
(866,NULL,'register','User',51,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:14:04'),
(867,51,'login','User',51,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:14:39'),
(868,1,'update_profile','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:22:45'),
(869,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:23:50'),
(870,51,'login','User',51,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:24:30'),
(871,51,'create','Report',34,NULL,'{\"tracking_code\":\"BA-2026-592035\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:25:02'),
(872,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 10:40:34'),
(873,51,'logout','User',51,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:48:48'),
(874,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:48:51'),
(875,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 10:49:30'),
(876,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 10:53:42'),
(877,1,'create','Report',35,NULL,'{\"tracking_code\":\"BA-2026-487225\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:07:10'),
(878,1,'create','Report',36,NULL,'{\"tracking_code\":\"BA-2026-099487\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:08:34'),
(879,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:25:42'),
(880,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:25:50'),
(881,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 11:35:46'),
(882,45,'login','User',45,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 11:36:19'),
(883,48,'create','Report',37,NULL,'{\"tracking_code\":\"BA-2026-377442\",\"organization_id\":9}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:38:18'),
(884,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:38:45'),
(885,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:38:48'),
(886,1,'assign','Report',37,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:46:51'),
(887,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:47:04'),
(888,65,'login','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:47:11'),
(889,65,'logout','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:47:32'),
(890,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:47:34'),
(891,1,'assign','Report',37,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:47:47'),
(892,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:47:58'),
(893,71,'login','User',71,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:48:08'),
(894,71,'logout','User',71,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:48:33'),
(895,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:48:35'),
(896,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:48:53'),
(897,68,'login','User',68,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:00'),
(898,68,'logout','User',68,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:05'),
(899,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:07'),
(900,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:24'),
(901,63,'login','User',63,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:30'),
(902,63,'logout','User',63,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:34'),
(903,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:35'),
(904,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:39'),
(905,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:49:53'),
(906,48,'create','Report',38,NULL,'{\"tracking_code\":\"BA-2026-703167\",\"organization_id\":9}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:51:20'),
(907,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:51:25'),
(908,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:51:27'),
(909,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:51:59'),
(910,66,'login','User',66,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:52:05'),
(911,66,'assign','Report',38,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:52:16'),
(912,66,'status_change','Report',38,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:52:20'),
(913,66,'status_change','Report',38,NULL,'{\"status\":\"assigned\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:52:36'),
(914,66,'status_change','Report',38,NULL,'{\"status\":\"acknowledged\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:52:43'),
(915,66,'assign','Report',38,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:52:49'),
(916,66,'logout','User',66,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:53:21'),
(917,65,'login','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:53:28'),
(918,65,'logout','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:53:39'),
(919,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:53:41'),
(920,1,'assign','Report',38,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:53:50'),
(921,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:54:01'),
(922,65,'login','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 11:54:06'),
(923,65,'status_change','Report',38,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:03:22'),
(924,65,'status_change','Report',38,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:03:32'),
(925,65,'logout','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:04:31'),
(926,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:04:33'),
(927,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:12'),
(928,63,'login','User',63,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:18'),
(929,63,'logout','User',63,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:24'),
(930,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:26'),
(931,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:37'),
(932,68,'login','User',68,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:44'),
(933,68,'logout','User',68,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:49'),
(934,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:05:52'),
(935,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:13:54'),
(936,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:22:20'),
(937,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:22:34'),
(938,65,'login','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:22:41'),
(939,65,'status_change','Report',38,NULL,'{\"status\":\"in_progress\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:23:14'),
(940,65,'logout','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:23:27'),
(941,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:23:30'),
(942,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:23:46'),
(943,11,'login','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:23:52'),
(944,11,'logout','User',11,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:24:23'),
(945,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:24:25'),
(946,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:24:34'),
(947,65,'login','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:24:46'),
(948,65,'logout','User',65,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:25:00'),
(949,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:25:02'),
(950,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:27:11'),
(951,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:27:36'),
(952,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:28:07'),
(953,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:29:31'),
(954,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:30:27'),
(955,67,'create','Report',40,NULL,'{\"tracking_code\":\"BA-2026-870446\",\"organization_id\":9}','127.0.0.1','curl/8.20.0','2026-07-22 12:30:27'),
(956,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:30:29'),
(957,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:30:30'),
(958,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:30:30'),
(959,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:30:31'),
(960,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:30:53'),
(961,71,'assign','Report',40,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:30:53'),
(962,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:31:35'),
(963,67,'create','Report',41,NULL,'{\"tracking_code\":\"BA-2026-454232\",\"organization_id\":9}','127.0.0.1','curl/8.20.0','2026-07-22 12:31:35'),
(964,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:31:36'),
(965,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:31:36'),
(966,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:31:37'),
(967,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:31:38'),
(968,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:32:11'),
(969,67,'create','Report',42,NULL,'{\"tracking_code\":\"BA-2026-995263\",\"organization_id\":9}','127.0.0.1','curl/8.20.0','2026-07-22 12:32:11'),
(970,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:32:38'),
(971,67,'create','Report',43,NULL,'{\"tracking_code\":\"BA-2026-413825\",\"organization_id\":9}','127.0.0.1','curl/8.20.0','2026-07-22 12:32:39'),
(972,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:32:39'),
(973,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:32:41'),
(974,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:32:41'),
(975,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:32:42'),
(976,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:33:03'),
(977,71,'assign','Report',43,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:33:03'),
(978,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:33:24'),
(979,71,'assign','Report',43,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:33:24'),
(980,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:33:57'),
(981,67,'create','Report',44,NULL,'{\"tracking_code\":\"BA-2026-036363\",\"organization_id\":9}','127.0.0.1','curl/8.20.0','2026-07-22 12:33:57'),
(982,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:33:58'),
(983,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:34:00'),
(984,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:34:01'),
(985,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:34:03'),
(986,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:34:22'),
(987,71,'assign','Report',44,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:34:22'),
(988,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:35:15'),
(989,67,'create','Report',45,NULL,'{\"tracking_code\":\"BA-2026-671311\",\"organization_id\":9}','127.0.0.1','curl/8.20.0','2026-07-22 12:35:16'),
(990,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:35:17'),
(991,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:35:20'),
(992,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:35:22'),
(993,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:35:24'),
(994,1,'assign','Report',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:36:39'),
(995,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:36:41'),
(996,71,'assign','Report',45,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 12:36:42'),
(997,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 12:46:16'),
(998,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:01:52'),
(999,68,'login','User',68,NULL,NULL,'::1','curl/8.20.0','2026-07-22 13:07:12'),
(1000,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:08:28'),
(1001,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:09:08'),
(1002,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:09:25'),
(1003,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:10:07'),
(1004,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:10:08'),
(1005,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:10:09'),
(1006,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:10:09'),
(1007,1,'create','Report',46,NULL,'{\"tracking_code\":\"BA-2026-790931\",\"organization_id\":2}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:11:45'),
(1008,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:12:07'),
(1009,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:12:12'),
(1010,10,'login','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:12:18'),
(1011,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:12:32'),
(1012,71,'login','User',71,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:12:32'),
(1013,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:12:49'),
(1014,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:12:50'),
(1015,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:12:50'),
(1016,10,'assign','Report',46,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:13:03'),
(1017,10,'status_change','Report',46,NULL,'{\"status\":\"assigned\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:13:06'),
(1018,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:13:07'),
(1019,70,'assign','Report',45,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:13:07'),
(1020,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:13:22'),
(1021,70,'assign','Report',45,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:13:22'),
(1022,10,'logout','User',10,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:13:24'),
(1023,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:13:31'),
(1024,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:13:43'),
(1025,69,'assign','Report',45,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:13:44'),
(1026,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:13:44'),
(1027,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:14:12'),
(1028,3,'assign','Report',46,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:14:34'),
(1029,3,'status_change','Report',46,NULL,'{\"status\":\"pending_unite\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:14:40'),
(1030,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:14:47'),
(1031,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:14:54'),
(1032,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:14:56'),
(1033,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:15:25'),
(1034,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:15:33'),
(1035,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:16:01'),
(1036,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:16:16'),
(1037,5,'login','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:16:23'),
(1038,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:16:44'),
(1039,68,'login','User',68,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:16:55'),
(1040,69,'login','User',69,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:17:06'),
(1041,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:17:25'),
(1042,5,'logout','User',5,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:18:40'),
(1043,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:18:50'),
(1044,70,'login','User',70,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:19:11'),
(1045,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:20:53'),
(1046,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:20:56'),
(1047,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:22:12'),
(1048,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 13:22:24'),
(1049,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:29:05'),
(1050,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:29:26'),
(1051,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:31:55'),
(1052,67,'login','User',67,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-22 13:32:11'),
(1053,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:00:46'),
(1054,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:00:48'),
(1055,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:01:39'),
(1056,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:01:53'),
(1057,45,'update_profile','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:03:01'),
(1058,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:13:29'),
(1059,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:13:31'),
(1060,1,'update_profile','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:15:33'),
(1061,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:16:55'),
(1062,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:16:58'),
(1063,45,'update_profile','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:27:31'),
(1064,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:27:35'),
(1065,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:27:38'),
(1066,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:28:33'),
(1067,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:28:36'),
(1068,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:29:03'),
(1069,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:29:09'),
(1070,3,'status_change','Report',46,NULL,'{\"status\":\"pending_unite\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:30:10'),
(1071,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:31:09'),
(1072,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:31:31'),
(1073,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:31:33'),
(1074,13,'login','User',13,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:31:39'),
(1075,13,'logout','User',13,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:34:11'),
(1076,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:34:14'),
(1077,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:36:17'),
(1078,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:36:20'),
(1079,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:36:49'),
(1080,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:36:52'),
(1081,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:51:52'),
(1082,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 14:51:54'),
(1083,NULL,'login_failed','User',NULL,'{\"email\":\"hamza123@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 15:00:34'),
(1084,51,'login','User',51,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 15:00:56'),
(1085,51,'update_profile','User',51,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 15:01:28'),
(1086,51,'logout','User',51,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 15:02:16'),
(1087,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 15:02:51'),
(1088,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 15:07:49'),
(1089,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-22 15:08:00'),
(1090,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 15:13:45'),
(1091,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 15:13:47'),
(1092,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-22 15:21:40'),
(1093,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 06:13:59'),
(1094,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 08:26:02'),
(1095,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 09:01:55'),
(1096,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 09:02:06'),
(1097,3,'status_change','Report',46,NULL,'{\"status\":\"pending_unite\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 09:57:42'),
(1098,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 09:57:46'),
(1099,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 09:57:49'),
(1100,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 10:44:17'),
(1101,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-23 10:56:13'),
(1102,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:01:29'),
(1103,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:02:32'),
(1104,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:02:36'),
(1105,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:03:52'),
(1106,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:03:55'),
(1107,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:04:01'),
(1108,3,'login','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:04:03'),
(1109,3,'logout','User',3,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:04:11'),
(1110,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:04:14'),
(1111,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:05:42'),
(1112,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:05:53'),
(1113,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:06:20'),
(1114,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:06:23'),
(1115,1,'status_change','Report',46,NULL,'{\"status\":\"validated\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:06:40'),
(1116,1,'status_change','Report',44,NULL,'{\"status\":\"validated\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:07:59'),
(1117,1,'assign','Report',43,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:08:10'),
(1118,1,'status_change','Report',43,NULL,'{\"status\":\"rejected\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:08:15'),
(1119,1,'status_change','Report',46,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:08:33'),
(1120,1,'status_change','Report',38,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:08:47'),
(1121,1,'status_change','Report',21,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:09:46'),
(1122,1,'status_change','Report',45,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:10:12'),
(1123,1,'status_change','Report',44,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:10:25'),
(1124,1,'status_change','Report',42,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:10:33'),
(1125,1,'status_change','Report',41,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:10:41'),
(1126,1,'status_change','Report',40,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:10:54'),
(1127,1,'status_change','Report',37,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:11:05'),
(1128,1,'status_change','Report',36,NULL,'{\"status\":\"resolved\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:11:19'),
(1129,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:12:13'),
(1130,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:12:17'),
(1131,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-23 11:13:45'),
(1132,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-23 11:14:22'),
(1133,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-23 11:14:30'),
(1134,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:17:02'),
(1135,48,'login','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:17:13'),
(1136,48,'logout','User',48,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:17:47'),
(1137,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:17:49'),
(1138,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:41:34'),
(1139,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:41:37'),
(1140,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:41:53'),
(1141,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:41:56'),
(1142,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:42:06'),
(1143,1,'login','User',1,NULL,NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-23 11:44:02'),
(1144,1,'logout','User',1,NULL,NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-23 11:44:28'),
(1145,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:44:33'),
(1146,45,'login','User',45,NULL,NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-23 11:44:35'),
(1147,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:45:20'),
(1148,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:45:37'),
(1149,NULL,'login_failed','User',NULL,'{\"email\":\"citizen@test.com\"}',NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:46:22'),
(1150,NULL,'register','User',72,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:47:00'),
(1151,72,'login','User',72,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:47:10'),
(1152,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:47:39'),
(1153,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:47:42'),
(1154,72,'login','User',72,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:48:46'),
(1155,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:50:21'),
(1156,NULL,'login_failed','User',NULL,'{\"email\":\"fatima@balagh-alger.dz\"}',NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:50:49'),
(1157,3,'login','User',3,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 11:50:50'),
(1158,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:53:06'),
(1159,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:56:02'),
(1160,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:56:08'),
(1161,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:56:16'),
(1162,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:56:44'),
(1163,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:56:51'),
(1164,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:57:20'),
(1165,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 11:57:36'),
(1166,72,'login','User',72,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 12:02:21'),
(1167,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 12:03:03'),
(1168,72,'login','User',72,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 12:03:26'),
(1169,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 12:23:10'),
(1170,72,'login','User',72,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-23 12:24:27'),
(1171,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 12:42:10'),
(1172,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 12:42:18'),
(1173,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 14:33:01'),
(1174,NULL,'login_failed','User',NULL,'{\"email\":\"hamza123@gmail.com\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 15:30:56'),
(1175,51,'login','User',51,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-23 15:31:13'),
(1176,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 11:15:07'),
(1177,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 11:51:33'),
(1178,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 11:51:43'),
(1179,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 11:52:03'),
(1180,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-26 11:57:00'),
(1181,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-26 11:57:15'),
(1182,NULL,'login_failed','User',NULL,'{\"email\":\"test.asrut.1@balagh-alger.dz\"}',NULL,'127.0.0.1','curl/8.20.0','2026-07-26 11:58:08'),
(1183,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 12:05:54'),
(1184,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 12:13:37'),
(1185,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-26 12:16:06'),
(1186,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-26 12:16:35'),
(1187,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 12:17:50'),
(1188,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 12:45:01'),
(1189,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 12:45:11'),
(1190,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 12:48:59'),
(1191,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 12:49:14'),
(1192,1,'login','User',1,NULL,NULL,'127.0.0.1','curl/8.20.0','2026-07-26 12:51:07'),
(1193,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:04:05'),
(1194,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:04:16'),
(1195,1,'login','User',1,NULL,NULL,'192.168.117.37','curl/8.20.0','2026-07-26 13:04:19'),
(1196,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:05:31'),
(1197,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:05:38'),
(1198,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:07:46'),
(1199,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:07:55'),
(1200,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:08:41'),
(1201,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:16:18'),
(1202,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:16:30'),
(1203,45,'create','Report',47,NULL,'{\"tracking_code\":\"BA-2026-949108\",\"organization_id\":2}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:19:27'),
(1204,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:20:41'),
(1205,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:20:48'),
(1206,1,'status_change','Report',47,NULL,'{\"status\":\"assigned\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:21:37'),
(1207,1,'assign','Report',47,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:22:26'),
(1208,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:23:08'),
(1209,11,'login','User',11,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:23:14'),
(1210,11,'assign','Report',47,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:23:22'),
(1211,11,'logout','User',11,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:23:47'),
(1212,3,'login','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:23:51'),
(1213,3,'logout','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:24:37'),
(1214,5,'login','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:24:42'),
(1215,5,'logout','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:25:57'),
(1216,3,'login','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:26:06'),
(1217,3,'logout','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:26:20'),
(1218,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:26:27'),
(1219,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:27:05'),
(1220,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:27:11'),
(1221,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1 Edg/150.0.0.0','2026-07-26 13:45:33'),
(1222,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:45:44'),
(1223,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:46:39'),
(1224,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 13:48:40'),
(1225,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:01:50'),
(1226,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:02:00'),
(1227,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:06:34'),
(1228,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:06:43'),
(1229,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:22:50'),
(1230,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:23:15'),
(1231,NULL,'register','User',73,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-26 14:37:45'),
(1232,73,'login','User',73,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-26 14:38:07'),
(1233,73,'create','Report',48,NULL,'{\"tracking_code\":\"BA-2026-308430\",\"organization_id\":2}','192.168.117.200','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-26 14:40:15'),
(1234,1,'status_change','Report',48,NULL,'{\"status\":\"assigned\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:42:22'),
(1235,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:45:16'),
(1236,10,'login','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:45:22'),
(1237,10,'assign','Report',48,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:45:40'),
(1238,10,'status_change','Report',48,NULL,'{\"status\":\"in_progress\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:45:45'),
(1239,10,'logout','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:46:27'),
(1240,11,'login','User',11,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:46:38'),
(1241,11,'status_change','Report',48,NULL,'{\"status\":\"in_progress\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:54:28'),
(1242,11,'logout','User',11,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:56:19'),
(1243,3,'login','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:56:27'),
(1244,3,'logout','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:57:15'),
(1245,5,'login','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:57:20'),
(1246,5,'logout','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:57:30'),
(1247,3,'login','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:57:37'),
(1248,3,'logout','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:57:58'),
(1249,13,'login','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:58:02'),
(1250,13,'logout','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:58:10'),
(1251,5,'login','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:58:20'),
(1252,5,'logout','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:58:30'),
(1253,3,'login','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:58:40'),
(1254,3,'logout','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:58:57'),
(1255,4,'login','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:59:01'),
(1256,4,'logout','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:59:08'),
(1257,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 14:59:12'),
(1258,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:00:18'),
(1259,10,'login','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:00:23'),
(1260,10,'logout','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:01:59'),
(1261,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:02:04'),
(1262,NULL,'login_failed','User',NULL,'{\"email\":\"adminlocal@balagh-alger.dz\"}',NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:02:09'),
(1263,46,'login','User',46,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:02:17'),
(1264,46,'logout','User',46,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:02:52'),
(1265,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:11:39'),
(1266,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-26 15:14:16'),
(1267,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:00:24'),
(1268,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:00:52'),
(1269,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:00:55'),
(1270,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:05:16'),
(1271,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:05:19'),
(1272,1,'status_change','Report',48,NULL,'{\"status\":\"rejected\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:05:38'),
(1273,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:57:50'),
(1274,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:57:59'),
(1275,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:59:28'),
(1276,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 09:59:31'),
(1277,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:10:20'),
(1278,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:10:23'),
(1279,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:42:38'),
(1280,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:42:41'),
(1281,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:50:52'),
(1282,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:50:54'),
(1283,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:52:30'),
(1284,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:52:58'),
(1285,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:53:43'),
(1286,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 10:53:45'),
(1287,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:06:49'),
(1288,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:06:54'),
(1289,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:06:58'),
(1290,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:07:13'),
(1291,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:33:16'),
(1292,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:33:19'),
(1293,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:35:31'),
(1294,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:35:33'),
(1295,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:53:08'),
(1296,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 11:53:10'),
(1297,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:06:38'),
(1298,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:06:40'),
(1299,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:11:00'),
(1300,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:11:03'),
(1301,NULL,'login_failed','User',NULL,'{\"email\":\"http:\\/\\/www.google.com\\/search?q=ZAP\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1302,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com\\/\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1303,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com:80\\/\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1304,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1305,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com\\/search?q=ZAP\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1306,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com:80\\/search?q=ZAP\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1307,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1308,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1309,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1310,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1311,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1312,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1313,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:45'),
(1314,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:46'),
(1315,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:46'),
(1316,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:46'),
(1317,NULL,'register','User',74,NULL,NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:46'),
(1318,NULL,'login_failed','User',NULL,'{\"email\":\"https:\\/\\/3406012550848560242.owasp.org\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:47'),
(1319,NULL,'login_failed','User',NULL,'{\"email\":\"URL=\'http:\\/\\/3406012550848560242.owasp.org\'\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:47'),
(1320,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:48'),
(1321,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:48'),
(1322,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:48'),
(1323,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:49'),
(1324,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:49'),
(1325,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:49'),
(1326,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:49'),
(1327,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:49'),
(1328,NULL,'login_failed','User',NULL,'{\"email\":\"<!--#EXEC cmd=\\\"dir \\\\\\\"-->\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:50'),
(1329,NULL,'login_failed','User',NULL,'{\"email\":\"\\\"><!--#EXEC cmd=\\\"dir \\\\\\\"--><\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:50'),
(1330,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:50'),
(1331,NULL,'login_failed','User',NULL,'{\"email\":\"\'\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:51'),
(1332,NULL,'login_failed','User',NULL,'{\"email\":\";\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:51'),
(1333,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com;\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:51'),
(1334,NULL,'login_failed','User',NULL,'{\"email\":\"\'(\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:51'),
(1335,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1336,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1337,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com AND 1=1 --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1338,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com UNION ALL select NULL --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1339,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\" UNION ALL select NULL --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1340,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\') UNION ALL select NULL --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1341,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1342,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1343,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:52'),
(1344,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:53'),
(1345,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:53'),
(1346,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:53'),
(1347,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:53'),
(1348,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:53'),
(1349,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:53'),
(1350,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:53'),
(1351,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:54'),
(1352,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:54'),
(1353,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:54'),
(1354,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:54'),
(1355,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:54'),
(1356,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:54'),
(1357,NULL,'login_failed','User',NULL,'{\"email\":\";print(chr(122).chr(97).chr(112).chr(95).chr(116).chr(111).chr(107).chr(101).chr(110));\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:56'),
(1358,NULL,'login_failed','User',NULL,'{\"email\":\"\\\"+response.write(999\\u202f193*324\\u202f778)+\\\"\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:56'),
(1359,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:56'),
(1360,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:56'),
(1361,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:56'),
(1362,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:57'),
(1363,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:57'),
(1364,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com&cat \\/etc\\/passwd&\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1365,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\"&cat \\/etc\\/passwd&\\\"\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1366,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\";cat \\/etc\\/passwd;\\\"\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1367,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\'&cat \\/etc\\/passwd&\'\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1368,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\';cat \\/etc\\/passwd;\'\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1369,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com|type %SYSTEMROOT%\\\\win.ini\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1370,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\"&type %SYSTEMROOT%\\\\win.ini&\\\"\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1371,NULL,'login_failed','User',NULL,'{\"email\":\"get-help\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1372,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com;get-help\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:58'),
(1373,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\";get-help\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:59'),
(1374,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com;get-help #\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:59'),
(1375,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:59'),
(1376,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:59'),
(1377,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:59'),
(1378,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:59'),
(1379,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:34:59'),
(1380,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:00'),
(1381,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:00'),
(1382,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:00'),
(1383,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:00'),
(1384,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:00'),
(1385,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:00'),
(1386,NULL,'login_failed','User',NULL,'{\"email\":\"\\\"\'\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:02'),
(1387,NULL,'login_failed','User',NULL,'{\"email\":\"<!--\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:02'),
(1388,NULL,'login_failed','User',NULL,'{\"email\":\"]]>\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:02'),
(1389,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:02'),
(1390,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:02'),
(1391,NULL,'login_failed','User',NULL,'{\"email\":\"zj 4425*3050 zj\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:03'),
(1392,NULL,'login_failed','User',NULL,'{\"email\":\"zj<%=1465*5373%>zj\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:03'),
(1393,NULL,'login_failed','User',NULL,'{\"email\":\"zj<p th:text=\\\"${8441*9753}\\\"><\\/p>zj\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:03'),
(1394,NULL,'login_failed','User',NULL,'{\"email\":\"zj{@math key=\\\"8908\\\" method=\\\"multiply\\\" operand=\\\"2307\\\"\\/}zj\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:03'),
(1395,NULL,'login_failed','User',NULL,'{\"email\":\"zj{{print \\\"7501\\\" \\\"6238\\\"}}zj\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:03'),
(1396,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:03'),
(1397,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:03'),
(1398,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1399,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1400,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1401,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1402,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1403,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1404,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1405,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:04'),
(1406,NULL,'login_failed','User',NULL,'{\"email\":\"#set($engine=\\\"\\\")\\n#set($proc=$engine.getClass().forName(\\\"java.lang.Runtime\\\").getRuntime().exec(\\\"sleep 15\\\"))\\n#set($null=$proc.waitFor())\\n${null}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:06'),
(1407,NULL,'login_failed','User',NULL,'{\"email\":\"{{range.constructor(\\\"return eval(\\\\\\\"global.process.mainModule.require(\'child_process\').execSync(\'sleep 15\').toString()\\\\\\\")\\\")()}}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:06'),
(1408,NULL,'login_failed','User',NULL,'{\"email\":\"{{\\\"\\\".__class__.__mro__[1].__subclasses__()[157].__repr__.__globals__.get(\\\"__builtins__\\\").get(\\\"__import__\\\")(\\\"subprocess\\\").check_output(\\\"sleep 15\\\")}}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:06'),
(1409,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:06'),
(1410,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:06'),
(1411,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:07'),
(1412,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:07'),
(1413,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:07'),
(1414,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:07'),
(1415,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:07'),
(1416,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:07'),
(1417,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:07'),
(1418,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\"&sleep 15.0&\\\"\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:08'),
(1419,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\'|timeout \\/T 15.0\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:08'),
(1420,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com;start-sleep -s 15.0\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:08'),
(1421,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com;start-sleep -s 15.0 #\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:09'),
(1422,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:09'),
(1423,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:09'),
(1424,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:09'),
(1425,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:09'),
(1426,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:09'),
(1427,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:09'),
(1428,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:10'),
(1429,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:10'),
(1430,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:10'),
(1431,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:10'),
(1432,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:10'),
(1433,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:10'),
(1434,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:10'),
(1435,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:13'),
(1436,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:13'),
(1437,NULL,'login_failed','User',NULL,'{\"email\":\"ZAP\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:13'),
(1438,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:14'),
(1439,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:14'),
(1440,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:14'),
(1441,NULL,'login_failed','User',NULL,'{\"email\":\"any?\\r\\nSet-cookie: Tamper=3fa299b7-3dba-4c66-bfc8-9dccaec8f85c\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:15'),
(1442,NULL,'login_failed','User',NULL,'{\"email\":\"any\\r\\nSet-cookie: Tamper=3fa299b7-3dba-4c66-bfc8-9dccaec8f85c\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:15'),
(1443,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:15'),
(1444,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:15'),
(1445,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:15'),
(1446,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:15'),
(1447,NULL,'login_failed','User',NULL,'{\"email\":\"+\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:16'),
(1448,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:17'),
(1449,NULL,'login_failed','User',NULL,'{\"email\":\"system-property(\'xsl:vendor\')\\/>\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:19'),
(1450,NULL,'login_failed','User',NULL,'{\"email\":\"<xsl:value-of select=\\\"system-property(\'xsl:vendor\')\\\"\\/><!--\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:19'),
(1451,NULL,'login_failed','User',NULL,'{\"email\":\"<xsl:variable name=\\\"rtobject\\\" select=\\\"runtime:getRuntime()\\\"\\/>\\n<xsl:variable name=\\\"process\\\" select=\\\"runtime:exec($rtobject,\'erroneous_command\')\\\"\\/>\\n<xsl:variable name=\\\"waiting\\\" select=\\\"process:waitFor($process)\\\"\\/>\\n<xsl:value-of select=\\\"$process\\\"\\/>\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:19'),
(1452,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:19'),
(1453,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:19'),
(1454,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:35:19'),
(1455,NULL,'login_failed','User',NULL,'{\"email\":\"http:\\/\\/www.google.com\\/\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:18'),
(1456,NULL,'login_failed','User',NULL,'{\"email\":\"http:\\/\\/www.google.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:18'),
(1457,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1458,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com\\/search?q=ZAP\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1459,NULL,'login_failed','User',NULL,'{\"email\":\"www.google.com:80\\/search?q=ZAP\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1460,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1461,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1462,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1463,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1464,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:19'),
(1465,NULL,'login_failed','User',NULL,'{\"email\":\"https:\\/\\/\\\\3406012550848560242.owasp.org\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:21'),
(1466,NULL,'login_failed','User',NULL,'{\"email\":\"http:\\/\\/\\\\3406012550848560242.owasp.org\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:21'),
(1467,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:21'),
(1468,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:21'),
(1469,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:21'),
(1470,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:21'),
(1471,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:22'),
(1472,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:22'),
(1473,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:22'),
(1474,NULL,'login_failed','User',NULL,'{\"email\":\"<!--#EXEC cmd=\\\"dir \\\\\\\"-->\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:23'),
(1475,NULL,'login_failed','User',NULL,'{\"email\":\"\\\"><!--#EXEC cmd=\\\"dir \\\\\\\"--><\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:23'),
(1476,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:23'),
(1477,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:24'),
(1478,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\'(\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:25'),
(1479,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com AND 1=2 --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:25'),
(1480,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com OR 1=1 --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:25'),
(1481,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\' AND \'1\'=\'1\' --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:25'),
(1482,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\' AND \'1\'=\'2\' --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:25'),
(1483,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\' OR \'1\'=\'1\' --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:25'),
(1484,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com UNION ALL select NULL --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:25'),
(1485,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\') UNION ALL select NULL --\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:26'),
(1486,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:26'),
(1487,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:26'),
(1488,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:26'),
(1489,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:27'),
(1490,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:27'),
(1491,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:27'),
(1492,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:28'),
(1493,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:28'),
(1494,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:28'),
(1495,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:28'),
(1496,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:28'),
(1497,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:28'),
(1498,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:28'),
(1499,NULL,'login_failed','User',NULL,'{\"email\":\"${@print(chr(122).chr(97).chr(112).chr(95).chr(116).chr(111).chr(107).chr(101).chr(110))}\\\\\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1500,NULL,'login_failed','User',NULL,'{\"email\":\";print(chr(122).chr(97).chr(112).chr(95).chr(116).chr(111).chr(107).chr(101).chr(110));\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1501,NULL,'login_failed','User',NULL,'{\"email\":\"\\\"+response.write(352\\u202f881*262\\u202f738)+\\\"\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1502,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1503,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1504,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1505,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1506,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1507,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1508,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:31'),
(1509,NULL,'login_failed','User',NULL,'{\"email\":\"cat \\/etc\\/passwd\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:33'),
(1510,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\"&type %SYSTEMROOT%\\\\win.ini&\\\"\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:33'),
(1511,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\"|type %SYSTEMROOT%\\\\win.ini\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:33'),
(1512,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\'&type %SYSTEMROOT%\\\\win.ini&\'\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:33'),
(1513,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\'|type %SYSTEMROOT%\\\\win.ini\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:33'),
(1514,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\';get-help\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:34'),
(1515,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:34'),
(1516,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:34'),
(1517,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:34'),
(1518,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:34'),
(1519,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:34'),
(1520,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:34'),
(1521,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:35'),
(1522,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:35'),
(1523,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:36'),
(1524,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:36'),
(1525,NULL,'login_failed','User',NULL,'{\"email\":\"]]>\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:37'),
(1526,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:37'),
(1527,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:37'),
(1528,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:38'),
(1529,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:38'),
(1530,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:38'),
(1531,NULL,'login_failed','User',NULL,'{\"email\":\"zj{{=2767*9688}}zj\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:39'),
(1532,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:39'),
(1533,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:40'),
(1534,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:40'),
(1535,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:40'),
(1536,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:40'),
(1537,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:40'),
(1538,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:41'),
(1539,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:41'),
(1540,NULL,'login_failed','User',NULL,'{\"email\":\"<#assign ex=\\\"freemarker.template.utility.Execute\\\"?new()> ${ ex(\\\"sleep 15\\\") }\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:42'),
(1541,NULL,'login_failed','User',NULL,'{\"email\":\"{{range.constructor(\\\"return eval(\\\\\\\"global.process.mainModule.require(\'child_process\').execSync(\'sleep 15\').toString()\\\\\\\")\\\")()}}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:42'),
(1542,NULL,'login_failed','User',NULL,'{\"email\":\"{{\\\"\\\".__class__.__mro__[1].__subclasses__()[157].__repr__.__globals__.get(\\\"__builtins__\\\").get(\\\"__import__\\\")(\\\"subprocess\\\").check_output(\\\"sleep 15\\\")}}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:42'),
(1543,NULL,'login_failed','User',NULL,'{\"email\":\"${__import__(\\\"subprocess\\\").check_output(\\\"sleep 15\\\", shell=True)}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:42'),
(1544,NULL,'login_failed','User',NULL,'{\"email\":\"{{__import__(\\\"subprocess\\\").check_output(\\\"sleep 15\\\", shell=True)}}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:42'),
(1545,NULL,'login_failed','User',NULL,'{\"email\":\"<%=%x(sleep 15)%>\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:42'),
(1546,NULL,'login_failed','User',NULL,'{\"email\":\"#{%x(sleep 15)}\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:42'),
(1547,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:43'),
(1548,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:43'),
(1549,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:43'),
(1550,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:43'),
(1551,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:44'),
(1552,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:44'),
(1553,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\"|timeout \\/T 15.0\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:45'),
(1554,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\'&timeout \\/T 15.0&\'\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:45'),
(1555,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\'|timeout \\/T 15.0\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:45'),
(1556,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com;start-sleep -s 15.0\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:45'),
(1557,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\\\";start-sleep -s 15.0\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:45'),
(1558,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com\';start-sleep -s 15.0\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:45'),
(1559,NULL,'login_failed','User',NULL,'{\"email\":\"zaproxy@example.com;start-sleep -s 15.0 #\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:45'),
(1560,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:46'),
(1561,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:46'),
(1562,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:46'),
(1563,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:46'),
(1564,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:46'),
(1565,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:46'),
(1566,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:51'),
(1567,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:51'),
(1568,NULL,'login_failed','User',NULL,'{\"email\":\"ZAP %1!s%2!s%3!s%4!s%5!s%6!s%7!s%8!s%9!s%10!s%11!s%12!s%13!s%14!s%15!s%16!s%17!s%18!s%19!s%20!s%21!n%22!n%23!n%24!n%25!n%26!n%27!n%28!n%29!n%30!n%31!n%32!n%33!n%34!n%35!n%36!n%37!n%38!n%39!n%40!n\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:52'),
(1569,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:52'),
(1570,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:52'),
(1571,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:52'),
(1572,NULL,'login_failed','User',NULL,'{\"email\":\"Set-cookie: Tamper=03e80d31-460b-4c14-9fbb-f891961d83e7\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1573,NULL,'login_failed','User',NULL,'{\"email\":\"any?\\r\\nSet-cookie: Tamper=03e80d31-460b-4c14-9fbb-f891961d83e7\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1574,NULL,'login_failed','User',NULL,'{\"email\":\"any\\r\\nSet-cookie: Tamper=03e80d31-460b-4c14-9fbb-f891961d83e7\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1575,NULL,'login_failed','User',NULL,'{\"email\":\"any?\\r\\nSet-cookie: Tamper=03e80d31-460b-4c14-9fbb-f891961d83e7\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1576,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1577,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1578,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1579,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:53'),
(1580,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:54'),
(1581,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:54'),
(1582,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:55'),
(1583,NULL,'login_failed','User',NULL,'{\"email\":\"@\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:55'),
(1584,NULL,'login_failed','User',NULL,'{\"email\":\"+\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:55'),
(1585,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:56'),
(1586,NULL,'login_locked','User',74,'{\"locked_until\":\"2026-07-27 14:49:49\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:56'),
(1587,NULL,'login_failed','User',NULL,'{\"email\":\"<xsl:value-of select=\\\"system-property(\'xsl:vendor\')\\\"\\/><!--\"}',NULL,'192.168.117.139','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','2026-07-27 12:38:58'),
(1588,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:48:16'),
(1589,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:48:18'),
(1590,1,'close','Report',46,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:49:09'),
(1591,1,'close','Report',38,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:49:14'),
(1592,1,'close','Report',21,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:49:22'),
(1593,1,'redirect','Report',21,'{\"organization_id\":2}','{\"organization_id\":2}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 12:59:03'),
(1594,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 13:49:24'),
(1595,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 13:49:26'),
(1596,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:04:45'),
(1597,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:04:47'),
(1598,1,'status_change','Report',48,NULL,'{\"status\":\"rejected\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:13:01'),
(1599,1,'status_change','Report',48,NULL,'{\"status\":\"closed\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:13:06'),
(1600,1,'status_change','Report',48,NULL,'{\"status\":\"rejected\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:37:59'),
(1601,1,'status_change','Report',48,NULL,'{\"status\":\"closed\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:38:05'),
(1602,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:38:25'),
(1603,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:38:27'),
(1604,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:51:00'),
(1605,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:51:04'),
(1606,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:51:33'),
(1607,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:51:51'),
(1608,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:52:00'),
(1609,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:52:02'),
(1610,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:52:07'),
(1611,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:52:09'),
(1612,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:53:43'),
(1613,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:56:35'),
(1614,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1 Edg/150.0.0.0','2026-07-27 14:57:45'),
(1615,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:58:55'),
(1616,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 14:59:05'),
(1617,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:07:02'),
(1618,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:07:38'),
(1619,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:08:57'),
(1620,NULL,'login_failed','User',NULL,'{\"email\":\"raouf@gmail.com\"}',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:09:52'),
(1621,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:10:28'),
(1622,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:10:53'),
(1623,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:11:01'),
(1624,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 15:11:48'),
(1625,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:10:01'),
(1626,1,'create','Report',49,NULL,'{\"tracking_code\":\"BA-2026-883633\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:13:59'),
(1627,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:16:21'),
(1628,NULL,'register','User',75,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:17:00'),
(1629,75,'login','User',75,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:17:06'),
(1630,75,'create','Report',50,NULL,'{\"tracking_code\":\"BA-2026-722710\",\"organization_id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:21:21'),
(1631,75,'logout','User',75,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:22:35'),
(1632,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:23:00'),
(1633,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:26:58'),
(1634,75,'login','User',75,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:28:22'),
(1635,75,'logout','User',75,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 17:30:50'),
(1636,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 18:14:23'),
(1637,1,'update','Settings',NULL,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-27 18:18:53'),
(1638,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 09:17:22'),
(1639,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 09:28:15'),
(1640,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 09:33:53'),
(1641,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 09:34:06'),
(1642,1,'login','User',1,NULL,NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-28 09:56:21'),
(1643,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 09:57:02'),
(1644,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-28 10:00:33'),
(1645,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-28 10:07:05'),
(1646,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-28 10:08:37'),
(1647,1,'login','User',1,NULL,NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-07-28 10:09:12'),
(1648,1,'login','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 10:27:20'),
(1649,1,'logout','User',1,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 10:28:21'),
(1650,45,'login','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 10:28:28'),
(1651,45,'logout','User',45,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 10:28:45'),
(1652,NULL,'register','User',76,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 10:30:42'),
(1653,76,'login','User',76,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 10:30:50'),
(1654,76,'logout','User',76,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 10:33:01'),
(1655,1,'login','User',1,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 10:33:09'),
(1656,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 10:49:35'),
(1657,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 10:49:38'),
(1658,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 11:24:51'),
(1659,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 11:24:54'),
(1660,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-28 11:36:34'),
(1661,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:08:34'),
(1662,3,'login','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:08:39'),
(1663,3,'logout','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:09:17'),
(1664,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:09:19'),
(1665,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:20:37'),
(1666,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:21:05'),
(1667,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:22:37'),
(1668,1,'logout','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:25:32'),
(1669,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:25:42'),
(1670,1,'logout','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:25:47'),
(1671,NULL,'login_failed','User',NULL,'{\"email\":\"hamza132@gmail.com\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:26:13'),
(1672,NULL,'login_failed','User',NULL,'{\"email\":\"hamza132@gmail.com\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:26:23'),
(1673,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:26:25'),
(1674,1,'update','User',51,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:27:02'),
(1675,1,'logout','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:27:06'),
(1676,NULL,'login_failed','User',NULL,'{\"email\":\"hamza132@gmail.com\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:27:18'),
(1677,NULL,'login_failed','User',NULL,'{\"email\":\"hamza132@gmail.com\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:27:48'),
(1678,NULL,'register','User',77,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:28:12'),
(1679,77,'login','User',77,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 12:28:28'),
(1680,1,'update_profile','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:35:14'),
(1681,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:39:12'),
(1682,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 12:59:20'),
(1683,1,'delete','User',77,NULL,NULL,'::1','curl/8.20.0','2026-07-28 13:10:23'),
(1684,1,'delete','User',77,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 13:10:24'),
(1685,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 14:16:35'),
(1686,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 14:28:22'),
(1687,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 14:42:01'),
(1688,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 14:59:05'),
(1689,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-28 14:59:06'),
(1690,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh.dz\"}',NULL,'::1','curl/8.20.0','2026-07-28 14:59:57'),
(1691,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh.dz\"}',NULL,'::1','curl/8.20.0','2026-07-28 15:00:59'),
(1692,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-28 15:02:45'),
(1693,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-28 15:03:38'),
(1694,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-28 15:03:55'),
(1695,1,'login','User',1,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-28 15:06:38'),
(1696,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 09:07:57'),
(1697,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-29 09:10:35'),
(1698,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 09:18:31'),
(1699,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 09:18:51'),
(1700,1,'login','User',1,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-29 09:19:43'),
(1701,NULL,'login_failed','User',NULL,'{\"email\":\"balagh_Alger16@gmail.dz\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-29 09:21:27'),
(1702,NULL,'login_failed','User',NULL,'{\"email\":\"balagh_Alger16@gmail.dz\"}',NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-29 09:22:39'),
(1703,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-29 09:23:39'),
(1704,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:03:11'),
(1705,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:03:14'),
(1706,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:03:26'),
(1707,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:04:05'),
(1708,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:04:40'),
(1709,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:04:42'),
(1710,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:04:57'),
(1711,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 10:05:00'),
(1712,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-29 12:27:06'),
(1713,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:27:37'),
(1714,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:27:40'),
(1715,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-29 12:31:12'),
(1716,45,'create','Report',51,NULL,'{\"tracking_code\":\"BA-2026-566906\",\"organization_id\":1}','192.168.117.61','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-29 12:34:37'),
(1717,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:35:38'),
(1718,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:35:41'),
(1719,1,'redirect','Report',51,'{\"organization_id\":1}','{\"organization_id\":2}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:36:07'),
(1720,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:36:25'),
(1721,10,'login','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:36:32'),
(1722,10,'assign','Report',51,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:36:49'),
(1723,10,'status_change','Report',51,NULL,'{\"status\":\"assigned\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:36:52'),
(1724,10,'logout','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:37:11'),
(1725,11,'login','User',11,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:37:16'),
(1726,11,'assign','Report',51,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:37:30'),
(1727,11,'logout','User',11,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:37:59'),
(1728,3,'login','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:38:04'),
(1729,3,'assign','Report',51,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:38:19'),
(1730,3,'logout','User',3,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:39:31'),
(1731,5,'login','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:39:37'),
(1732,5,'logout','User',5,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:39:50'),
(1733,10,'login','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:39:52'),
(1734,10,'logout','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:40:14'),
(1735,4,'login','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:40:20'),
(1736,4,'logout','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:40:26'),
(1737,10,'login','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:40:29'),
(1738,10,'logout','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:40:47'),
(1739,13,'login','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:40:52'),
(1740,13,'logout','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:42:17'),
(1741,10,'login','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:42:20'),
(1742,10,'status_change','Report',51,NULL,'{\"status\":\"resolved\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:42:27'),
(1743,10,'status_change','Report',7,NULL,'{\"status\":\"resolved\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:42:40'),
(1744,10,'logout','User',10,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:42:49'),
(1745,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:42:51'),
(1746,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:46:48'),
(1747,9,'login','User',9,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:46:55'),
(1748,9,'logout','User',9,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:47:10'),
(1749,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:47:19'),
(1750,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:47:33'),
(1751,47,'login','User',47,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:47:39'),
(1752,47,'status_change','Report',31,NULL,'{\"status\":\"closed\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:47:54'),
(1753,47,'logout','User',47,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:49:47'),
(1754,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:49:52'),
(1755,1,'close','Report',51,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:50:20'),
(1756,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:55:48'),
(1757,4,'login','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:56:03'),
(1758,4,'logout','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:56:26'),
(1759,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:56:28'),
(1760,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:56:53'),
(1761,13,'login','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 12:57:00'),
(1762,13,'logout','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:10:20'),
(1763,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:10:27'),
(1764,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:13:53'),
(1765,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:13:56'),
(1766,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:19:21'),
(1767,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:19:23'),
(1768,45,'status_change','Report',30,NULL,'{\"status\":\"closed\"}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:20:56'),
(1769,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-29 13:24:40'),
(1770,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:26:11'),
(1771,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:26:13'),
(1772,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:54:57'),
(1773,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 13:54:59'),
(1774,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:52:51'),
(1775,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:52:53'),
(1776,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:53:43'),
(1777,13,'login','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:53:49'),
(1778,13,'logout','User',13,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:55:12'),
(1779,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:55:14'),
(1780,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:55:47'),
(1781,4,'login','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:55:51'),
(1782,4,'logout','User',4,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:56:02'),
(1783,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:56:05'),
(1784,1,'login','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 14:59:54'),
(1785,1,'status_change','Report',46,NULL,'{\"status\":\"resolved\"}','192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:00:59'),
(1786,1,'status_change','Report',46,NULL,'{\"status\":\"closed\"}','192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:01:10'),
(1787,1,'logout','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:01:53'),
(1788,45,'login','User',45,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:02:01'),
(1789,45,'logout','User',45,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:02:41'),
(1790,NULL,'register','User',78,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:03:06'),
(1791,78,'login','User',78,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:03:11'),
(1792,78,'create','Report',52,NULL,'{\"tracking_code\":\"BA-2026-352767\",\"organization_id\":2}','192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:05:21'),
(1793,78,'logout','User',78,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:06:08'),
(1794,1,'login','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:06:16'),
(1795,1,'logout','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:06:38'),
(1796,10,'login','User',10,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:06:43'),
(1797,10,'assign','Report',52,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:06:55'),
(1798,10,'logout','User',10,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:07:14'),
(1799,60,'login','User',60,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:07:19'),
(1800,60,'assign_commune','SectionCommune',NULL,NULL,'{\"user_id\":59,\"commune_id\":56}','192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:07:33'),
(1801,60,'logout','User',60,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:07:43'),
(1802,1,'login','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:07:51'),
(1803,1,'assign','Report',52,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:08:44'),
(1804,1,'logout','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:08:57'),
(1805,11,'login','User',11,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:09:02'),
(1806,11,'assign','Report',52,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:09:35'),
(1807,11,'logout','User',11,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:09:44'),
(1808,3,'login','User',3,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:09:51'),
(1809,3,'assign','Report',52,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:10:01'),
(1810,3,'status_change','Report',52,NULL,'{\"status\":\"in_progress\"}','192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:10:06'),
(1811,3,'logout','User',3,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:10:17'),
(1812,4,'login','User',4,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:10:22'),
(1813,4,'logout','User',4,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:11:29'),
(1814,NULL,'login_failed','User',NULL,'{\"email\":\"admin@balagh-alger.dz\"}',NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:11:38'),
(1815,1,'login','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:11:46'),
(1816,1,'logout','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:12:18'),
(1817,11,'login','User',11,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:12:23'),
(1818,11,'logout','User',11,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:13:00'),
(1819,10,'login','User',10,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:13:04'),
(1820,10,'logout','User',10,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:13:35'),
(1821,3,'login','User',3,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:13:40'),
(1822,3,'logout','User',3,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:14:14'),
(1823,1,'login','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:14:23'),
(1824,1,'login','User',1,NULL,NULL,'192.168.117.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-29 15:14:33'),
(1825,1,'logout','User',1,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:15:11'),
(1826,11,'login','User',11,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:15:15'),
(1827,11,'logout','User',11,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:15:55'),
(1828,78,'login','User',78,NULL,NULL,'192.168.117.144','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-29 15:16:00'),
(1829,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 06:20:35'),
(1830,NULL,'register','User',79,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:25:56'),
(1831,79,'login','User',79,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:26:09'),
(1832,79,'create','Report',53,NULL,'{\"tracking_code\":\"BA-2026-917563\",\"organization_id\":2}','::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:30:00'),
(1833,79,'create','Report',54,NULL,'{\"tracking_code\":\"BA-2026-256470\",\"organization_id\":2}','::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:30:02'),
(1834,79,'create','Report',55,NULL,'{\"tracking_code\":\"BA-2026-370991\",\"organization_id\":2}','::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:30:04'),
(1835,79,'create','Report',56,NULL,'{\"tracking_code\":\"BA-2026-970973\",\"organization_id\":2}','::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:30:13'),
(1836,79,'create','Report',57,NULL,'{\"tracking_code\":\"BA-2026-635118\",\"organization_id\":2}','::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:30:15'),
(1837,79,'create','Report',58,NULL,'{\"tracking_code\":\"BA-2026-151501\",\"organization_id\":2}','::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 06:30:15'),
(1838,1,'delete','Report',58,'{\"tracking_code\":\"BA-2026-151501\"}',NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 06:47:53'),
(1839,1,'delete','Report',57,'{\"tracking_code\":\"BA-2026-635118\"}',NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 06:47:57'),
(1840,1,'delete','Report',56,'{\"tracking_code\":\"BA-2026-970973\"}',NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 06:48:01'),
(1841,1,'delete','Report',55,'{\"tracking_code\":\"BA-2026-370991\"}',NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 06:48:06'),
(1842,1,'delete','Report',54,'{\"tracking_code\":\"BA-2026-256470\"}',NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 06:48:09'),
(1843,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:10:46'),
(1844,45,'login','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:10:48'),
(1845,45,'logout','User',45,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:19:26'),
(1846,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:19:29'),
(1847,1,'update','LandingBeforeAfter',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:30:05'),
(1848,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:30:11'),
(1849,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:34:39'),
(1850,1,'update','LandingSettings',0,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:35:41'),
(1851,1,'update','LandingSettings',0,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:35:49'),
(1852,1,'logout','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:35:52'),
(1853,1,'login','User',1,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:36:16'),
(1854,1,'update','LandingSettings',0,NULL,NULL,'192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 07:36:38'),
(1855,79,'login','User',79,NULL,NULL,'::1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','2026-07-30 07:40:16'),
(1856,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-30 07:43:45'),
(1857,1,'update','RolePermissions',7,NULL,'{\"permissions\":[\"22\",\"20\",\"21\",\"25\",\"24\",\"43\",\"29\",\"30\",\"16\",\"18\",\"2\",\"31\",\"8\",\"3\",\"32\",\"9\",\"5\",\"6\",\"34\",\"1\",\"7\",\"26\",\"13\",\"14\",\"33\",\"15\",\"11\",\"12\"]}','::1','curl/8.20.0','2026-07-30 07:44:04'),
(1858,1,'login','User',1,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-30 07:54:14'),
(1859,1,'logout','User',1,NULL,NULL,'192.168.117.56','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-30 07:56:13'),
(1860,1,'update','RolePermissions',1,NULL,'{\"permissions\":[\"24\",\"29\",\"2\",\"10\"]}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 08:09:45'),
(1861,1,'update','RolePermissions',1,NULL,'{\"permissions\":[\"24\",\"29\",\"7\",\"2\",\"10\"]}','192.168.117.200','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0','2026-07-30 08:10:23'),
(1862,1,'login','User',1,NULL,NULL,'::1','curl/8.20.0','2026-07-30 08:11:11');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `icon` varchar(50) DEFAULT 'fas fa-exclamation-triangle',
  `color` varchar(7) DEFAULT '#3a7bd5',
  `description` text DEFAULT NULL,
  `deadline_days` int(10) unsigned DEFAULT 7,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `organization_id` (`organization_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,1,'نفايات منزلية','نفايات منزلية','nefayat-managiya','fas fa-trash','#6c757d',NULL,7,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(2,1,'عملية الكنس','عملية الكنس','amaliyat-alkans','fas fa-broom','#6c757d',NULL,7,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(3,1,'حاويات القمامة','حاويات القمامة','hawiyat-alqamama','fas fa-dumpster','#6c757d',NULL,7,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(4,1,'سلات المهملات','سلات المهملات','salat-almahmalat','fas fa-trash-alt','#6c757d',NULL,7,1,4,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(5,1,'مخلفات بحرية','مخلفات بحرية','makhalfat-bahariya','fas fa-water','#6c757d',NULL,7,1,5,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(6,1,'نفايات خضراء','نفايات خضراء','nefayat-khadraa','fas fa-leaf','#6c757d',NULL,7,1,6,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(7,2,'النفايات الصلبة','النفايات الصلبة','alnefayat-alsaliba','fas fa-recycle','#28a745',NULL,10,1,7,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(8,2,'نفايات مختلطة','نفايات مختلطة','nefayat-mukhtalita','fas fa-trash-restore','#28a745',NULL,10,1,8,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(9,2,'البالوعات','البالوعات','albalawat','fas fa-grip-lines','#28a745',NULL,10,1,9,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(10,2,'تسرب المياه الصالحة للشرب','تسرب المياه الصالحة للشرب','tasarrub-miyah-sharba','fas fa-tint','#28a745',NULL,10,1,10,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(11,2,'تسرب مياه الصرف الصحي','تسرب مياه الصرف الصحي','tasarrub-miyah-sayf','fas fa-water','#28a745',NULL,10,1,11,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(12,2,'أغطية قنوات الصرف الصحي','أغطية قنوات الصرف الصحي','aghtiyat-qanawat','fas fa-circle','#28a745',NULL,10,1,12,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(13,2,'خزان الصرف الصحي','خزان الصرف الصحي','khazan-alkanati','fas fa-fill-drip','#28a745',NULL,10,1,13,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(14,2,'ركود المياه','ركود المياه','rukud-almiyah','fas fa-tint-slash','#28a745',NULL,10,1,14,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(15,2,'أرصفة','أرصفة','arasefa','fas fa-walking','#28a745',NULL,10,1,15,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(16,2,'الطريق','الطريق','altarik','fas fa-road','#28a745',NULL,10,1,16,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(17,2,'حواجز إسمنتية','حواجز إسمنتية','hawajiz-isamentiya','fas fa-university','#28a745',NULL,10,1,17,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(18,2,'أقبية الأسلاك الهاتفية','أقبية الأسلاك الهاتفية','aqabiya-aslak','fas fa-phone-slash','#28a745',NULL,10,1,18,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(19,4,'الإنارة العمومية','الإنارة العمومية','alenera-aloumoumiya','fas fa-lightbulb','#ffc107',NULL,15,1,19,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(20,4,'الساعات','الساعات','alsaat','fas fa-clock','#ffc107',NULL,15,1,20,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(21,4,'الساعات العامة','الساعات العامة','alsaat-alamma','fas fa-business-time','#ffc107',NULL,15,1,21,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(22,4,'حالة الأعمدة الكهربائية','حالة الأعمدة الكهربائية','halat-alamdah','fas fa-bolt','#ffc107',NULL,15,1,22,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(23,15,'نقص في العناية بالمساحة الخضراء','نقص في العناية بالمساحة الخضراء','naqs-enaya-fadaa','fas fa-seedling','#20c997',NULL,7,1,23,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(24,15,'العناية بالأشجار','العناية بالأشجار','enaya-bilashjar','fas fa-tree','#20c997',NULL,7,1,24,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(25,15,'حشائش ضارة','حشائش ضارة','hashaish-darra','fas fa-leaf','#20c997',NULL,7,1,25,'2026-07-22 10:35:11','2026-07-22 10:50:32'),
(26,15,'إنهيار صخري','إنهيار صخري','inihar-sakhri','fas fa-mountain','#20c997',NULL,7,1,26,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(27,15,'زحف الرمال','زحف الرمال','zahaf-arlamal','fas fa-wind','#20c997',NULL,7,1,27,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(28,15,'إنجراف التربة','إنجراف التربة','injiraf-alturba','fas fa-landmark','#20c997',NULL,7,1,28,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(29,15,'المنحدرات','المنحدرات','almanahid','fas fa-angle-double-down','#20c997',NULL,7,1,29,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(30,6,'الإشارات العمومية','الإشارات العمومية','alisharat-aloumoumiya','fas fa-sign','#17a2b8',NULL,7,1,30,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(31,6,'الإشارات الأفقية','الإشارات الأفقية','alisharat-alufuqiya','fas fa-arrows-alt-h','#17a2b8',NULL,7,1,31,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(32,6,'واقيات مواقف الحافلات','واقيات مواقف الحافلات','waqiyat-mawaqif','fas fa-bus','#17a2b8',NULL,7,1,32,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(33,6,'حواجز حديدية','حواجز حديدية','hawajiz-hadidiya','fas fa-border-all','#17a2b8',NULL,7,1,33,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(34,6,'جسر المشاة','جسر المشاة','jasr-almoshaa','fas fa-walking','#17a2b8',NULL,7,1,34,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(35,6,'مدخل الموقف','مدخل الموقف','madkhal-almauqif','fas fa-door-open','#17a2b8',NULL,7,1,35,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(36,6,'موقف سيارات','موقف سيارات','mauqif-sayarat','fas fa-parking','#17a2b8',NULL,7,1,36,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(37,6,'محطة حضرية','محطة حضرية','mahatta-hadariya','fas fa-city','#17a2b8',NULL,7,1,37,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(38,6,'مواقف الحافلات','مواقف الحافلات','mawaqif-alhafilat','fas fa-bus-alt','#17a2b8',NULL,7,1,38,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(39,6,'أشغال طور الإنجاز','أشغال طور الإنجاز','ashghal-tour-injaz','fas fa-hard-hat','#17a2b8',NULL,7,1,39,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(40,5,'الرايات الوطنية','الرايات الوطنية','alriyat-alwataniya','fas fa-flag','#e83e8c',NULL,7,1,40,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(41,5,'نافورات المياه','نافورات المياه','nafurat-almiyah','fas fa-faucet','#e83e8c',NULL,7,1,41,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(42,5,'مقصورات','مقصورات','maqaswarat','fas fa-store','#e83e8c',NULL,7,1,42,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(43,5,'النافورات العمومية','النافورات العمومية','alnafurat-aloumoumiya','fas fa-tint','#e83e8c',NULL,7,1,43,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(44,9,'سيارات مهترئة','سيارات مهترئة','sayarat-muhtari-a','fas fa-car-crash','#fd7e14',NULL,7,1,44,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(45,9,'الإستغلال الغير قانوني للطريق العام','الإستغلال الغير قانوني للطريق العام','istighlal-hair-qanuni','fas fa-ban','#fd7e14',NULL,7,1,45,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(46,9,'الإستغلال الغير قانوني للشواطئ','الإستغلال الغير قانوني للشواطئ','istighlal-shawati','fas fa-umbrella-beach','#fd7e14',NULL,7,1,46,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(47,9,'واجهات المباني','واجهات المباني','wajihat-almaabani','fas fa-building','#fd7e14',NULL,7,1,47,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(48,9,'بناية مهدمة','بناية مهدمة','binaya-muhadama','fas fa-home','#fd7e14',NULL,7,1,48,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(49,9,'حالة المصاعد','حالة المصاعد','halat-almasaad','fas fa-arrow-up','#fd7e14',NULL,7,1,49,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(50,9,'الملاعب الجوارية','الملاعب الجوارية','almalab-aljawariya','fas fa-futbol','#fd7e14',NULL,7,1,50,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(51,9,'بيوت قصديرية','بيوت قصديرية','buyut-qasdiriya','fas fa-home','#fd7e14',NULL,7,1,51,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(52,9,'فضاء التسلية','فضاء التسلية','fadaa-altasliya','fas fa-child','#fd7e14',NULL,7,1,52,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(53,9,'أقبية','أقبية','aqabiya','fas fa-warehouse','#fd7e14',NULL,7,1,53,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(54,9,'لوحات إشهارية','لوحات إشهارية','lawhat-ishhariya','fas fa-sign','#fd7e14',NULL,7,1,54,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(55,9,'حالة السلالم والأدراج','حالة السلالم والأدراج','halat-alsalalim','fas fa-stairs','#fd7e14',NULL,7,1,55,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(56,9,'الدعامات','الدعامات','alddaam','fas fa-drafting-compass','#fd7e14',NULL,7,1,56,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(57,9,'لافتات إشهارية','لافتات إشهارية','lafihat-ishhariya','fas fa-ad','#fd7e14',NULL,7,1,57,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(58,3,'لافتات','لافتات','lafihat','fas fa-umbrella-beach','#007bff',NULL,7,1,58,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(59,3,'حيوانات ضالة','حيوانات ضالة','hayawanat-dala','fas fa-paw','#007bff',NULL,7,1,59,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(60,3,'قوارب الصيد','قوارب الصيد','qawarib-alsayd','fas fa-ship','#007bff',NULL,7,1,60,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(61,3,'وضعية القبور','وضعية القبور','wadiyyat-alqubur','fas fa-monument','#007bff',NULL,7,1,61,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(62,11,'أودية','أودية','awdiya','fas fa-water','#6610f2',NULL,10,1,62,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(63,11,'الينابيع','الينابيع','alyanabi','fas fa-spa','#6610f2',NULL,7,1,63,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(64,11,'مرشات','مرشات','mrashshat','fas fa-shower','#6610f2',NULL,7,1,64,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(65,11,'عمود أسلاك الهاتف','عمود أسلاك الهاتف','amud-aslak-hatif','fas fa-phone','#6610f2',NULL,15,1,65,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(66,11,'صخور متدلية','صخور متدلية','sukhur-mutadalliya','fas fa-mountain','#6610f2',NULL,7,1,66,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(67,10,'طريق سريع','طريق سريع','tarik-sari','fas fa-highway','#343a40',NULL,10,1,67,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(68,18,'مقبرة','مقبرة','maqbara','fas fa-headstone','#6f42c1',NULL,7,1,68,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(69,13,'خزان المياه','خزان المياه','khazan-almiyah','fas fa-database','#20c997',NULL,7,1,69,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(70,NULL,'أخرى','أخرى','ukhra','fas fa-question-circle','#adb5bd',NULL,7,1,70,'2026-07-22 10:34:10','2026-07-22 10:50:32');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `citizen_points`
--

DROP TABLE IF EXISTS `citizen_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `citizen_points` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `points` int(10) unsigned NOT NULL DEFAULT 0,
  `reason` varchar(100) NOT NULL,
  `reference_id` int(10) unsigned DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizen_points`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `citizen_points` WRITE;
/*!40000 ALTER TABLE `citizen_points` DISABLE KEYS */;
INSERT INTO `citizen_points` VALUES
(1,45,5,'post_created',1,'post','2026-07-23 12:53:18'),
(2,73,5,'post_created',2,'post','2026-07-26 16:41:03'),
(3,45,25,'report_resolved',51,'report','2026-07-29 14:42:27'),
(4,9,25,'report_resolved',7,'report','2026-07-29 14:42:40'),
(5,1,25,'report_resolved',46,'report','2026-07-29 17:00:59');
/*!40000 ALTER TABLE `citizen_points` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `communes`
--

DROP TABLE IF EXISTS `communes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `communes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `daira_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `daira_id` (`daira_id`),
  CONSTRAINT `communes_ibfk_1` FOREIGN KEY (`daira_id`) REFERENCES `dairas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `communes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `communes` WRITE;
/*!40000 ALTER TABLE `communes` DISABLE KEYS */;
INSERT INTO `communes` VALUES
(1,1,'Bab El Oued','باب الوادي','C160101','16000',36.7918000,3.0514000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(2,1,'Casbah','القصبة','C160102','16001',36.7833000,3.0500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(3,1,'Bologhine','بولوغين','C160103','16005',36.7833000,3.0333000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(4,1,'Oued Koriche','وادي قريش','C160104','16002',36.7833000,3.0333000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(5,1,'Raïs Hamidou','ريس حميدو','C160105','16003',36.7667000,3.0333000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(6,2,'Baraki','براقي','C160201','16200',36.6683000,3.1080000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(7,2,'Les Eucalyptus','الكاليتوس','C160202','16202',36.6667000,3.1000000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(8,2,'Sidi Moussa','سيدي موسى','C160203','16201',36.6500000,3.1167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(9,3,'Bir Mourad Raïs','بئر مراد رايس','C160301','16300',36.7406000,3.0499000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(10,3,'Birkhadem','بئر خادم','C160302','16302',36.7167000,3.0500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(11,3,'Gué de Constantine','معبر قسنطينة','C160303','16301',36.7333000,3.0833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(12,3,'Hydra','حيدرة','C160304','16303',36.7500000,3.0500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(13,3,'Saoula','السولة','C160305','16304',36.7167000,3.0167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(14,4,'Birtouta','بئرتوتة','C160401','16400',36.7179000,2.9936000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(15,4,'Ouled Chebel','أولاد شبل','C160402','16401',36.7333000,2.9500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(16,4,'Tessala El Merdja','تسالة المرجة','C160403','16402',36.7000000,3.0167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(17,5,'Ben Aknoun','بن عكنون','C160501','16305',36.7667000,3.0000000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(18,5,'Beni Messous','بني مسعود','C160502','16306',36.7833000,2.9833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(19,5,'Bouzareah','بوزريعة','C160503','16340',36.7808000,3.0111000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(20,5,'El Biar','البيار','C160504','16032',36.7667000,3.0167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(21,6,'Aïn Benian','عين البنيان','C160601','16500',36.8000000,2.9167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(22,6,'Chéraga','الشراقة','C160602','16002',36.7653000,2.9575000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(23,6,'Dely Ibrahim','دالي إبراهيم','C160603','16320',36.7500000,2.9833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(24,6,'Ouled Fayet','أولاد فايت','C160604','16003',36.7500000,2.9333000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(25,6,'El Hammamet','الحمامات','C160605','16004',36.7667000,2.9167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(26,7,'Aïn Taya','عين الطاية','C160701','16200',36.7833000,3.2333000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(27,7,'Bab Ezzouar','باب الزوار','C160702','16028',36.7250000,3.1833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(28,7,'Bordj El Bahri','برج البحرى','C160703','16029',36.7833000,3.2167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(29,7,'Bordj El Kiffan','برج الكيفان','C160704','16006',36.7500000,3.2000000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(30,7,'Dar El Beïda','الدار البيضاء','C160705','16230',36.7150000,3.2506000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(31,7,'El Marsa','المرسى','C160706','16007',36.7667000,3.2667000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(32,7,'Mohammadia','المحمدية','C160707','16008',36.7333000,3.1500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(33,8,'Baba Hassen','بابا حسن','C160801','16009',36.7167000,2.9667000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(34,8,'Douera','الدورة','C160802','16051',36.7000000,2.9500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(35,8,'Draria','دراية','C160803','16052',36.7286000,2.9972000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(36,8,'El Achour','العشور','C160804','16053',36.7333000,2.9667000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(37,8,'Khraïssia','الخرايسية','C160805','16054',36.7167000,2.9500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(38,9,'Bach Djerrah','باش جراح','C160901','16204',36.7167000,3.1000000,1,'2026-07-16 08:43:05','2026-07-20 11:46:01'),
(39,9,'Bourouba','بوروابة','C160902','16205',36.7167000,3.1167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(40,9,'El Harrach','الحراش','C160903','16200',36.7183000,3.1349000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(41,9,'Oued Smar','وادي السمار','C160904','16000',36.7167000,3.1500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(42,10,'Belouizdad','بولوغين','C161001','16032',36.7500000,3.0833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(43,10,'El Magharia','المقرية','C161002','16006',36.7333000,3.1000000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(44,10,'Hussein Dey','حسين داي','C161003','16005',36.7447000,3.1008000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(45,10,'Kouba','القبة','C161004','16072',36.7333000,3.0833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(46,11,'H\'raoua','العروة','C161101','16050',36.7333000,3.3167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(47,11,'Reghaïa','الرغاية','C161102','16051',36.7333000,3.3333000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(48,11,'Rouïba','الرويبة','C161103','16052',36.7333000,3.2833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(49,12,'Alger-Centre','الجزائر الوسطى','C161201','16000',36.7538000,3.0588000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(50,12,'El Madania','المدنية','C161202','16002',36.7500000,3.0500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(51,12,'El Mouradia','المoria','C161203','16003',36.7500000,3.0500000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(52,12,'Sidi M\'Hamed','سيدي أمحمد','C161204','16004',36.7525000,3.0517000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(53,13,'Mahelma','ماحلمة','C161301','16053',36.7000000,2.9167000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(54,13,'Rahmania','الرحمنية','C161302','16054',36.6833000,2.9000000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(55,13,'Souidania','السونيدانية','C161303','16055',36.7167000,2.8833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(56,13,'Staoueli','الستاوالي','C161304','16007',36.7333000,2.8667000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41'),
(57,13,'Zéralda','زرالدة','C161305','16056',36.7117000,2.9431000,1,'2026-07-16 08:43:05','2026-07-16 08:43:41');
/*!40000 ALTER TABLE `communes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `community_comments`
--

DROP TABLE IF EXISTS `community_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_post` (`post_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `fk_comment_post` FOREIGN KEY (`post_id`) REFERENCES `community_posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_comments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `community_comments` WRITE;
/*!40000 ALTER TABLE `community_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_comments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `community_likes`
--

DROP TABLE IF EXISTS `community_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_likes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_post` (`user_id`,`post_id`),
  KEY `idx_post` (`post_id`),
  CONSTRAINT `fk_like_post` FOREIGN KEY (`post_id`) REFERENCES `community_posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_likes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `community_likes` WRITE;
/*!40000 ALTER TABLE `community_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_likes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `community_photos`
--

DROP TABLE IF EXISTS `community_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(50) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `sort_order` tinyint(4) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_post` (`post_id`),
  CONSTRAINT `fk_photo_post` FOREIGN KEY (`post_id`) REFERENCES `community_posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_photos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `community_photos` WRITE;
/*!40000 ALTER TABLE `community_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_photos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `community_posts`
--

DROP TABLE IF EXISTS `community_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  `post_type` enum('discussion','update','question') DEFAULT 'discussion',
  `report_id` int(10) unsigned DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `is_anonymous` tinyint(1) DEFAULT 0,
  `likes_count` int(10) unsigned DEFAULT 0,
  `comments_count` int(10) unsigned DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_type` (`post_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_posts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `community_posts` WRITE;
/*!40000 ALTER TABLE `community_posts` DISABLE KEYS */;
INSERT INTO `community_posts` VALUES
(1,45,'ss','ss','discussion',NULL,NULL,NULL,0,0,0,'2026-07-23 12:53:18','2026-07-23 12:53:18',NULL),
(2,73,'Hola im new','Hola im new','discussion',NULL,NULL,NULL,0,0,0,'2026-07-26 16:41:03','2026-07-26 16:41:03',NULL);
/*!40000 ALTER TABLE `community_posts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `dairas`
--

DROP TABLE IF EXISTS `dairas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dairas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `wilaya_code` varchar(10) NOT NULL DEFAULT '16',
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dairas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `dairas` WRITE;
/*!40000 ALTER TABLE `dairas` DISABLE KEYS */;
INSERT INTO `dairas` VALUES
(1,'Bab El Oued','باب الوادي','D1601','16',36.7918000,3.0514000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(2,'Baraki','براقي','D1602','16',36.6683000,3.1080000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(3,'Bir Mourad Raïs','بئر مراد رايس','D1603','16',36.7406000,3.0499000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(4,'Birtouta','بئرتوتة','D1604','16',36.7179000,2.9936000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(5,'Bouzareah','بوزريعة','D1605','16',36.7808000,3.0111000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(6,'Chéraga','الشراقة','D1606','16',36.7653000,2.9575000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(7,'Dar El Beïda','الدار البيضاء','D1607','16',36.7150000,3.2506000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(8,'Draria','دراية','D1608','16',36.7286000,2.9972000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(9,'El Harrach','الحراش','D1609','16',36.7183000,3.1349000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(10,'Hussein Dey','حسين داي','D1610','16',36.7447000,3.1008000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(11,'Rouïba','الرويبة','D1611','16',36.7333000,3.2833000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(12,'Sidi M\'Hamed','سيدي أمحمد','D1612','16',36.7525000,3.0517000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28'),
(13,'Zéralda','زرالدة','D1613','16',36.7117000,2.9431000,1,'2026-07-16 08:43:05','2026-07-16 08:43:28');
/*!40000 ALTER TABLE `dairas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `intervention_photos`
--

DROP TABLE IF EXISTS `intervention_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `intervention_photos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `intervention_id` bigint(20) unsigned NOT NULL,
  `report_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `photo_type` enum('before','during','after') NOT NULL DEFAULT 'before',
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `intervention_id` (`intervention_id`),
  KEY `report_id` (`report_id`),
  KEY `uploaded_by` (`uploaded_by`),
  CONSTRAINT `intervention_photos_ibfk_1` FOREIGN KEY (`intervention_id`) REFERENCES `report_interventions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `intervention_photos_ibfk_2` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `intervention_photos_ibfk_3` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intervention_photos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `intervention_photos` WRITE;
/*!40000 ALTER TABLE `intervention_photos` DISABLE KEYS */;
INSERT INTO `intervention_photos` VALUES
(1,1,7,'after_1784195096_8afd8ab3.jpg','test_after.jpg','image/jpeg',3267,'after',NULL,NULL,'Dechets ramasses',13,'2026-07-16 09:44:56'),
(2,2,8,'during_1784195963_84d73e78.jpg','OIP.jpg','image/jpeg',33347,'during',36.7378050,2.9913710,'',9,'2026-07-16 09:59:23'),
(3,4,22,'after_1784463067_087f5c8e.jpg','e567aa60-0009-400b-8406-d6ed34089fe7.jpg','image/jpeg',80581,'after',36.7909720,3.0517960,'',9,'2026-07-19 12:11:07'),
(4,5,31,'after_1784621117_53be2fb0.jpg','apre.jpeg','image/jpeg',188845,'after',36.7889790,3.0504660,'',4,'2026-07-21 08:05:17'),
(5,6,32,'after_1784636112_657fd747.jpg','WhatsApp Image 2026-07-21 at 08.48.39.jpeg','image/jpeg',172286,'after',36.7904940,3.0529980,'',5,'2026-07-21 12:15:12'),
(6,7,45,'after_1784726204_149fb63c.jpg','test_after.jpg','image/jpeg',415,'after',NULL,NULL,NULL,68,'2026-07-22 13:16:44'),
(7,8,47,'after_1785072315_5396991f.png','Capture d\'écran 2026-07-14 150023.png','image/png',69116,'after',36.7853040,3.0573750,'c\'est regler',5,'2026-07-26 13:25:15'),
(14,9,51,'after_1785328923_dc50aeac.png','Gemini_Generated_Image_llfs7gllfs7gllfs.png','image/png',1795563,'after',36.7908330,3.0534920,'',13,'2026-07-29 12:42:03'),
(15,12,52,'after_1785337867_a94edaea.jpg','21.jpeg','image/jpeg',161227,'after',36.7861640,3.0390070,'bien',4,'2026-07-29 15:11:07');
/*!40000 ALTER TABLE `intervention_photos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `landing_before_after`
--

DROP TABLE IF EXISTS `landing_before_after`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_before_after` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `before_image` varchar(500) NOT NULL,
  `after_image` varchar(500) NOT NULL,
  `title_fr` varchar(200) NOT NULL,
  `title_ar` varchar(200) NOT NULL,
  `desc_fr` text NOT NULL,
  `desc_ar` text NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_before_after`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `landing_before_after` WRITE;
/*!40000 ALTER TABLE `landing_before_after` DISABLE KEYS */;
INSERT INTO `landing_before_after` VALUES
(1,'/uploads/landing/before-after/lp_6a6afd7ddf8338.79089246.png','/uploads/landing/before-after/lp_6a6afd7ddfe668.61195485.png','Réparation rue du quartier','إصلاح طريق الحي','Nid-de-poule comblé et route rénovée en 5 jours.','تم إصلاح الحفر وترقيع الطريق خلال 5 أيام.',1,1,'2026-07-20 15:05:05'),
(2,'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=600&q=80','https://images.unsplash.com/photo-1497436072909-60f360e1d4b1?w=600&q=80','Nettoyage de la zone','تنظيف المنطقة','Déchets retirés, espace vert créé.','إزالة النفايات وإنشاء مساحة خضراء.',2,1,'2026-07-20 15:05:05'),
(3,'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=600&q=80','https://images.unsplash.com/photo-1580502304784-8985b7eb7260?w=600&q=80','Réparation éclairage','إصلاح الإضاءة','Nouveaux lampadaires installés, éclairage amélioré.','تم تركيب مصابيح جديدة وتحسين الإضاءة.',3,1,'2026-07-20 15:05:05');
/*!40000 ALTER TABLE `landing_before_after` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `landing_faq`
--

DROP TABLE IF EXISTS `landing_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_faq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question_fr` varchar(300) NOT NULL,
  `question_ar` varchar(300) NOT NULL,
  `answer_fr` text NOT NULL,
  `answer_ar` text NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_faq`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `landing_faq` WRITE;
/*!40000 ALTER TABLE `landing_faq` DISABLE KEYS */;
INSERT INTO `landing_faq` VALUES
(1,'Comment signaler un problème ?','كيفية الإبلاغ عن مشكلة؟','Créez un compte, cliquez sur \"Signaler un problème\", remplissez le formulaire avec photo et localisation, puis soumettez.','أنشئ حساباً، انقر على \"الإبلاغ عن مشكلة\"، املأ النموذج مع الصورة والموقع، ثم أرسل.',1,1,'2026-07-20 15:05:05'),
(2,'Combien de temps prend le traitement ?','كم يستغرق المعالجة؟','Le délai varie selon la catégorie : 7-15 jours ouvrables. Vous pouvez suivre l\'avancement en temps réel via votre code de suivi.','يختلف المدة حسب الفئة: 7-15 يوم عمل. يمكنك متابعة التقدم في الوقت الفعلي عبر كود التتبع.',2,1,'2026-07-20 15:05:05'),
(3,'Puis-je suivre mon signalement ?','هل يمكنني متابعة بلاغي؟','Oui ! Chaque signalement reçoit un code unique. Utilisez la page \"Suivi\" pour voir l\'état en temps réel.','نعم! كل بلاغ يحصل على كود فريد. استخدم صفحة \"المتابعة\" لرؤية الحالة في الوقت الفعلي.',3,1,'2026-07-20 15:05:05'),
(4,'Comment modifier mon signalement ?','كيف أعدّل بلاغي؟','Vous pouvez modifier votre signalement tant qu\'il n\'a pas été pris en charge par un intervenant. Allez dans \"Mes signalements\".','يمكنك تعديل بلاغك ما لم يتم اتخاذه من قبل المتدخل. اذهب إلى \"بلاغاتي\".',4,1,'2026-07-20 15:05:05'),
(5,'Les photos sont-elles obligatoires ?','هل الصور إلزامية؟','Les photos sont fortement recommandées car elles accélèrent le traitement. Une photo par défaut sera ajoutée si vous n\'en avez pas.','الصور موصى بها بشدة لأنها تسرّع المعالجة. ستُضاف صورة افتراضية إذا لم يكن لديك صورة.',5,1,'2026-07-20 15:05:05'),
(6,'Comment contacter le support ?','التواصل مع الدعم؟','Utilisez la page de contact ou envoyez un email à support@balagh-alger.dz. Notre équipe répond sous 24h.','استخدم صفحة الاتصال أو أرسل بريداً إلكترونياً إلى support@balagh-alger.dz. يرد فريقنا خلال 24 ساعة.',6,1,'2026-07-20 15:05:05');
/*!40000 ALTER TABLE `landing_faq` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `landing_gallery`
--

DROP TABLE IF EXISTS `landing_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image_url` varchar(500) NOT NULL,
  `alt_text` varchar(255) DEFAULT '',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_gallery`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `landing_gallery` WRITE;
/*!40000 ALTER TABLE `landing_gallery` DISABLE KEYS */;
INSERT INTO `landing_gallery` VALUES
(2,'https://images.unsplash.com/photo-1580502304784-8985b7eb7260?w=600&q=80','Rue Alger',2,1,'2026-07-20 15:05:05'),
(6,'https://images.unsplash.com/photo-1414609245224-afa02bfb3fda?w=600&q=80','Route',6,1,'2026-07-20 15:05:05'),
(7,'https://www.independentarabia.com/sites/default/files/styles/1368x911/public/article/mainimage/2021/01/11/302311-1180778481.jpg?itok=0Kbru5Vw','Alger Vue',1,1,'2026-07-21 07:22:09'),
(8,'https://www.elbilad.net/storage/images/article/d_f987f6776fe5d9282994ca2b5b8ebffd.jpg','',3,1,'2026-07-21 07:22:55'),
(9,'https://content.r9cdn.net/rimg/dimg/a2/04/dd9815df-city-10465-164dc53b979.jpg?width=2160&height=1215&xhint=3092&yhint=1763&crop=true','',4,1,'2026-07-21 07:23:42'),
(10,'https://live.staticflickr.com/3700/9425008530_8f05de1d4a_b.jpg','',5,1,'2026-07-21 07:24:09');
/*!40000 ALTER TABLE `landing_gallery` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `landing_partners`
--

DROP TABLE IF EXISTS `landing_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_partners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(50) NOT NULL DEFAULT 'fas fa-building',
  `color` varchar(30) DEFAULT 'var(--primary-light)',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_partners`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `landing_partners` WRITE;
/*!40000 ALTER TABLE `landing_partners` DISABLE KEYS */;
INSERT INTO `landing_partners` VALUES
(1,'SEAAL','fas fa-water','var(--accent)',1,1,'2026-07-20 15:05:05'),
(2,'Sonelgaz','fas fa-bolt','var(--amber)',2,1,'2026-07-20 15:05:05'),
(3,'DTP','fas fa-road','var(--primary-light)',3,1,'2026-07-20 15:05:05'),
(4,'ASRout','fas fa-road','#f97316',4,1,'2026-07-20 15:05:05'),
(5,'ERMA','fas fa-industry','var(--red)',5,1,'2026-07-20 15:05:05'),
(6,'EDéval','fas fa-lightbulb','var(--amber)',6,1,'2026-07-20 15:05:05'),
(7,'EGCTU','fas fa-dumbbell','var(--green)',7,1,'2026-07-20 15:05:05'),
(8,'EMCU','fas fa-tree','var(--green)',8,1,'2026-07-20 15:05:05'),
(9,'HUPE','fas fa-umbrella-beach','var(--accent)',9,1,'2026-07-20 15:05:05'),
(10,'NETCOM','fas fa-broom','var(--pink)',10,1,'2026-07-20 15:05:05'),
(11,'Wilaya d\'Alger','fas fa-building','var(--primary-light)',11,1,'2026-07-20 15:05:05'),
(12,'APC','fas fa-city','var(--accent)',12,1,'2026-07-20 15:05:05');
/*!40000 ALTER TABLE `landing_partners` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `landing_testimonials`
--

DROP TABLE IF EXISTS `landing_testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_testimonials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text_fr` text NOT NULL,
  `text_ar` text NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_role` varchar(100) NOT NULL,
  `avatar_letter` char(1) NOT NULL,
  `avatar_gradient` varchar(30) DEFAULT 'var(--gradient-accent)',
  `rating` tinyint(4) DEFAULT 5,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_testimonials`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `landing_testimonials` WRITE;
/*!40000 ALTER TABLE `landing_testimonials` DISABLE KEYS */;
INSERT INTO `landing_testimonials` VALUES
(1,'J\'ai signalé un trou de rue, et il a été réparé en une semaine. Plateforme formidable !','أبلغت عن حفرة في شارعنا، وتم إصلاحها خلال أسبوع. منصة رائعة!','Karim B.','El Harrach','K','var(--gradient-accent)',5,1,1,'2026-07-20 15:05:05'),
(2,'La facilité d\'utilisation et la transparence du suivi me font recommander cette plateforme à tous.','سهولة الاستخدام والشفافية في التتبع تجعلانيني أوصي بهذه المنصة للجميع.','Sarah L.','Bir Mourad Raïs','S','var(--gradient-cool)',5,1,2,'2026-07-20 15:05:05'),
(3,'Enfin une plateforme qui permet aux citoyens d\'améliorer leur ville. Merci Balagh Alger !','أخيراً منصة تسمح للمواطنين بالمساهمة في تحسين مدينتهم. شكراً بلاغ الجزائر!','Yacine H.','Hussein Dey','Y','var(--gradient-purple)',4,1,3,'2026-07-20 15:05:05');
/*!40000 ALTER TABLE `landing_testimonials` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,11,'assignment','Signalement assigné','Un signalement vous a été assigné par le responsable central.','{\"report_id\":7}',0,NULL,'2026-07-16 09:40:13'),
(2,12,'assignment','Signalement assigné','Un signalement vous a été assigné par le Chef d\'Unité.','{\"report_id\":7}',0,NULL,'2026-07-16 09:41:08'),
(3,13,'assignment','Mission d\'intervention','Vous avez été assigné à un signalement terrain. Veuillez vous rendre sur place.','{\"report_id\":7}',0,NULL,'2026-07-16 09:41:23'),
(4,9,'status_update','Intervention en cours','Votre signalement BA-2026-TEST01 est en cours de traitement.','{\"report_id\":7}',0,NULL,'2026-07-16 09:41:36'),
(5,9,'status_update','Signalement traité','Votre signalement BA-2026-TEST01 a été traité. Vous pouvez consulter les résultats.','{\"report_id\":7}',0,NULL,'2026-07-16 09:45:03'),
(6,9,'status_update','Signalement clôturé','Votre signalement BA-2026-TEST01 a été clôturé definitivement.','{\"report_id\":7}',0,NULL,'2026-07-16 09:45:32'),
(7,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":8}',0,NULL,'2026-07-16 09:54:21'),
(8,9,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #8',NULL,0,NULL,'2026-07-16 09:58:20'),
(9,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":9}',0,NULL,'2026-07-16 10:43:03'),
(10,13,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #7',NULL,0,NULL,'2026-07-16 10:56:04'),
(11,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":16}',0,NULL,'2026-07-16 11:26:59'),
(12,11,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #16',NULL,0,NULL,'2026-07-16 11:28:21'),
(13,18,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":17}',0,NULL,'2026-07-16 11:50:38'),
(14,3,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #16',NULL,0,NULL,'2026-07-19 10:01:47'),
(15,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":19}',0,NULL,'2026-07-19 10:26:09'),
(16,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":21}',0,NULL,'2026-07-19 11:38:43'),
(17,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":22}',0,NULL,'2026-07-19 11:38:44'),
(18,10,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #22',NULL,0,NULL,'2026-07-19 11:41:24'),
(19,11,'assignment','Signalement assigné','Un signalement vous a été assigné par le responsable central.','{\"report_id\":22}',0,NULL,'2026-07-19 12:07:22'),
(20,11,'assignment','Signalement assigné','Un signalement vous a été assigné par le responsable central.','{\"report_id\":22}',0,NULL,'2026-07-19 12:08:04'),
(21,12,'assignment','Signalement assigné','Un signalement vous a été assigné par le Chef d\'Unité.','{\"report_id\":22}',0,NULL,'2026-07-19 12:09:09'),
(22,9,'assignment','Mission d\'intervention','Vous avez été assigné à un signalement terrain. Veuillez vous rendre sur place.','{\"report_id\":22}',0,NULL,'2026-07-19 12:09:49'),
(23,45,'status_update','Intervention en cours','Votre signalement BA-2026-660064 est en cours de traitement sur le terrain.','{\"report_id\":22}',1,'2026-07-22 14:04:31','2026-07-19 12:10:39'),
(24,45,'status_update','Intervention en cours','Votre signalement BA-2026-660064 est en cours de traitement sur le terrain.','{\"report_id\":22}',1,'2026-07-22 14:04:29','2026-07-19 12:11:00'),
(25,45,'status_update','Signalement clôturé','Votre signalement BA-2026-660064 a été clôturé définitivement. Merci pour votre contribution.','{\"report_id\":22}',1,'2026-07-22 13:20:51','2026-07-19 12:20:39'),
(26,10,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #21',NULL,0,NULL,'2026-07-19 14:33:45'),
(27,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":23}',0,NULL,'2026-07-20 09:21:39'),
(28,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":24}',0,NULL,'2026-07-20 09:21:41'),
(29,11,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #24',NULL,0,NULL,'2026-07-20 09:23:52'),
(30,5,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #24',NULL,0,NULL,'2026-07-20 09:24:50'),
(31,5,'assignment','Mission d\'intervention','Vous avez été assigné à un signalement terrain. Veuillez vous rendre sur place.','{\"report_id\":24}',0,NULL,'2026-07-20 09:25:34'),
(32,21,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #15',NULL,0,NULL,'2026-07-20 12:47:54'),
(33,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":30}',0,NULL,'2026-07-20 12:52:16'),
(34,3,'assignment','Nouvelle assignation','Vous avez été assigné au signalement #30',NULL,0,NULL,'2026-07-20 12:53:23'),
(35,11,'assignment','Signalement assigné','Un signalement vous a été assigné par le responsable central.','{\"report_id\":30}',0,NULL,'2026-07-20 12:55:55'),
(36,11,'assignment','Signalement assigné','Un signalement vous a été assigné par le responsable central.','{\"report_id\":30}',0,NULL,'2026-07-20 12:57:39'),
(37,2,'assignment','Signalement assigné','Un signalement vous a été assigné par le responsable central.','{\"report_id\":30}',0,NULL,'2026-07-20 12:57:55'),
(38,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":18}',0,NULL,'2026-07-20 13:05:53'),
(39,11,'assignment','Signalement assigné','Un signalement vous a été assigné par le responsable central.','{\"report_id\":18}',0,NULL,'2026-07-20 13:06:18'),
(40,12,'assignment','Signalement assigné','Un signalement vous a été assigné par le Chef d\'Unité.','{\"report_id\":18}',0,NULL,'2026-07-20 13:06:19'),
(41,13,'assignment','Mission d\'intervention','Vous avez été assigné à un signalement terrain. Veuillez vous rendre sur place.','{\"report_id\":18}',0,NULL,'2026-07-20 13:06:20'),
(42,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":30}',0,NULL,'2026-07-20 13:08:21'),
(43,6,'status_update','Signalement résolu','Votre signalement BA-2026-000003 a été résolu.','{\"report_id\":3}',0,NULL,'2026-07-20 13:13:39'),
(44,45,'status_update','Signalement résolu','Votre signalement BA-2026-144866 a été résolu.','{\"report_id\":30}',1,'2026-07-22 13:20:49','2026-07-20 13:16:29'),
(45,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":31}',0,NULL,'2026-07-21 08:01:13'),
(46,3,'assignment','Signalement assigné','Un signalement vous a été assigné par le Chef d\'Unité.','{\"report_id\":31}',0,NULL,'2026-07-21 08:03:09'),
(47,4,'assignment','Mission d\'intervention','Vous avez été assigné à un signalement terrain. Veuillez vous rendre sur place.','{\"report_id\":31}',1,'2026-07-29 12:56:23','2026-07-21 08:04:03'),
(48,47,'status_update','Intervention en cours','Votre signalement BA-2026-316710 est en cours de traitement sur le terrain.','{\"report_id\":31}',1,'2026-07-21 08:19:33','2026-07-21 08:04:52'),
(49,47,'status_update','Signalement résolu','Votre signalement BA-2026-316710 a été résolu.','{\"report_id\":31}',1,'2026-07-21 11:41:07','2026-07-21 08:06:27'),
(50,10,'assignment','Nouveau signalement','Un nouveau signalement vous a été assigné automatiquement.','{\"report_id\":32}',1,'2026-07-21 12:13:49','2026-07-21 11:47:34'),
(51,5,'assignment','Mission d\'intervention','Vous avez été assigné à un signalement terrain. Veuillez vous rendre sur place.','{\"report_id\":32}',1,'2026-07-21 12:14:09','2026-07-21 12:13:37'),
(52,48,'status_update','Intervention en cours','Votre signalement BA-2026-577793 est en cours de traitement sur le terrain.','{\"report_id\":32}',1,'2026-07-21 14:31:12','2026-07-21 12:14:27'),
(53,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":36}',0,NULL,'2026-07-22 11:08:34'),
(54,65,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":37}',1,'2026-07-22 11:47:24','2026-07-22 11:46:51'),
(55,71,'assignment','notifications.mission_title','notifications.mission_msg','{\"report_id\":37}',0,NULL,'2026-07-22 11:47:47'),
(56,66,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":38}',0,NULL,'2026-07-22 11:51:20'),
(57,65,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":38}',0,NULL,'2026-07-22 11:52:16'),
(58,65,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":38}',0,NULL,'2026-07-22 11:52:49'),
(59,65,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":38}',1,'2026-07-22 11:54:56','2026-07-22 11:53:50'),
(60,66,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":40}',0,NULL,'2026-07-22 12:30:27'),
(61,70,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":40}',0,NULL,'2026-07-22 12:30:53'),
(62,66,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":41}',0,NULL,'2026-07-22 12:31:35'),
(63,66,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":42}',0,NULL,'2026-07-22 12:32:11'),
(64,66,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":43}',0,NULL,'2026-07-22 12:32:39'),
(65,70,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":43}',0,NULL,'2026-07-22 12:33:03'),
(66,70,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":43}',0,NULL,'2026-07-22 12:33:24'),
(67,66,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":44}',0,NULL,'2026-07-22 12:33:57'),
(68,70,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":44}',0,NULL,'2026-07-22 12:34:22'),
(69,66,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":45}',0,NULL,'2026-07-22 12:35:16'),
(70,66,'assignment','notifications.mission_title','notifications.mission_msg','{\"report_id\":45}',0,NULL,'2026-07-22 12:36:39'),
(71,70,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":45}',0,NULL,'2026-07-22 12:36:42'),
(72,70,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":42}',0,NULL,'2026-07-22 12:37:12'),
(73,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":46}',0,NULL,'2026-07-22 13:11:45'),
(74,3,'assignment','notifications.assigned_title','notifications.assigned_by_chef_unite_msg','{\"report_id\":46}',1,'2026-07-23 09:57:36','2026-07-22 13:13:03'),
(75,69,'assignment','notifications.assigned_title','notifications.assigned_by_chef_unite_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:13:07'),
(76,69,'assignment','notifications.assigned_title','notifications.assigned_by_chef_unite_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:13:22'),
(77,68,'assignment','notifications.mission_title','notifications.mission_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:13:44'),
(78,5,'assignment','notifications.mission_title','notifications.mission_msg','{\"report_id\":46}',0,NULL,'2026-07-22 13:14:34'),
(79,67,'status_update','notifications.intervention_started_title','notifications.intervention_started_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:14:56'),
(80,69,'validation','notifications.work_to_validate_title','notifications.work_to_validate_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:16:55'),
(81,67,'status_update','notifications.report_in_validation_title','notifications.report_in_validation_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:16:55'),
(82,70,'validation','notifications.validation_required_title','notifications.validation_required_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:17:06'),
(83,67,'status_update','notifications.report_validated_title','notifications.report_validated_msg','{\"report_id\":45}',0,NULL,'2026-07-22 13:19:11'),
(84,1,'status_update','notifications.report_validated_title','notifications.report_validated_msg','{\"report_id\":46}',1,'2026-07-22 14:00:54','2026-07-22 13:21:28'),
(85,70,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":43}',0,NULL,'2026-07-23 11:08:10'),
(86,1,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":46}',1,'2026-07-27 09:54:55','2026-07-23 11:08:33'),
(87,1,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',1,'2026-07-23 11:08:59','2026-07-23 11:08:33'),
(88,1,'badge','Badge obtenu !','Vous avez gagné le badge \"Résolution\"','{\"badge\":\"first_resolved\"}',1,'2026-07-23 11:09:05','2026-07-23 11:08:33'),
(89,48,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":38}',0,NULL,'2026-07-23 11:08:47'),
(90,48,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',1,'2026-07-23 11:17:43','2026-07-23 11:08:47'),
(91,48,'badge','Badge obtenu !','Vous avez gagné le badge \"Résolution\"','{\"badge\":\"first_resolved\"}',0,NULL,'2026-07-23 11:08:47'),
(92,45,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":21}',1,'2026-07-26 12:36:02','2026-07-23 11:09:46'),
(93,45,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',1,'2026-07-26 12:44:45','2026-07-23 11:09:46'),
(94,45,'badge','Badge obtenu !','Vous avez gagné le badge \"Résolution\"','{\"badge\":\"first_resolved\"}',1,'2026-07-23 11:12:21','2026-07-23 11:09:46'),
(95,67,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":45}',0,NULL,'2026-07-23 11:10:12'),
(96,67,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',0,NULL,'2026-07-23 11:10:12'),
(97,67,'badge','Badge obtenu !','Vous avez gagné le badge \"Résolution\"','{\"badge\":\"first_resolved\"}',0,NULL,'2026-07-23 11:10:12'),
(98,67,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":44}',0,NULL,'2026-07-23 11:10:25'),
(99,67,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":42}',0,NULL,'2026-07-23 11:10:33'),
(100,67,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":41}',0,NULL,'2026-07-23 11:10:41'),
(101,67,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":40}',0,NULL,'2026-07-23 11:10:54'),
(102,67,'badge','Badge obtenu !','Vous avez gagné le badge \"Impact local\"','{\"badge\":\"resolved_5\"}',0,NULL,'2026-07-23 11:10:54'),
(103,48,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":37}',0,NULL,'2026-07-23 11:11:05'),
(104,1,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":36}',1,'2026-07-23 11:12:10','2026-07-23 11:11:19'),
(105,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":47}',0,NULL,'2026-07-26 13:19:27'),
(106,11,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":47}',0,NULL,'2026-07-26 13:22:26'),
(107,3,'assignment','notifications.assigned_title','notifications.assigned_by_chef_unite_msg','{\"report_id\":47}',0,NULL,'2026-07-26 13:23:22'),
(108,5,'assignment','notifications.mission_title','notifications.mission_msg','{\"report_id\":47}',1,'2026-07-29 12:39:41','2026-07-26 13:24:24'),
(109,3,'validation','notifications.work_to_validate_title','notifications.work_to_validate_msg','{\"report_id\":47}',0,NULL,'2026-07-26 13:25:32'),
(110,45,'status_update','notifications.report_in_validation_title','notifications.report_in_validation_msg','{\"report_id\":47}',1,'2026-07-27 09:59:07','2026-07-26 13:25:32'),
(111,11,'validation','notifications.validation_required_title','notifications.validation_required_msg','{\"report_id\":47}',0,NULL,'2026-07-26 13:26:15'),
(112,45,'status_update','notifications.report_validated_title','notifications.report_validated_msg','{\"report_id\":47}',1,'2026-07-26 13:27:19','2026-07-26 13:27:00'),
(113,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":48}',0,NULL,'2026-07-26 14:40:15'),
(114,73,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',1,'2026-07-26 14:44:12','2026-07-26 14:40:15'),
(115,2,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":48}',0,NULL,'2026-07-26 14:45:40'),
(116,1,'status_update','notifications.report_closed_final_title','notifications.report_closed_final_msg','{\"report_id\":46}',1,'2026-07-27 13:04:18','2026-07-27 12:49:09'),
(117,48,'status_update','notifications.report_closed_final_title','notifications.report_closed_final_msg','{\"report_id\":38}',0,NULL,'2026-07-27 12:49:14'),
(118,45,'status_update','notifications.report_closed_final_title','notifications.report_closed_final_msg','{\"report_id\":21}',1,'2026-07-27 13:49:27','2026-07-27 12:49:22'),
(119,73,'status_update','notifications.report_closed_title','notifications.report_closed_msg','{\"report_id\":48}',0,NULL,'2026-07-27 12:55:12'),
(120,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":21}',0,NULL,'2026-07-27 12:59:03'),
(121,1,'test','Test','Test',NULL,1,'2026-07-27 13:04:39','2026-07-27 13:04:01'),
(122,1,'test','Queue E2E Test','Full end-to-end test',NULL,1,'2026-07-27 13:06:13','2026-07-27 13:05:00'),
(123,1,'test','SLA Test','SLA works',NULL,1,'2026-07-27 14:13:11','2026-07-27 13:06:34'),
(124,1,'test','Test','Test',NULL,1,'2026-07-27 14:13:11','2026-07-27 13:12:16'),
(125,13,'sla_overdue','🚨 EN RETARD — 4 jour(s)','Le signalement \"Dépôt sauvage rue des Frères Abbas\" (BA-2026-TEST01) est en retard de 4 jour(s).','{\"report_id\":7}',0,NULL,'2026-07-27 13:16:17'),
(126,14,'sla_overdue','🚨 EN RETARD — 7 jour(s)','Le signalement \"Nid-de-poule rue Didouche Mourad\" (BA-2026-000010) est en retard de 7 jour(s).','{\"report_id\":12}',0,NULL,'2026-07-27 13:16:17'),
(127,21,'sla_overdue','🚨 EN RETARD — 4 jour(s)','Le signalement \"Fuite d\'eau Draria\" (BA-2026-000013) est en retard de 4 jour(s).','{\"report_id\":15}',0,NULL,'2026-07-27 13:16:17'),
(128,3,'sla_overdue','🚨 EN RETARD — 4 jour(s)','Le signalement \"Dégradation\" (BA-2026-653539) est en retard de 4 jour(s).','{\"report_id\":16}',0,NULL,'2026-07-27 13:16:17'),
(129,10,'sla_overdue','🚨 EN RETARD — 1 jour(s)','Le signalement \"xxx\" (BA-2026-230859) est en retard de 1 jour(s).','{\"report_id\":21}',0,NULL,'2026-07-27 13:16:17'),
(130,14,'sla_overdue','🚨 EN RETARD — 8 jour(s)','Le signalement \"Nid-de-poule rue Didouche Mourad\" (BA-2026-000001) est en retard de 8 jour(s).','{\"report_id\":1}',0,NULL,'2026-07-27 13:16:17'),
(131,21,'sla_overdue','🚨 EN RETARD — 5 jour(s)','Le signalement \"Fuite d eau avenue de la République\" (BA-2026-000004) est en retard de 5 jour(s).','{\"report_id\":4}',0,NULL,'2026-07-27 13:16:17'),
(132,18,'sla_overdue','🚨 EN RETARD — 4 jour(s)','Le signalement \"coupe courant\" (BA-2026-358666) est en retard de 4 jour(s).','{\"report_id\":17}',0,NULL,'2026-07-27 13:16:17'),
(133,13,'sla_overdue','🚨 EN RETARD — 1 jour(s)','Le signalement \"dechet souvage \" (BA-2026-457733) est en retard de 1 jour(s).','{\"report_id\":18}',0,NULL,'2026-07-27 13:16:17'),
(134,1,'test','E2E Test','Queue system works!',NULL,1,'2026-07-27 14:13:11','2026-07-27 13:28:46'),
(135,1,'test','E2E Test','Queue system works!',NULL,1,'2026-07-27 18:22:49','2026-07-27 13:29:41'),
(136,73,'status_update','notifications.report_closed_title','notifications.report_closed_msg','{\"report_id\":48}',0,NULL,'2026-07-27 13:49:02'),
(137,73,'status_update','notifications.report_closed_title','notifications.report_closed_msg','{\"report_id\":48}',0,NULL,'2026-07-27 14:06:34'),
(138,73,'status_update','notifications.report_closed_title','notifications.report_closed_msg','{\"report_id\":48}',0,NULL,'2026-07-27 14:06:38'),
(139,73,'status_update','notifications.report_closed_title','notifications.report_closed_msg','{\"report_id\":48}',0,NULL,'2026-07-27 14:13:06'),
(140,73,'status_update','notifications.report_closed_title','notifications.report_closed_msg','{\"report_id\":48}',0,NULL,'2026-07-27 14:38:05'),
(141,1,'badge','Badge obtenu !','Vous avez gagné le badge \"5 signalements\"','{\"badge\":\"report_5\"}',1,'2026-07-28 13:06:17','2026-07-27 17:13:59'),
(142,75,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',1,'2026-07-27 17:21:44','2026-07-27 17:21:21'),
(143,45,'badge','Badge obtenu !','Vous avez gagné le badge \"5 signalements\"','{\"badge\":\"report_5\"}',1,'2026-07-29 12:34:57','2026-07-29 12:34:37'),
(144,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":51}',0,NULL,'2026-07-29 12:36:07'),
(145,11,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":51}',0,NULL,'2026-07-29 12:36:49'),
(146,3,'assignment','notifications.assigned_title','notifications.assigned_by_chef_unite_msg','{\"report_id\":51}',1,'2026-07-29 12:38:12','2026-07-29 12:37:30'),
(147,13,'assignment','notifications.mission_title','notifications.mission_msg','{\"report_id\":51}',0,NULL,'2026-07-29 12:38:19'),
(148,3,'validation','notifications.work_to_validate_title','notifications.work_to_validate_msg','{\"report_id\":51}',0,NULL,'2026-07-29 12:42:10'),
(149,45,'status_update','notifications.report_in_validation_title','notifications.report_in_validation_msg','{\"report_id\":51}',1,'2026-07-29 12:59:25','2026-07-29 12:42:10'),
(150,45,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":51}',1,'2026-07-29 12:59:25','2026-07-29 12:42:27'),
(151,9,'status_update','notifications.report_resolved_title','notifications.report_resolved_msg','{\"report_id\":7}',0,NULL,'2026-07-29 12:42:40'),
(152,9,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',0,NULL,'2026-07-29 12:42:40'),
(153,9,'badge','Badge obtenu !','Vous avez gagné le badge \"Résolution\"','{\"badge\":\"first_resolved\"}',0,NULL,'2026-07-29 12:42:40'),
(154,45,'status_update','notifications.report_closed_final_title','notifications.report_closed_final_msg','{\"report_id\":51}',1,'2026-07-29 12:59:25','2026-07-29 12:50:20'),
(155,44,'status_update','notifications.intervention_started_title','notifications.intervention_started_msg','{\"report_id\":18}',0,NULL,'2026-07-29 12:57:48'),
(156,44,'status_update','notifications.intervention_started_title','notifications.intervention_started_msg','{\"report_id\":18}',0,NULL,'2026-07-29 12:57:52'),
(157,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":52}',0,NULL,'2026-07-29 15:05:21'),
(158,78,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',1,'2026-07-29 15:05:25','2026-07-29 15:05:21'),
(159,60,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":52}',0,NULL,'2026-07-29 15:06:55'),
(160,11,'assignment','notifications.assigned_title','notifications.assigned_by_central_msg','{\"report_id\":52}',0,NULL,'2026-07-29 15:08:44'),
(161,3,'assignment','notifications.assigned_title','notifications.assigned_by_chef_unite_msg','{\"report_id\":52}',0,NULL,'2026-07-29 15:09:35'),
(162,4,'assignment','notifications.mission_title','notifications.mission_msg','{\"report_id\":52}',0,NULL,'2026-07-29 15:10:01'),
(163,78,'status_update','notifications.intervention_started_title','notifications.intervention_started_msg','{\"report_id\":52}',1,'2026-07-29 15:16:08','2026-07-29 15:10:30'),
(164,3,'validation','notifications.work_to_validate_title','notifications.work_to_validate_msg','{\"report_id\":52}',1,'2026-07-29 15:14:06','2026-07-29 15:11:10'),
(165,78,'status_update','notifications.report_in_validation_title','notifications.report_in_validation_msg','{\"report_id\":52}',1,'2026-07-29 15:16:08','2026-07-29 15:11:10'),
(166,11,'validation','notifications.validation_required_title','notifications.validation_required_msg','{\"report_id\":52}',0,NULL,'2026-07-29 15:13:52'),
(167,78,'status_update','notifications.report_validated_title','notifications.report_validated_msg','{\"report_id\":52}',1,'2026-07-29 15:16:08','2026-07-29 15:15:24'),
(168,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":53}',0,NULL,'2026-07-30 06:30:00'),
(169,79,'badge','Badge obtenu !','Vous avez gagné le badge \"Premier signalement\"','{\"badge\":\"first_report\"}',1,'2026-07-30 06:31:14','2026-07-30 06:30:00'),
(170,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":54}',0,NULL,'2026-07-30 06:30:02'),
(171,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":55}',0,NULL,'2026-07-30 06:30:04'),
(172,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":56}',0,NULL,'2026-07-30 06:30:13'),
(173,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":57}',0,NULL,'2026-07-30 06:30:15'),
(174,79,'badge','Badge obtenu !','Vous avez gagné le badge \"5 signalements\"','{\"badge\":\"report_5\"}',1,'2026-07-30 06:31:14','2026-07-30 06:30:15'),
(175,10,'assignment','notifications.new_assignment_title','notifications.new_assignment_msg','{\"report_id\":58}',0,NULL,'2026-07-30 06:30:15'),
(176,79,'report_deleted','Signalement supprimé','Votre signalement BA-2026-151501 a été supprimé par l\'administration.','{\"report_id\":58}',1,'2026-07-30 06:48:26','2026-07-30 06:47:53'),
(177,79,'report_deleted','Signalement supprimé','Votre signalement BA-2026-635118 a été supprimé par l\'administration.','{\"report_id\":57}',1,'2026-07-30 06:48:26','2026-07-30 06:47:57'),
(178,79,'report_deleted','Signalement supprimé','Votre signalement BA-2026-970973 a été supprimé par l\'administration.','{\"report_id\":56}',1,'2026-07-30 06:48:26','2026-07-30 06:48:01'),
(179,79,'report_deleted','Signalement supprimé','Votre signalement BA-2026-370991 a été supprimé par l\'administration.','{\"report_id\":55}',1,'2026-07-30 06:48:26','2026-07-30 06:48:06'),
(180,79,'report_deleted','Signalement supprimé','Votre signalement BA-2026-256470 a été supprimé par l\'administration.','{\"report_id\":54}',1,'2026-07-30 06:48:26','2026-07-30 06:48:09');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `organization_rules`
--

DROP TABLE IF EXISTS `organization_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `subcategory_id` bigint(20) unsigned DEFAULT NULL,
  `daira_id` bigint(20) unsigned DEFAULT NULL,
  `priority_order` int(11) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rule` (`category_id`,`subcategory_id`,`daira_id`,`organization_id`),
  KEY `organization_id` (`organization_id`),
  KEY `subcategory_id` (`subcategory_id`),
  KEY `daira_id` (`daira_id`),
  CONSTRAINT `organization_rules_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organization_rules_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organization_rules_ibfk_3` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `organization_rules_ibfk_4` FOREIGN KEY (`daira_id`) REFERENCES `dairas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `organization_rules` WRITE;
/*!40000 ALTER TABLE `organization_rules` DISABLE KEYS */;
INSERT INTO `organization_rules` VALUES
(100,1,1,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(101,1,2,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(102,1,3,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(103,1,4,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(104,1,5,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(105,1,6,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(106,2,7,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(107,2,8,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(108,2,9,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(109,2,10,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(110,2,11,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(111,2,12,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(112,2,13,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(113,2,14,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(114,2,15,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(115,2,16,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(116,2,17,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(117,2,18,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(118,4,19,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(119,4,20,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(120,4,21,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(121,4,22,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(122,15,23,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(123,15,24,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(124,15,25,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(125,15,26,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(126,15,27,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(127,15,28,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(128,15,29,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(129,6,30,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(130,6,31,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(131,6,32,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(132,6,33,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(133,6,34,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(134,6,35,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(135,6,36,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(136,6,37,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(137,6,38,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(138,6,39,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(139,5,40,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(140,5,41,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(141,5,42,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(142,5,43,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(143,9,44,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(144,9,45,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(145,9,46,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(146,9,47,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(147,9,48,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(148,9,49,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(149,9,50,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(150,9,51,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(151,9,52,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(152,9,53,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(153,9,54,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(154,9,55,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(155,9,56,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(156,9,57,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(157,3,58,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(158,3,59,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(159,3,60,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(160,3,61,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(161,11,62,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(162,11,63,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(163,11,64,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(164,11,65,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(165,11,66,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(166,10,67,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(167,18,68,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10'),
(168,13,69,NULL,NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:34:10');
/*!40000 ALTER TABLE `organization_rules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `name_ar` varchar(150) DEFAULT NULL,
  `slug` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES
(1,'NETCOM','نتكوم','netcom','NETCOM',NULL,'Alger',NULL,NULL,NULL,'المؤسسة العمومية للنظافة - جمع النفايات، رفع النفايات، إزالة المفارغ العشوائية، تنظيف الشوارع، غسل الأرصفة، غسل الساحات العمومية، سلات المهملات، الحاويات',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(2,'ASROUT','اسروت','asrout','ASROUT',NULL,'Alger',NULL,NULL,NULL,'مؤسسة صيانة الطرق - صيانة الطرق، الحفر، الأرصفة، البالوعات، مجاري مياه الأمطار، أغطية البالوعات، الحواجز، إعادة تهيئة الطرق بعد الأشغال، ركود المياه',1,'2026-07-15 14:02:15','2026-07-20 11:46:56'),
(3,'HUPE','هيب','hupe','HUPE',NULL,'Alger',NULL,NULL,NULL,'تسيير الشواطئ - نظافة الشواطئ، إزالة النفايات بالشواطئ، تنظيف الكورنيش، الحيوانات الضالة بالشواطئ، التجهيزات الشاطئية',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(4,'ERMA','ايرما','erma','ERMA',NULL,'Alger',NULL,NULL,NULL,'مؤسسة صيانة الإنارة العمومية - الإنارة العمومية، أعمدة الإنارة، المصابيح، الكوابل الخاصة بالإنارة، صيانة شبكة الإنارة',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(5,'EMCU','ام سي يو','emcu','EMCU',NULL,'Alger',NULL,NULL,NULL,'التجميل الحضري - الساحات العمومية، النوافير، الرايات الوطنية، الأثاث الحضري، التجميل الحضري',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(6,'EGCTU','اج سي تي يو','egctu','EGCTU',NULL,'Alger',NULL,NULL,NULL,'التجهيزات الحضرية - الإشارات العمودية والأفقية، محطات الحافلات، مواقف السيارات، الجسور الخاصة بالمشاة، اللافتات، الحواجز',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(7,'SEAAL','سيال','seaal','SEAAL',NULL,'Alger',NULL,NULL,NULL,'مؤسسة المياه والتطهير - تسرب المياه الصالحة للشرب، الصرف الصحي، قنوات الصرف، محطات الرفع، شبكات التطهير، خزانات المياه',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(8,'SONELGAZ','سونلغاز','sonelgaz','SONELGAZ',NULL,'Alger',NULL,NULL,NULL,'مؤسسة الكهرباء والغاز - الكهرباء، الغاز، الأعمدة الكهربائية، الأسلاك الكهربائية، انقطاع الكهرباء، انقطاع الغاز، الأعمدة الآيلة للسقوط',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(9,'APC (البلدية)','البلدية','apc','APC',NULL,'Alger',NULL,NULL,NULL,'البلدية - الاحتلال غير القانوني للطريق العام، الأسواق، الحيوانات الضالة، البنايات الفوضوية، الرخص، الممتلكات البلدية، النظافة المحلية، الفضاءات العمومية',1,'2026-07-15 14:02:15','2026-07-16 09:49:07'),
(10,'DTP','دي تي بي','dtp','DTP',NULL,'Alger',NULL,NULL,NULL,'مديرية الأشغال العمومية - الطرق الوطنية، الطرق الولائية، الجسور، المنشآت الفنية، مشاريع الأشغال العمومية',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(11,'DRE','دي آر إي','dre','DRE',NULL,'Alger',NULL,NULL,NULL,'مديرية الموارد المائية - الأودية، الينابيع، قنوات المياه الكبرى، حماية الموارد المائية، الفيضانات',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(12,'DEPTIC','دي بي تي سي','deptic','DEPTIC',NULL,'Alger',NULL,NULL,NULL,'مديرية الرقمنة - الأنظمة المعلوماتية، الشبكات، الكاميرات، اللوحات الإلكترونية، التجهيزات الرقمية',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(13,'GESTIMMO','جيستيم','gestimmo','GESTIMMO',NULL,'Alger',NULL,NULL,NULL,'تسيير الممتلكات - الممتلكات التابعة للولاية، المباني الإدارية، العقارات العمومية',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(14,'OPGI','وجي','opgi','OPGI',NULL,'Alger',NULL,NULL,NULL,'ديوان الترقية والتسيير العقاري - العمارات، الواجهات، المصاعد، الأقبية، الأجزاء المشتركة، المباني السكنية',1,'2026-07-15 14:02:15','2026-07-16 09:48:38'),
(15,'EDEVAL','في أن إس أ','edeval','EDEVAL',NULL,'Alger',NULL,NULL,NULL,'المساحات الخضراء - الحدائق، المساحات الخضراء، الأشجار، السقي، تقليم الأشجار، إزالة الأعشاب الضارة، صيانة المنحدرات، تهيئة المساحات الخضراء',1,'2026-07-15 14:02:15','2026-07-16 09:49:07'),
(16,'مديرية الصيد البحري','مديرية الصيد البحري','marine','MARINE',NULL,'Alger',NULL,NULL,NULL,'مديرية الصيد البحري - قوارب الصيد، تجهيزات الصيد، الموانئ الصغيرة',1,'2026-07-15 14:02:15','2026-07-16 09:49:07'),
(17,'المقاطعة الإدارية','التقطيعة الإدارية','district','DISTRICT',NULL,'Alger',NULL,NULL,NULL,'المقاطعة الإدارية - الإشراف على البلديات، متابعة المشاريع، التنسيق بين المؤسسات، متابعة تنفيذ الأشغال، مراقبة الأداء المحلي',1,'2026-07-15 14:02:15','2026-07-16 09:49:07'),
(18,'EGPFC','المقابر','egpfc','EGPFC',NULL,NULL,NULL,NULL,NULL,'المقابر - المقابر، الجنائز، الحدائق الكبرى، صيانة المقابر',1,'2026-07-16 09:49:07','2026-07-16 09:49:07'),
(19,'OPLA','الملاعب والمنشآت الرياضية','opla','OPLA',NULL,NULL,NULL,NULL,NULL,'الملاعب الجوارية، المنشآت الرياضية، فضاءات التسلية',1,'2026-07-16 09:49:07','2026-07-16 09:49:07'),
(20,'WILAYA','ولاية الجزائر','wilaya','WILAYA',NULL,NULL,NULL,NULL,NULL,'ولاية الجزائر - الإشراف العام على المنصة، متابعة جميع البلاغات، مراقبة أداء المؤسسات، استخراج الإحصائيات، إدارة جميع المستخدمين، مراقبة آجال المعالجة، متابعة مؤشرات الأداء (KPI)، إصدار التقارير',1,'2026-07-16 09:49:07','2026-07-16 09:49:07');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `label` varchar(150) NOT NULL,
  `module` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `uk_module_action` (`module`,`action`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'reports.view','Voir les signalements','reports','view',NULL,'2026-07-15 14:01:50'),
(2,'reports.create','Créer un signalement','reports','create',NULL,'2026-07-15 14:01:50'),
(3,'reports.update','Modifier un signalement','reports','update',NULL,'2026-07-15 14:01:50'),
(4,'reports.delete','Supprimer un signalement','reports','delete',NULL,'2026-07-15 14:01:50'),
(5,'reports.assign','Assigner un signalement','reports','assign',NULL,'2026-07-15 14:01:50'),
(6,'reports.resolve','Résoudre un signalement','reports','resolve',NULL,'2026-07-15 14:01:50'),
(7,'reports.comment','Commenter un signalement','reports','comment',NULL,'2026-07-15 14:01:50'),
(8,'reports.export','Exporter les signalements','reports','export',NULL,'2026-07-15 14:01:50'),
(9,'reports.view_all','Voir tous les signalements','reports','view_all',NULL,'2026-07-15 14:01:50'),
(10,'reports.view_assigned','Voir les signalements assignés','reports','view_assigned',NULL,'2026-07-15 14:01:50'),
(11,'users.view','Voir les utilisateurs','users','view',NULL,'2026-07-15 14:01:50'),
(12,'users.create','Créer un utilisateur','users','create',NULL,'2026-07-15 14:01:50'),
(13,'users.update','Modifier un utilisateur','users','update',NULL,'2026-07-15 14:01:50'),
(14,'users.delete','Supprimer un utilisateur','users','delete',NULL,'2026-07-15 14:01:50'),
(15,'users.suspend','Suspendre un utilisateur','users','suspend',NULL,'2026-07-15 14:01:50'),
(16,'organizations.view','Voir les organismes','organizations','view',NULL,'2026-07-15 14:01:50'),
(17,'organizations.create','Créer un organisme','organizations','create',NULL,'2026-07-15 14:01:50'),
(18,'organizations.update','Modifier un organisme','organizations','update',NULL,'2026-07-15 14:01:50'),
(19,'organizations.delete','Supprimer un organisme','organizations','delete',NULL,'2026-07-15 14:01:50'),
(20,'dairas.view','Voir les daïras','dairas','view',NULL,'2026-07-15 14:01:50'),
(21,'dairas.manage','Gérer les daïras','dairas','manage',NULL,'2026-07-15 14:01:50'),
(22,'categories.view','Voir les catégories','categories','view',NULL,'2026-07-15 14:01:50'),
(23,'categories.manage','Gérer les catégories','categories','manage',NULL,'2026-07-15 14:01:50'),
(24,'dashboard.view','Voir le tableau de bord','dashboard','view',NULL,'2026-07-15 14:01:50'),
(25,'dashboard.stats','Voir les statistiques','dashboard','stats',NULL,'2026-07-15 14:01:50'),
(26,'settings.view','Voir les paramètres','settings','view',NULL,'2026-07-15 14:01:50'),
(27,'settings.update','Modifier les paramètres','settings','update',NULL,'2026-07-15 14:01:50'),
(28,'audit.view','Voir le journal d audit','audit','view',NULL,'2026-07-15 14:01:50'),
(29,'notifications.view','Voir les notifications','notifications','view',NULL,'2026-07-15 14:01:50'),
(30,'notifications.manage','Gérer les notifications','notifications','manage',NULL,'2026-07-15 14:01:50'),
(31,'reports.reassign','Réaffecter un signalement','reports','reassign',NULL,'2026-07-16 11:04:06'),
(32,'reports.redirect','Rediriger vers un autre organisme','reports','redirect',NULL,'2026-07-16 11:04:06'),
(33,'users.manage_org','Gérer les utilisateurs de l\'organisme','users','manage_org',NULL,'2026-07-16 11:04:06'),
(34,'reports.view_org','Voir les signalements de l\'organisme','reports','view_org',NULL,'2026-07-16 11:04:06'),
(43,'landing.manage','Gérer la page d\'accueil','landing','manage','Contrôle du contenu de la landing page','2026-07-20 15:06:15');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `push_subscriptions`
--

DROP TABLE IF EXISTS `push_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `endpoint` text NOT NULL,
  `p256dh_key` varchar(255) DEFAULT NULL,
  `auth_key` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_subscriptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `push_subscriptions` WRITE;
/*!40000 ALTER TABLE `push_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `report_comments`
--

DROP TABLE IF EXISTS `report_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `comment` text NOT NULL,
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `report_comments_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_comments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `report_comments` WRITE;
/*!40000 ALTER TABLE `report_comments` DISABLE KEYS */;
INSERT INTO `report_comments` VALUES
(1,8,11,'bien',0,'2026-07-16 10:41:14','2026-07-16 10:41:14',NULL),
(2,7,1,'Bien degrader',0,'2026-07-16 10:54:51','2026-07-16 10:54:51',NULL),
(3,9,3,'bien',0,'2026-07-19 10:34:05','2026-07-19 10:34:05',NULL),
(4,7,11,'verfier par wilaya',0,'2026-07-19 10:47:46','2026-07-19 10:47:46',NULL),
(5,22,1,'urgent',0,'2026-07-19 11:41:35','2026-07-19 11:41:35',NULL),
(6,22,12,'daccord',0,'2026-07-19 12:10:01','2026-07-19 12:10:01',NULL),
(7,21,1,'cc',0,'2026-07-19 14:20:51','2026-07-19 14:20:51',NULL),
(8,24,10,'verfier',0,'2026-07-20 09:27:21','2026-07-20 09:27:21',NULL),
(9,30,10,'étudie bien ce cas',0,'2026-07-20 12:53:42','2026-07-20 12:53:42',NULL),
(10,31,1,'bien',0,'2026-07-21 10:41:33','2026-07-21 10:41:33',NULL),
(11,32,48,'bien recu',0,'2026-07-21 14:30:45','2026-07-21 14:30:45',NULL),
(12,30,45,'Merci Pour la rapidete',0,'2026-07-23 11:16:48','2026-07-23 11:16:48',NULL),
(13,47,45,'Merci Pour la rapidete',0,'2026-07-26 13:27:42','2026-07-26 13:27:42',NULL),
(14,23,45,'bien',0,'2026-07-27 12:10:14','2026-07-27 12:10:14',NULL),
(15,23,45,'Merci Pour la rapidete',0,'2026-07-27 12:10:20','2026-07-27 12:10:20',NULL),
(16,19,45,'verfier par wilaya',0,'2026-07-27 12:10:33','2026-07-27 12:10:33',NULL),
(17,47,45,'bien',0,'2026-07-27 12:10:44','2026-07-27 12:10:44',NULL),
(18,47,45,'verfier par wilaya',0,'2026-07-27 12:10:54','2026-07-27 12:10:54',NULL),
(19,47,45,'?',0,'2026-07-27 14:41:01','2026-07-27 14:41:01',NULL),
(20,51,1,'trés bien bon travail !',0,'2026-07-29 12:50:33','2026-07-29 12:50:33',NULL),
(21,53,79,'G',0,'2026-07-30 08:10:11','2026-07-30 08:10:11',NULL);
/*!40000 ALTER TABLE `report_comments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `report_history`
--

DROP TABLE IF EXISTS `report_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `report_history_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_history_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `report_history` WRITE;
/*!40000 ALTER TABLE `report_history` DISABLE KEYS */;
INSERT INTO `report_history` VALUES
(1,7,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-16 09:31:42'),
(2,7,10,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-16 09:40:13'),
(3,7,11,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-16 09:41:08'),
(4,7,12,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-16 09:41:23'),
(5,7,13,'intervention_started',NULL,'Intervention démarrée',NULL,36.7866000,3.0614000,NULL,'2026-07-16 09:41:36'),
(6,7,13,'photo_upload',NULL,'Photo  ajoutée: test_after.jpg',NULL,NULL,NULL,NULL,'2026-07-16 09:44:56'),
(7,7,13,'intervention_completed',NULL,'Intervention terminée par l\'agent',NULL,NULL,NULL,NULL,'2026-07-16 09:45:03'),
(8,7,10,'intervention_validated',NULL,'Travaux validés par le chef',NULL,NULL,NULL,NULL,'2026-07-16 09:45:17'),
(9,7,1,'closed',NULL,'Dossier clôturé',NULL,NULL,NULL,NULL,'2026-07-16 09:45:32'),
(10,7,1,'status_change',NULL,'resolved',NULL,NULL,NULL,NULL,'2026-07-16 09:51:24'),
(11,7,1,'status_change',NULL,'submitted',NULL,NULL,NULL,NULL,'2026-07-16 09:51:38'),
(12,7,1,'status_change',NULL,'resolved',NULL,NULL,NULL,NULL,'2026-07-16 09:51:47'),
(13,8,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-16 09:54:21'),
(14,8,1,'assign',NULL,'Assigné à l\'utilisateur #9',NULL,NULL,NULL,NULL,'2026-07-16 09:58:20'),
(15,8,9,'status_change',NULL,'in_progress',NULL,NULL,NULL,NULL,'2026-07-16 09:59:02'),
(16,8,9,'photo_upload',NULL,'Photo during ajoutée: OIP.jpg',NULL,NULL,NULL,NULL,'2026-07-16 09:59:23'),
(17,9,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-16 10:43:03'),
(18,7,1,'status_change',NULL,'in_progress',NULL,NULL,NULL,NULL,'2026-07-16 10:56:02'),
(19,7,1,'assign',NULL,'Assigné à l\'utilisateur #13',NULL,NULL,NULL,NULL,'2026-07-16 10:56:04'),
(20,16,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-16 11:26:59'),
(21,16,10,'assign',NULL,'Assigné à l\'utilisateur #11',NULL,NULL,NULL,NULL,'2026-07-16 11:28:21'),
(22,17,18,'auto_assign_central',NULL,'Affecté automatiquement à Brahim Zeroual (resp_central)',NULL,NULL,NULL,NULL,'2026-07-16 11:50:38'),
(23,16,11,'assign',NULL,'Assigné à l\'utilisateur #3',NULL,NULL,NULL,NULL,'2026-07-19 10:01:47'),
(24,17,1,'status_change',NULL,'in_progress',NULL,NULL,NULL,NULL,'2026-07-19 10:02:27'),
(25,19,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-19 10:26:09'),
(26,20,1,'status_change',NULL,'acknowledged',NULL,NULL,NULL,NULL,'2026-07-19 10:57:47'),
(27,21,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-19 11:38:43'),
(28,22,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-19 11:38:44'),
(29,22,1,'assign',NULL,'Assigné à l\'utilisateur #10',NULL,NULL,NULL,NULL,'2026-07-19 11:41:24'),
(30,8,9,'status_change',NULL,'resolved',NULL,NULL,NULL,NULL,'2026-07-19 12:01:52'),
(31,22,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-19 12:07:22'),
(32,22,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-19 12:08:04'),
(33,22,11,'status_change',NULL,'in_progress',NULL,NULL,NULL,NULL,'2026-07-19 12:08:49'),
(34,22,11,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-19 12:09:09'),
(35,22,12,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-19 12:09:49'),
(36,22,9,'intervention_started',NULL,'Intervention démarrée sur place',NULL,36.7754140,3.0605240,NULL,'2026-07-19 12:10:39'),
(37,22,9,'intervention_started',NULL,'Intervention démarrée sur place',NULL,36.7754140,3.0605240,NULL,'2026-07-19 12:11:00'),
(38,22,9,'photo_upload',NULL,'Photo after ajoutée: e567aa60-0009-400b-8406-d6ed34089fe7.jpg',NULL,NULL,NULL,NULL,'2026-07-19 12:11:07'),
(39,22,1,'status_change',NULL,'resolved',NULL,NULL,NULL,NULL,'2026-07-19 12:18:57'),
(40,22,1,'closed',NULL,'Dossier clôturé définitivement',NULL,NULL,NULL,NULL,'2026-07-19 12:20:39'),
(41,21,1,'status_change',NULL,'rejected',NULL,NULL,NULL,NULL,'2026-07-19 12:22:14'),
(42,21,1,'assign',NULL,'Assigné à l\'utilisateur #10',NULL,NULL,NULL,NULL,'2026-07-19 14:33:45'),
(43,23,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-20 09:21:39'),
(44,24,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-20 09:21:41'),
(45,23,1,'status_change',NULL,'in_progress',NULL,NULL,NULL,NULL,'2026-07-20 09:22:52'),
(46,24,10,'status_change',NULL,'in_progress',NULL,NULL,NULL,NULL,'2026-07-20 09:23:46'),
(47,24,10,'assign',NULL,'Assigné à l\'utilisateur #11',NULL,NULL,NULL,NULL,'2026-07-20 09:23:52'),
(48,24,11,'assign',NULL,'Assigné à l\'utilisateur #5',NULL,NULL,NULL,NULL,'2026-07-20 09:24:50'),
(49,24,11,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-20 09:25:34'),
(50,24,5,'status_change',NULL,'resolved',NULL,NULL,NULL,NULL,'2026-07-20 09:26:06'),
(51,24,5,'status_change',NULL,'closed',NULL,NULL,NULL,NULL,'2026-07-20 09:36:21'),
(52,15,1,'assign',NULL,'Assigné à l\'utilisateur #21',NULL,NULL,NULL,NULL,'2026-07-20 12:47:54'),
(53,30,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-20 12:52:16'),
(54,30,10,'assign',NULL,'Assigné à l\'utilisateur #3',NULL,NULL,NULL,NULL,'2026-07-20 12:53:23'),
(55,30,10,'status_change',NULL,'acknowledged',NULL,NULL,NULL,NULL,'2026-07-20 12:53:28'),
(56,30,10,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-20 12:55:55'),
(57,30,10,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-20 12:57:39'),
(58,30,10,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-20 12:57:55'),
(59,18,1,'redirect','Organisme #1','Redirigé vers ASROUT (#2)',NULL,NULL,NULL,NULL,'2026-07-20 13:05:53'),
(60,18,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-20 13:05:53'),
(61,18,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-20 13:06:18'),
(62,18,11,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-20 13:06:19'),
(63,18,12,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-20 13:06:20'),
(64,30,1,'redirect','Organisme #2','Redirigé vers ASROUT (#2)',NULL,NULL,NULL,NULL,'2026-07-20 13:08:21'),
(65,30,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-20 13:08:21'),
(66,3,1,'status_change',NULL,'pending_review','',NULL,NULL,NULL,'2026-07-20 13:13:12'),
(67,3,1,'status_change',NULL,'validated','',NULL,NULL,NULL,'2026-07-20 13:13:21'),
(68,3,1,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-20 13:13:26'),
(69,3,1,'status_change',NULL,'validated','',NULL,NULL,NULL,'2026-07-20 13:13:30'),
(70,3,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-20 13:13:39'),
(71,30,1,'status_change',NULL,'validated','',NULL,NULL,NULL,'2026-07-20 13:16:16'),
(72,30,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-20 13:16:29'),
(73,31,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-21 08:01:13'),
(74,31,11,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-21 08:03:09'),
(75,31,3,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-21 08:04:03'),
(76,31,4,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-21 08:04:30'),
(77,31,4,'intervention_started',NULL,'Intervention démarrée sur place',NULL,36.7954000,3.0554000,NULL,'2026-07-21 08:04:52'),
(78,31,4,'photo_upload',NULL,'Photo after ajoutée: apre.jpeg',NULL,NULL,NULL,NULL,'2026-07-21 08:05:17'),
(79,31,10,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-21 08:06:27'),
(80,32,1,'redirect','Organisme #1','Redirigé vers ASROUT (#2)',NULL,NULL,NULL,NULL,'2026-07-21 11:47:34'),
(81,32,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-21 11:47:34'),
(82,32,10,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-21 12:13:37'),
(83,32,5,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-21 12:14:16'),
(84,32,5,'intervention_started',NULL,'Intervention démarrée sur place',NULL,36.7954000,3.0554000,NULL,'2026-07-21 12:14:27'),
(85,32,5,'photo_upload',NULL,'Photo after ajoutée: WhatsApp Image 2026-07-21 at 08.48.39.jpeg',NULL,NULL,NULL,NULL,'2026-07-21 12:15:12'),
(86,32,1,'status_change',NULL,'validated','',NULL,NULL,NULL,'2026-07-21 12:16:06'),
(87,36,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 11:08:34'),
(88,37,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 11:46:51'),
(89,37,1,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-22 11:47:47'),
(90,38,66,'auto_assign_central',NULL,'Affecté automatiquement à رشيد تيموشت (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 11:51:20'),
(91,38,66,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 11:52:16'),
(92,38,66,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-22 11:52:20'),
(93,38,66,'status_change',NULL,'assigned','',NULL,NULL,NULL,'2026-07-22 11:52:36'),
(94,38,66,'status_change',NULL,'acknowledged','',NULL,NULL,NULL,'2026-07-22 11:52:43'),
(95,38,66,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 11:52:49'),
(96,38,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 11:53:50'),
(97,38,65,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-22 12:03:22'),
(98,38,65,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-22 12:03:32'),
(99,38,65,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-22 12:23:14'),
(100,40,66,'auto_assign_central',NULL,'Affecté automatiquement à رشيد تيموشت (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 12:30:27'),
(101,40,71,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 12:30:53'),
(102,41,66,'auto_assign_central',NULL,'Affecté automatiquement à رشيد تيموشت (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 12:31:35'),
(103,42,66,'auto_assign_central',NULL,'Affecté automatiquement à رشيد تيموشت (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 12:32:11'),
(104,43,66,'auto_assign_central',NULL,'Affecté automatiquement à رشيد تيموشت (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 12:32:39'),
(105,43,71,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 12:33:03'),
(106,43,71,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 12:33:24'),
(107,44,66,'auto_assign_central',NULL,'Affecté automatiquement à رشيد تيموشت (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 12:33:57'),
(108,44,71,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 12:34:22'),
(109,45,66,'auto_assign_central',NULL,'Affecté automatiquement à رشيد تيموشت (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 12:35:16'),
(110,45,1,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-22 12:36:39'),
(111,45,71,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 12:36:42'),
(112,42,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-22 12:37:12'),
(113,46,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-22 13:11:45'),
(114,46,10,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-22 13:13:03'),
(115,46,10,'status_change',NULL,'assigned','',NULL,NULL,NULL,'2026-07-22 13:13:06'),
(116,45,70,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-22 13:13:07'),
(117,45,70,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-22 13:13:22'),
(118,45,69,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-22 13:13:44'),
(119,46,3,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-22 13:14:34'),
(120,46,3,'status_change',NULL,'pending_unite','',NULL,NULL,NULL,'2026-07-22 13:14:40'),
(121,45,68,'intervention_started',NULL,'Intervention démarrée sur place',NULL,NULL,NULL,NULL,'2026-07-22 13:14:56'),
(122,45,68,'photo_upload',NULL,'Photo after ajoutée: test_after.jpg',NULL,NULL,NULL,NULL,'2026-07-22 13:16:44'),
(123,45,68,'intervention_completed',NULL,'Intervention terminée - en attente de validation du chef de section',NULL,NULL,NULL,NULL,'2026-07-22 13:16:55'),
(124,45,69,'section_validated',NULL,'Validé par le chef de section - en attente de validation du chef d\'unité',NULL,NULL,NULL,NULL,'2026-07-22 13:17:06'),
(125,45,70,'unite_validated',NULL,'Validé par le chef d\'unité - dossier approuvé',NULL,NULL,NULL,NULL,'2026-07-22 13:19:11'),
(126,46,1,'unite_validated',NULL,'Validé par le chef d\'unité - dossier approuvé',NULL,NULL,NULL,NULL,'2026-07-22 13:21:28'),
(127,46,3,'status_change',NULL,'pending_unite','',NULL,NULL,NULL,'2026-07-22 14:30:10'),
(128,46,3,'status_change',NULL,'pending_unite','',NULL,NULL,NULL,'2026-07-23 09:57:42'),
(129,46,1,'status_change',NULL,'validated','',NULL,NULL,NULL,'2026-07-23 11:06:40'),
(130,44,1,'status_change',NULL,'validated','',NULL,NULL,NULL,'2026-07-23 11:07:59'),
(131,43,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-23 11:08:10'),
(132,43,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-23 11:08:15'),
(133,46,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:08:33'),
(134,38,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:08:47'),
(135,21,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:09:46'),
(136,45,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:10:12'),
(137,44,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:10:25'),
(138,42,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:10:33'),
(139,41,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:10:41'),
(140,40,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:10:54'),
(141,37,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:11:05'),
(142,36,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-23 11:11:19'),
(143,47,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-26 13:19:27'),
(144,47,1,'status_change',NULL,'assigned','',NULL,NULL,NULL,'2026-07-26 13:21:37'),
(145,47,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-26 13:22:26'),
(146,47,11,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-26 13:23:22'),
(147,47,3,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-26 13:24:24'),
(148,47,5,'photo_upload',NULL,'Photo after ajoutée: Capture d\'écran 2026-07-14 150023.png',NULL,NULL,NULL,NULL,'2026-07-26 13:25:15'),
(149,47,5,'intervention_completed',NULL,'Intervention terminée - en attente de validation du chef de section',NULL,NULL,NULL,NULL,'2026-07-26 13:25:32'),
(150,47,3,'section_validated',NULL,'Validé par le chef de section - en attente de validation du chef d\'unité',NULL,NULL,NULL,NULL,'2026-07-26 13:26:15'),
(151,47,1,'unite_validated',NULL,'Validé par le chef d\'unité - dossier approuvé',NULL,NULL,NULL,NULL,'2026-07-26 13:27:00'),
(152,48,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-26 14:40:15'),
(153,48,1,'status_change',NULL,'assigned','',NULL,NULL,NULL,'2026-07-26 14:42:22'),
(154,48,10,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-26 14:45:40'),
(155,48,10,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-26 14:45:45'),
(156,48,11,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-26 14:54:28'),
(157,48,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 09:05:38'),
(158,46,1,'closed',NULL,'Dossier clôturé définitivement',NULL,NULL,NULL,NULL,'2026-07-27 12:49:09'),
(159,38,1,'closed',NULL,'Dossier clôturé définitivement',NULL,NULL,NULL,NULL,'2026-07-27 12:49:14'),
(160,21,1,'closed',NULL,'Dossier clôturé définitivement',NULL,NULL,NULL,NULL,'2026-07-27 12:49:22'),
(161,23,1,'status_change',NULL,'acknowledged','',NULL,NULL,NULL,'2026-07-27 12:50:42'),
(162,23,1,'status_change',NULL,'acknowledged','',NULL,NULL,NULL,'2026-07-27 12:50:45'),
(163,23,1,'status_change',NULL,'assigned','',NULL,NULL,NULL,'2026-07-27 12:50:53'),
(164,46,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 12:51:05'),
(165,48,1,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-27 12:55:12'),
(166,21,1,'redirect','Organisme #2','Redirigé vers ASROUT (#2)',NULL,NULL,NULL,NULL,'2026-07-27 12:59:03'),
(167,21,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-27 12:59:03'),
(168,21,1,'status_change',NULL,'assigned','',NULL,NULL,NULL,'2026-07-27 12:59:18'),
(169,48,1,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-27 13:49:02'),
(170,48,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 14:04:53'),
(171,48,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 14:04:56'),
(172,48,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 14:05:31'),
(173,48,1,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-27 14:06:34'),
(174,48,1,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-27 14:06:38'),
(175,48,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 14:06:50'),
(176,48,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 14:13:01'),
(177,48,1,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-27 14:13:06'),
(178,48,1,'status_change',NULL,'rejected','',NULL,NULL,NULL,'2026-07-27 14:37:59'),
(179,48,1,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-27 14:38:05'),
(180,51,1,'redirect','Organisme #1','Redirigé vers ASROUT (#2)',NULL,NULL,NULL,NULL,'2026-07-29 12:36:07'),
(181,51,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-29 12:36:07'),
(182,51,10,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-29 12:36:49'),
(183,51,10,'status_change',NULL,'assigned','',NULL,NULL,NULL,'2026-07-29 12:36:52'),
(184,51,11,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-29 12:37:30'),
(185,51,3,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-29 12:38:19'),
(186,51,13,'photo_upload',NULL,'Photo after ajoutée: Gemini_Generated_Image_llfs7gllfs7gllfs.png',NULL,NULL,NULL,NULL,'2026-07-29 12:42:03'),
(187,51,13,'intervention_completed',NULL,'Intervention terminée - en attente de validation du chef de section',NULL,NULL,NULL,NULL,'2026-07-29 12:42:10'),
(188,51,10,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-29 12:42:27'),
(189,7,10,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-29 12:42:40'),
(190,31,47,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-29 12:47:54'),
(191,51,1,'closed',NULL,'Dossier clôturé définitivement',NULL,NULL,NULL,NULL,'2026-07-29 12:50:20'),
(192,18,13,'intervention_started',NULL,'Intervention démarrée sur place',NULL,36.7753140,3.0614970,NULL,'2026-07-29 12:57:48'),
(193,18,13,'intervention_started',NULL,'Intervention démarrée sur place',NULL,36.7753140,3.0614970,NULL,'2026-07-29 12:57:52'),
(194,30,45,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-29 13:20:56'),
(195,46,1,'status_change',NULL,'resolved','',NULL,NULL,NULL,'2026-07-29 15:00:59'),
(196,46,1,'status_change',NULL,'closed','',NULL,NULL,NULL,'2026-07-29 15:01:10'),
(197,52,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-29 15:05:21'),
(198,52,10,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-29 15:06:55'),
(199,52,1,'assign_chef_unite',NULL,'Assigné au Chef d\'Unité',NULL,NULL,NULL,NULL,'2026-07-29 15:08:44'),
(200,52,11,'assign_chef_section',NULL,'Assigné au Chef de Section',NULL,NULL,NULL,NULL,'2026-07-29 15:09:35'),
(201,52,3,'assign_agent',NULL,'Assigné à l\'agent intervenant',NULL,NULL,NULL,NULL,'2026-07-29 15:10:01'),
(202,52,3,'status_change',NULL,'in_progress','',NULL,NULL,NULL,'2026-07-29 15:10:06'),
(203,52,4,'intervention_started',NULL,'Intervention démarrée sur place',NULL,NULL,NULL,NULL,'2026-07-29 15:10:30'),
(204,52,4,'photo_upload',NULL,'Photo after ajoutée: 21.jpeg',NULL,NULL,NULL,NULL,'2026-07-29 15:11:07'),
(205,52,4,'intervention_completed',NULL,'Intervention terminée - en attente de validation du chef de section',NULL,NULL,NULL,NULL,'2026-07-29 15:11:10'),
(206,52,3,'section_validated',NULL,'Validé par le chef de section - en attente de validation du chef d\'unité',NULL,NULL,NULL,NULL,'2026-07-29 15:13:52'),
(207,52,11,'unite_validated',NULL,'Validé par le chef d\'unité - dossier approuvé',NULL,NULL,NULL,NULL,'2026-07-29 15:15:24'),
(208,53,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-30 06:30:00'),
(209,54,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-30 06:30:02'),
(210,55,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-30 06:30:04'),
(211,56,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-30 06:30:13'),
(212,57,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-30 06:30:15'),
(213,58,10,'auto_assign_central',NULL,'Affecté automatiquement à Ahmed Benmalek (resp_central)',NULL,NULL,NULL,NULL,'2026-07-30 06:30:15'),
(214,58,1,'deleted',NULL,'Signalement supprimé',NULL,NULL,NULL,NULL,'2026-07-30 06:47:53'),
(215,57,1,'deleted',NULL,'Signalement supprimé',NULL,NULL,NULL,NULL,'2026-07-30 06:47:57'),
(216,56,1,'deleted',NULL,'Signalement supprimé',NULL,NULL,NULL,NULL,'2026-07-30 06:48:01'),
(217,55,1,'deleted',NULL,'Signalement supprimé',NULL,NULL,NULL,NULL,'2026-07-30 06:48:06'),
(218,54,1,'deleted',NULL,'Signalement supprimé',NULL,NULL,NULL,NULL,'2026-07-30 06:48:09');
/*!40000 ALTER TABLE `report_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `report_images`
--

DROP TABLE IF EXISTS `report_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` int(10) unsigned NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  CONSTRAINT `report_images_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_images`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `report_images` WRITE;
/*!40000 ALTER TABLE `report_images` DISABLE KEYS */;
INSERT INTO `report_images` VALUES
(5,30,'BA-2026-144866_1.png','1.png','image/png',1763620,1,'2026-07-20 12:52:16'),
(6,31,'BA-2026-316710_1.jpg','WhatsApp Image 2026-07-21 at 08.56.11.jpeg','image/jpeg',221150,1,'2026-07-21 08:01:13'),
(7,32,'BA-2026-577793_1.jpg','anomalie.jpeg','image/jpeg',327516,1,'2026-07-21 11:46:42'),
(8,33,'BA-2026-343390_1.jpg','apre.jpeg','image/jpeg',188845,1,'2026-07-21 13:15:34'),
(9,34,'BA-2026-592035_1.jpg','adem .jpeg','image/jpeg',217326,1,'2026-07-22 10:25:02'),
(10,37,'BA-2026-377442_1.jpg','apre.jpeg','image/jpeg',188845,1,'2026-07-22 11:38:18'),
(11,38,'BA-2026-703167_1.jpg','WhatsApp Image 2026-07-21 at 08.48.39.jpeg','image/jpeg',172286,1,'2026-07-22 11:51:20'),
(12,47,'BA-2026-949108_1.png','Capture d\'écran 2026-07-22 125745.png','image/png',836812,1,'2026-07-26 13:19:27'),
(13,48,'BA-2026-308430_1.jpg','17850767147185888332387254796769.jpg','image/jpeg',62997,1,'2026-07-26 14:40:15'),
(14,48,'BA-2026-308430_2.jpg','17850767147185888332387254796769.jpg','image/jpeg',62997,0,'2026-07-26 14:40:15'),
(15,50,'BA-2026-722710_1.jpg','Capture d’écran_9-1-2025_14348_meet.google.com.jpeg','image/jpeg',22624,1,'2026-07-27 17:21:21'),
(16,51,'BA-2026-566906_1.jpg','17853283493131067418870742970460.jpg','image/jpeg',2031339,1,'2026-07-29 12:34:37'),
(17,51,'BA-2026-566906_2.jpg','17853283493131067418870742970460.jpg','image/jpeg',2031339,0,'2026-07-29 12:34:37'),
(18,52,'BA-2026-352767_1.jpg','unnamed - 2026-02-22T144004.546.jpg','image/jpeg',637825,1,'2026-07-29 15:05:21');
/*!40000 ALTER TABLE `report_images` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `report_interventions`
--

DROP TABLE IF EXISTS `report_interventions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_interventions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) unsigned NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `status` enum('assigned','in_progress','completed','validated_by_section','validated','rejected') NOT NULL DEFAULT 'assigned',
  `description` text DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `validated_by` bigint(20) unsigned DEFAULT NULL,
  `validated_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  KEY `agent_id` (`agent_id`),
  KEY `validated_by` (`validated_by`),
  CONSTRAINT `report_interventions_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_interventions_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_interventions_ibfk_3` FOREIGN KEY (`validated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_interventions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `report_interventions` WRITE;
/*!40000 ALTER TABLE `report_interventions` DISABLE KEYS */;
INSERT INTO `report_interventions` VALUES
(1,7,13,'validated','0',36.7866000,3.0614000,'2026-07-16 09:41:36','2026-07-16 09:45:03',10,'2026-07-16 09:45:17',NULL,'2026-07-16 09:41:36','2026-07-16 09:45:17'),
(2,8,9,'in_progress',NULL,NULL,NULL,'2026-07-16 09:59:23',NULL,NULL,NULL,NULL,'2026-07-16 09:59:23','2026-07-16 09:59:23'),
(3,22,9,'in_progress','',36.7754140,3.0605240,'2026-07-19 12:10:39',NULL,NULL,NULL,NULL,'2026-07-19 12:10:39','2026-07-19 12:10:39'),
(4,22,9,'in_progress','',36.7754140,3.0605240,'2026-07-19 12:11:00',NULL,NULL,NULL,NULL,'2026-07-19 12:11:00','2026-07-19 12:11:00'),
(5,31,4,'in_progress','',36.7954000,3.0554000,'2026-07-21 08:04:52',NULL,NULL,NULL,NULL,'2026-07-21 08:04:52','2026-07-21 08:04:52'),
(6,32,5,'in_progress','',36.7954000,3.0554000,'2026-07-21 12:14:27',NULL,NULL,NULL,NULL,'2026-07-21 12:14:27','2026-07-21 12:14:27'),
(7,45,68,'validated',' Intervention terminee',NULL,NULL,'2026-07-22 13:14:56','2026-07-22 13:16:55',70,'2026-07-22 13:19:11',NULL,'2026-07-22 13:14:56','2026-07-22 13:19:11'),
(8,47,5,'validated',' ',NULL,NULL,'2026-07-26 13:25:15','2026-07-26 13:25:32',1,'2026-07-26 13:27:00',NULL,'2026-07-26 13:25:15','2026-07-26 13:27:00'),
(9,51,13,'completed',' ',NULL,NULL,'2026-07-29 12:42:03','2026-07-29 12:42:10',NULL,NULL,NULL,'2026-07-29 12:42:03','2026-07-29 12:42:10'),
(10,18,13,'in_progress','',36.7753140,3.0614970,'2026-07-29 12:57:48',NULL,NULL,NULL,NULL,'2026-07-29 12:57:48','2026-07-29 12:57:48'),
(11,18,13,'in_progress','',36.7753140,3.0614970,'2026-07-29 12:57:52',NULL,NULL,NULL,NULL,'2026-07-29 12:57:52','2026-07-29 12:57:52'),
(12,52,4,'validated',' ',NULL,NULL,'2026-07-29 15:10:30','2026-07-29 15:11:10',11,'2026-07-29 15:15:24',NULL,'2026-07-29 15:10:30','2026-07-29 15:15:24');
/*!40000 ALTER TABLE `report_interventions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `report_ratings`
--

DROP TABLE IF EXISTS `report_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_ratings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) unsigned NOT NULL,
  `citizen_id` bigint(20) unsigned NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rating` (`report_id`,`citizen_id`),
  KEY `citizen_id` (`citizen_id`),
  CONSTRAINT `report_ratings_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_ratings_ibfk_2` FOREIGN KEY (`citizen_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_ratings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `report_ratings` WRITE;
/*!40000 ALTER TABLE `report_ratings` DISABLE KEYS */;
INSERT INTO `report_ratings` VALUES
(1,24,45,5,'bon service','2026-07-20 09:32:58'),
(2,31,47,5,'Merci c\'est trés rapide','2026-07-21 08:13:15'),
(3,22,45,5,'','2026-07-27 10:17:40'),
(4,21,45,5,'','2026-07-27 10:17:59'),
(5,51,45,5,'','2026-07-29 14:17:58');
/*!40000 ALTER TABLE `report_ratings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tracking_code` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `subcategory_id` bigint(20) unsigned DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `status` enum('submitted','acknowledged','assigned','in_progress','pending_review','pending_unite','validated','resolved','closed','rejected') NOT NULL DEFAULT 'submitted',
  `daira_id` bigint(20) unsigned NOT NULL,
  `commune_id` bigint(20) unsigned NOT NULL,
  `address` text DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `citizen_name` varchar(200) DEFAULT NULL,
  `citizen_phone` varchar(30) DEFAULT NULL,
  `citizen_email` varchar(150) DEFAULT NULL,
  `citizen_id` bigint(20) unsigned DEFAULT NULL,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `workflow_step` tinyint(3) unsigned DEFAULT 0,
  `assigned_to` bigint(20) unsigned DEFAULT NULL,
  `assigned_by` bigint(20) unsigned DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT NULL,
  `assigned_at_central` timestamp NULL DEFAULT NULL,
  `assigned_at_chef_unite` timestamp NULL DEFAULT NULL,
  `assigned_at_chef_section` timestamp NULL DEFAULT NULL,
  `assigned_at_agent` timestamp NULL DEFAULT NULL,
  `deadline_at` timestamp NULL DEFAULT NULL,
  `is_late` tinyint(1) DEFAULT 0,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolution_note` text DEFAULT NULL,
  `is_anonymous` tinyint(1) NOT NULL DEFAULT 0,
  `view_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_code` (`tracking_code`),
  KEY `subcategory_id` (`subcategory_id`),
  KEY `citizen_id` (`citizen_id`),
  KEY `assigned_by` (`assigned_by`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_category` (`category_id`),
  KEY `idx_daira` (`daira_id`),
  KEY `idx_commune` (`commune_id`),
  KEY `idx_organization` (`organization_id`),
  KEY `idx_assigned` (`assigned_to`),
  KEY `idx_created` (`created_at`),
  KEY `idx_tracking` (`tracking_code`),
  KEY `idx_reports_status_date` (`status`,`created_at`),
  KEY `idx_reports_assigned_status` (`assigned_to`,`status`),
  KEY `idx_reports_daira_status` (`daira_id`,`status`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_ibfk_3` FOREIGN KEY (`daira_id`) REFERENCES `dairas` (`id`),
  CONSTRAINT `reports_ibfk_4` FOREIGN KEY (`commune_id`) REFERENCES `communes` (`id`),
  CONSTRAINT `reports_ibfk_5` FOREIGN KEY (`citizen_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_ibfk_6` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_ibfk_7` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_ibfk_8` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES
(1,'BA-2026-000001','Nid-de-poule rue Didouche Mourad','Grand nid-de-poule dans la chaussée, risque d accident',1,NULL,'high','in_progress',12,49,'Rue Didouche Mourad, Alger Centre',36.7710000,3.0580000,'Ahmed Ben Salah','0555123456',NULL,6,10,4,14,14,'2026-07-16 09:31:42','2026-07-16 09:31:42',NULL,NULL,NULL,NULL,0,NULL,NULL,0,31,'2026-07-12 14:04:02','2026-07-28 12:21:54',NULL),
(2,'BA-2026-000002','Lampe éteinte Boulevard Krim Belkacem','Plusieurs lampes éteintes sur le boulevard',1,NULL,'medium','acknowledged',10,44,'Boulevard Krim Belkacem',36.7420000,3.0980000,'Sara Khelifi','0555234567',NULL,NULL,8,1,18,18,'2026-07-16 09:31:42','2026-07-16 09:31:42',NULL,NULL,NULL,NULL,0,NULL,NULL,0,5,'2026-07-13 14:04:02','2026-07-22 10:33:59',NULL),
(3,'BA-2026-000003','Dépôt sauvage route de Reghaia','Accumulation de déchets le long de la route',1,NULL,'urgent','resolved',11,47,'Route Nationale N 5',36.7680000,3.3510000,NULL,NULL,NULL,6,3,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-07-20 13:13:39','',0,11,'2026-07-14 14:04:02','2026-07-22 10:33:59',NULL),
(4,'BA-2026-000004','Fuite d eau avenue de la République','Fuite importante devant le centre commercial',1,NULL,'high','in_progress',5,20,'Avenue de la République',36.7650000,3.0120000,'Youcef Amrani','0555345678',NULL,NULL,7,4,21,21,'2026-07-16 09:31:42','2026-07-16 09:31:42',NULL,NULL,NULL,NULL,0,NULL,NULL,0,16,'2026-07-15 02:04:02','2026-07-29 15:35:52',NULL),
(5,'BA-2026-000005','Vandalisme salle de sport communale','Miroirs cassés et équipements détériorés',1,NULL,'low','validated',7,27,'Centre sportif Bab Ezzouar',36.7210000,3.1850000,'Nadia Bensalem','0555456789',NULL,6,9,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,6,'2026-07-10 14:04:02','2026-07-22 12:25:23',NULL),
(6,'BA-2026-999001','Éclairage défaillant avenue Didouche Mourad','Les lampadaires de l\'avenue ne fonctionnent plus depuis 3 jours, risque d\'insécurité',1,NULL,'high','submitted',12,49,'Avenue Didouche Mourad, Alger Centre',NULL,NULL,'adem hezil',NULL,'usaplay1406@gmail.com',6,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,5,'2026-07-16 09:06:34','2026-07-16 09:13:30',NULL),
(7,'BA-2026-TEST01','Dépôt sauvage rue des Frères Abbas','Il y a un gros tas de déchets en face du n°15, ça sent mauvais depuis une semaine.',1,NULL,'high','resolved',1,1,'15 Rue des Frères Abbas, Bab El Oued',36.7866000,3.0614000,NULL,NULL,NULL,9,2,7,13,1,'2026-07-16 10:56:04','2026-07-16 09:31:42','2026-07-16 09:40:13','2026-07-16 09:41:08','2026-07-16 09:41:23',NULL,0,'2026-07-29 12:42:40','',0,16,'2026-07-16 09:31:42','2026-07-29 12:42:40',NULL),
(8,'BA-2026-681739','hofra','hofra',1,NULL,'medium','resolved',1,1,'sdsd',36.7378050,2.9913710,'sdsd','sdsd','usaplay1406@gmail.com',1,2,1,9,1,'2026-07-16 09:58:20','2026-07-16 09:54:21',NULL,NULL,NULL,NULL,0,'2026-07-19 12:01:52','',0,16,'2026-07-16 09:54:21','2026-07-29 15:15:48',NULL),
(9,'BA-2026-727751','problem dans la zone','fdfdf',1,NULL,'medium','acknowledged',1,4,'cellule',36.7753140,3.0614970,'','','',1,2,1,10,10,'2026-07-16 10:43:03','2026-07-16 10:43:03',NULL,NULL,NULL,NULL,0,NULL,NULL,0,8,'2026-07-16 10:43:03','2026-07-22 10:33:59',NULL),
(12,'BA-2026-000010','Nid-de-poule rue Didouche Mourad','Grand nid-de-poule dangereux dans la chaussée',1,NULL,'high','assigned',1,1,'Rue Didouche Mourad, Bab El Oued',36.7900000,3.0500000,'Ahmed Ben Salah','0555123456',NULL,8,10,1,14,NULL,NULL,'2026-07-16 11:06:56',NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,'2026-07-13 11:06:56','2026-07-22 10:33:59',NULL),
(13,'BA-2026-000011','Trottoir endommagé Bab El Oued','Trottoir effondré devant l\'école',1,NULL,'medium','submitted',1,1,'Avenue principale Bab El Oued',36.7900000,3.0510000,'Sara Khelifi','0555234567',NULL,8,10,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,'2026-07-14 11:06:56','2026-07-22 10:33:59',NULL),
(14,'BA-2026-000012','Lampe éteinte Hussein Dey','Plusieurs lampes éteintes sur le boulevard',1,NULL,'medium','submitted',10,43,'Boulevard Krim Belkacem, Hussein Dey',36.7400000,3.1000000,'Sara Khelifi','0555234567',NULL,8,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,'2026-07-14 11:06:56','2026-07-22 10:33:59',NULL),
(15,'BA-2026-000013','Fuite d\'eau Draria','Fuite importante devant le centre commercial',1,NULL,'high','assigned',8,35,'Avenue de la République, Draria',36.7330000,2.9840000,'Youcef Amrani','0555345678',NULL,8,7,4,21,1,'2026-07-20 12:47:54',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,3,'2026-07-15 23:06:56','2026-07-27 09:57:20',NULL),
(16,'BA-2026-653539','Dégradation','dégradation de la chaussé',1,NULL,'medium','assigned',1,1,'3 horloges',36.7908790,3.0520530,'','','',1,2,1,3,11,'2026-07-19 10:01:47','2026-07-16 11:26:59',NULL,NULL,NULL,NULL,0,NULL,NULL,0,14,'2026-07-16 11:26:59','2026-07-22 10:33:59',NULL),
(17,'BA-2026-358666','coupe courant','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',1,NULL,'medium','in_progress',5,17,'3 horloges',36.7546160,3.0006410,'','','',43,8,1,18,18,'2026-07-16 11:50:38','2026-07-16 11:50:38',NULL,NULL,NULL,NULL,0,NULL,NULL,0,5,'2026-07-16 11:50:38','2026-07-22 10:33:59',NULL),
(18,'BA-2026-457733','dechet souvage ','xxxxx',1,NULL,'medium','in_progress',1,2,'sdsd',36.7909450,3.0518280,'','','',44,2,4,13,12,'2026-07-20 13:06:20','2026-07-20 13:05:53','2026-07-20 13:06:18','2026-07-20 13:06:19','2026-07-20 13:06:20',NULL,0,NULL,NULL,0,10,'2026-07-19 10:16:01','2026-07-29 12:57:41',NULL),
(19,'BA-2026-128338','Test nid de poule Hussein Dey','Voie endommagee rue principale',1,NULL,'high','acknowledged',10,44,'Rue principal Hussein Dey',36.7458000,3.1048000,'Citoyen Test',NULL,'citizen@test.com',45,2,1,10,10,'2026-07-19 10:26:09','2026-07-19 10:26:09',NULL,NULL,NULL,NULL,0,NULL,NULL,0,14,'2026-07-19 10:26:09','2026-07-29 13:21:08',NULL),
(20,'BA-2026-020224','Dechet sauvage ','Dechet sauvage  a babelouad ',1,NULL,'high','acknowledged',1,3,'3 HORLOGE',36.7909620,3.0517100,'','','',45,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,13,'2026-07-19 10:31:11','2026-07-29 13:22:24',NULL),
(21,'BA-2026-230859','xxx','xxxxx',1,NULL,'urgent','assigned',1,3,'3 horloge ',36.7909720,3.0517960,'','','',45,2,2,10,10,'2026-07-27 12:59:03','2026-07-27 12:59:03',NULL,NULL,NULL,NULL,0,'2026-07-23 11:09:46',' | Clôturé: ',0,18,'2026-07-19 11:38:43','2026-07-27 12:59:29',NULL),
(22,'BA-2026-660064','xxx','xxxxx',1,NULL,'urgent','closed',1,3,'3 horloge ',36.7909720,3.0517960,'','','',45,2,8,9,12,'2026-07-19 12:09:49','2026-07-19 11:38:44','2026-07-19 12:08:04','2026-07-19 12:09:09','2026-07-19 12:09:49',NULL,0,'2026-07-19 12:18:57',' | Clôturé: ',0,38,'2026-07-19 11:38:44','2026-07-28 12:34:08',NULL),
(23,'BA-2026-474010','تحطم جزء من الرصيف ','تحطم جزء من الرصيف ',1,NULL,'high','assigned',1,5,'3 HORLOGE',36.7856480,3.0439000,'','','',45,2,2,10,10,'2026-07-20 09:21:39','2026-07-20 09:21:39',NULL,NULL,NULL,'2026-07-30 08:21:39',0,NULL,NULL,0,20,'2026-07-20 09:21:39','2026-07-29 14:55:24',NULL),
(24,'BA-2026-188245','تحطم جزء من الرصيف ','تحطم جزء من الرصيف ',1,NULL,'high','closed',1,5,'3 HORLOGE',36.7856480,3.0439000,'','','',45,2,4,5,11,'2026-07-20 09:25:34','2026-07-20 09:21:41',NULL,NULL,'2026-07-20 09:25:34','2026-07-30 08:21:41',0,'2026-07-20 09:26:06','',0,32,'2026-07-20 09:21:41','2026-07-27 14:40:43',NULL),
(30,'BA-2026-144866','a','a',1,NULL,'medium','closed',7,27,'usthb',36.7191960,3.1813140,'','','',45,2,7,10,10,'2026-07-20 13:08:21','2026-07-20 13:08:21','2026-07-20 12:57:55',NULL,NULL,'2026-07-30 11:52:16',0,'2026-07-20 13:16:29',' | ',0,28,'2026-07-20 12:52:16','2026-07-29 13:20:56',NULL),
(31,'BA-2026-316710','وجود حاوية القمامة محطمة ','وجود حاوية القمامة محطمة و مهترئة على مستوى مدخل حي مختاري السعيد',1,NULL,'medium','closed',1,3,'3 HORLOGE',36.7889790,3.0504660,'','','',47,2,7,4,3,'2026-07-21 08:04:03','2026-07-21 08:01:13',NULL,'2026-07-21 08:03:09','2026-07-21 08:04:03','2026-07-31 08:01:13',0,'2026-07-21 08:06:27',' | ',0,46,'2026-07-21 08:01:13','2026-07-29 12:56:23',NULL),
(32,'BA-2026-577793','وجود نفايات صلبة و أثاث منزلية و ألواح خشبية ','وجود نفايات صلبة و أثاث منزلية و ألواح خشبية ملقاة ',1,NULL,'medium','validated',1,1,'3 HORLOGE',36.7904940,3.0529980,'mohamed ','0698140634','babou@balagh-alger.dz',48,2,7,5,10,'2026-07-21 12:13:37','2026-07-21 11:47:34',NULL,NULL,'2026-07-21 12:13:37','2026-07-28 11:46:42',0,NULL,NULL,0,33,'2026-07-21 11:46:42','2026-07-22 13:57:12',NULL),
(33,'BA-2026-343390','dfdf','dfdf',1,NULL,'high','submitted',1,1,'3 horloge ',36.7754140,3.0605240,'df','df','',48,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-28 13:15:34',0,NULL,NULL,0,4,'2026-07-21 13:15:34','2026-07-22 11:36:56',NULL),
(34,'BA-2026-592035','sdsd','sdsd',1,NULL,'high','submitted',9,39,'zsdsd',36.1874900,2.5762940,'','','',51,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-29 10:25:02',0,NULL,NULL,0,9,'2026-07-22 10:25:02','2026-07-27 17:14:39',NULL),
(35,'BA-2026-487225','		نفايات منزلية','نفايات منزلية',1,1,'high','submitted',1,2,'cellule',36.7754140,3.0605240,'','','',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-29 11:07:10',0,NULL,NULL,0,5,'2026-07-22 11:07:10','2026-07-27 17:11:27',NULL),
(36,'BA-2026-099487','نفايات صلبة ','نفايات صلبة ',7,13,'medium','resolved',3,9,'sdsd',36.6917540,3.1434630,'','','',1,2,7,10,10,'2026-07-22 11:08:34','2026-07-22 11:08:34',NULL,NULL,NULL,'2026-08-01 11:08:34',0,'2026-07-23 11:11:19','',0,4,'2026-07-22 11:08:34','2026-07-23 11:11:19',NULL),
(37,'BA-2026-377442','استغلال الغير قانوني لشواطئ ','استغلال الغير قانوني لشواطئ ',46,113,'high','resolved',13,57,'sable d\'or',36.7076160,2.8406520,'','','',48,9,7,68,1,'2026-07-22 11:47:46',NULL,'2026-07-22 11:46:51',NULL,'2026-07-22 11:47:46','2026-07-29 11:38:18',0,'2026-07-23 11:11:05','',0,13,'2026-07-22 11:38:18','2026-07-28 11:26:57',NULL),
(38,'BA-2026-703167','عاجل استغلال غير قانوني ','عاجل استغلال غير قانوني ',46,113,'urgent','closed',13,57,'zeralda plage',36.7098180,2.8440860,'','','',48,9,8,65,1,'2026-07-22 11:53:50','2026-07-22 11:51:20','2026-07-22 11:53:50',NULL,NULL,'2026-07-29 11:51:20',0,'2026-07-23 11:08:47',' | Clôturé: ',0,24,'2026-07-22 11:51:20','2026-07-27 12:49:14',NULL),
(40,'BA-2026-870446','Route degradée Zeralda','Rue principale endommagée',44,108,'high','resolved',13,57,'Rue principale Zeralda',NULL,NULL,'Test','0555711111','citizen_apc_zeralda@test.com',67,9,7,70,71,'2026-07-22 12:30:53','2026-07-22 12:30:27','2026-07-22 12:30:53',NULL,NULL,'2026-07-29 12:30:27',0,'2026-07-23 11:10:54','',0,6,'2026-07-22 12:30:27','2026-07-23 11:10:54',NULL),
(41,'BA-2026-454232','Route degradée Zeralda','Rue principale endommagée',44,108,'high','resolved',13,57,'Rue principale Zeralda',NULL,NULL,'Test','0555711111','citizen_apc_zeralda@test.com',67,9,7,66,66,'2026-07-22 12:31:35','2026-07-22 12:31:35',NULL,NULL,NULL,'2026-07-29 12:31:35',0,'2026-07-23 11:10:41','',0,8,'2026-07-22 12:31:35','2026-07-26 13:05:23',NULL),
(42,'BA-2026-995263','Test final','Test',44,108,'high','resolved',13,57,'Zeralda',NULL,NULL,'Test','0555711111','citizen_apc_zeralda@test.com',67,9,7,70,1,'2026-07-22 12:37:12','2026-07-22 12:32:11','2026-07-22 12:37:12',NULL,NULL,'2026-07-29 12:32:11',0,'2026-07-23 11:10:33','',0,6,'2026-07-22 12:32:11','2026-07-26 13:13:14',NULL),
(43,'BA-2026-413825','Route degradée Zeralda','Rue principale endommagée',44,108,'high','rejected',13,57,'Rue principale Zeralda',NULL,NULL,'Test','0555711111','citizen_apc_zeralda@test.com',67,9,4,70,1,'2026-07-23 11:08:10','2026-07-22 12:32:39','2026-07-23 11:08:10',NULL,NULL,'2026-07-29 12:32:39',0,NULL,NULL,0,8,'2026-07-22 12:32:39','2026-07-23 11:08:16',NULL),
(44,'BA-2026-036363','Route degradée Zeralda','Rue endommagée',44,108,'high','resolved',13,57,'Zeralda',NULL,NULL,'Test','0555711111','citizen_apc_zeralda@test.com',67,9,7,70,71,'2026-07-22 12:34:22','2026-07-22 12:33:57','2026-07-22 12:34:22',NULL,NULL,'2026-07-29 12:33:57',0,'2026-07-23 11:10:25','',0,9,'2026-07-22 12:33:57','2026-07-23 11:10:25',NULL),
(45,'BA-2026-671311','Route degradée Zeralda','Rue endommagée',44,108,'high','resolved',13,57,'Zeralda',NULL,NULL,'Test','0555711111','citizen_apc_zeralda@test.com',67,9,7,68,69,'2026-07-22 13:13:44','2026-07-22 12:35:16','2026-07-22 12:36:42','2026-07-22 13:13:22','2026-07-22 13:13:44','2026-07-29 12:35:16',0,'2026-07-23 11:10:12','',0,17,'2026-07-22 12:35:16','2026-07-23 11:10:12',NULL),
(46,'BA-2026-790931','انسداد بالوعة ','انسداد بالوعة ',9,19,'urgent','closed',1,2,'3 HORLOGE',36.7910440,3.0530410,'','','',1,2,7,5,3,'2026-07-22 13:14:34','2026-07-22 13:11:45',NULL,'2026-07-22 13:13:03','2026-07-22 13:14:34','2026-08-01 13:11:45',0,'2026-07-29 15:00:59',' | ',0,47,'2026-07-22 13:11:45','2026-07-29 15:01:10',NULL),
(47,'BA-2026-949108','عدم الصيانة بعد الانتهاء من الاشغال','عدم الصيانة بعد الانتهاء من الاشغال',16,39,'medium','validated',1,2,'Alger',36.7853040,3.0573750,'adem','0698140634','damdouma2015.hay@gmail.com',45,2,7,5,3,'2026-07-26 13:24:24','2026-07-26 13:19:27','2026-07-26 13:22:26','2026-07-26 13:23:22','2026-07-26 13:24:24','2026-08-05 12:19:27',0,'2026-07-26 13:25:32','',0,75,'2026-07-26 13:19:27','2026-07-29 14:55:21',NULL),
(48,'BA-2026-308430','Android test ','Android test',7,13,'high','closed',1,3,'alger',36.7858820,3.0428610,'Android test','0798200171','',73,2,7,2,10,'2026-07-26 14:45:40','2026-07-26 14:40:15','2026-07-26 14:45:40',NULL,NULL,'2026-08-05 13:40:15',0,NULL,' |  |  |  |  |  | ',0,46,'2026-07-26 14:40:15','2026-07-27 17:10:31',NULL),
(49,'BA-2026-883633','dechet dans city vert','cc',1,1,'medium','submitted',6,24,'city vert ouladfayet',36.7144160,2.9545200,'','','',1,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-03 16:13:59',0,NULL,NULL,0,3,'2026-07-27 17:13:59','2026-07-28 13:45:19',NULL),
(50,'BA-2026-722710','absence des bacs','absence des bacs',3,6,'medium','submitted',6,24,'city vert ouladfayet',36.7144160,2.9545200,'huawie','','',75,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-03 16:21:21',0,NULL,NULL,0,16,'2026-07-27 17:21:21','2026-07-29 09:15:10',NULL),
(51,'BA-2026-566906','نفايات عشوائية','نن',1,1,'high','closed',1,1,'Alger',36.7908330,3.0534920,'','','',45,2,8,13,3,'2026-07-29 12:38:19','2026-07-29 12:36:07','2026-07-29 12:36:49','2026-07-29 12:37:30','2026-07-29 12:38:19','2026-08-05 11:34:37',0,'2026-07-29 12:42:27',' | Clôturé: ',0,29,'2026-07-29 12:34:37','2026-07-29 15:02:35',NULL),
(52,'BA-2026-352767','Rahy mkhalta ','d',7,13,'high','validated',1,2,'boufrizi',36.7861640,3.0390070,'Bouzareah App','0798200171','bouzareahapp@gmail.com',78,2,7,4,3,'2026-07-29 15:10:01','2026-07-29 15:05:21','2026-07-29 15:08:44','2026-07-29 15:09:35','2026-07-29 15:10:01','2026-08-08 14:05:21',0,'2026-07-29 15:11:10','',0,29,'2026-07-29 15:05:21','2026-07-29 15:17:59',NULL),
(53,'BA-2026-917563','نفايات صلبة ','تأخر في رفع النفايات الصلبة ',7,14,'urgent','acknowledged',1,2,'باب الواد',36.7907490,3.0532910,'Adem','0798200171','adem@gmail.com',79,2,1,10,10,'2026-07-30 06:30:00','2026-07-30 06:30:00',NULL,NULL,NULL,'2026-08-09 05:30:00',0,NULL,NULL,0,8,'2026-07-30 06:30:00','2026-07-30 08:10:11',NULL),
(54,'BA-2026-256470','نفايات صلبة ','تأخر في رفع النفايات الصلبة ',7,14,'urgent','acknowledged',1,2,'باب الواد',36.7907490,3.0532910,'Adem','0798200171','adem@gmail.com',79,2,1,10,10,'2026-07-30 06:30:02','2026-07-30 06:30:02',NULL,NULL,NULL,'2026-08-09 05:30:02',0,NULL,NULL,0,2,'2026-07-30 06:30:02','2026-07-30 06:48:09','2026-07-30 06:48:09'),
(55,'BA-2026-370991','نفايات صلبة ','تأخر في رفع النفايات الصلبة ',7,14,'urgent','acknowledged',1,2,'باب الواد',36.7907490,3.0532910,'Adem','0798200171','adem@gmail.com',79,2,1,10,10,'2026-07-30 06:30:04','2026-07-30 06:30:04',NULL,NULL,NULL,'2026-08-09 05:30:04',0,NULL,NULL,0,2,'2026-07-30 06:30:04','2026-07-30 06:48:06','2026-07-30 06:48:06'),
(56,'BA-2026-970973','نفايات صلبة ','تأخر في رفع النفايات الصلبة ',7,14,'urgent','acknowledged',1,2,'باب الواد',36.7907490,3.0532910,'Adem','0798200171','adem@gmail.com',79,2,1,10,10,'2026-07-30 06:30:13','2026-07-30 06:30:13',NULL,NULL,NULL,'2026-08-09 05:30:13',0,NULL,NULL,0,1,'2026-07-30 06:30:13','2026-07-30 06:48:01','2026-07-30 06:48:01'),
(57,'BA-2026-635118','نفايات صلبة ','تأخر في رفع النفايات الصلبة ',7,14,'urgent','acknowledged',1,2,'باب الواد',36.7907490,3.0532910,'Adem','0798200171','adem@gmail.com',79,2,1,10,10,'2026-07-30 06:30:15','2026-07-30 06:30:15',NULL,NULL,NULL,'2026-08-09 05:30:15',0,NULL,NULL,0,4,'2026-07-30 06:30:15','2026-07-30 06:47:57','2026-07-30 06:47:57'),
(58,'BA-2026-151501','نفايات صلبة ','تأخر في رفع النفايات الصلبة ',7,14,'urgent','acknowledged',1,2,'باب الواد',36.7907490,3.0532910,'Adem','0798200171','adem@gmail.com',79,2,1,10,10,'2026-07-30 06:30:15','2026-07-30 06:30:15',NULL,NULL,NULL,'2026-08-09 05:30:15',0,NULL,NULL,0,4,'2026-07-30 06:30:15','2026-07-30 06:47:53','2026-07-30 06:47:53');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(2,1),
(3,1),
(4,1),
(5,1),
(6,1),
(7,1),
(1,2),
(5,2),
(6,2),
(7,2),
(2,3),
(3,3),
(4,3),
(5,3),
(6,3),
(7,3),
(6,4),
(3,5),
(4,5),
(5,5),
(6,5),
(7,5),
(2,6),
(3,6),
(4,6),
(5,6),
(6,6),
(7,6),
(1,7),
(2,7),
(3,7),
(4,7),
(5,7),
(6,7),
(7,7),
(3,8),
(4,8),
(5,8),
(6,8),
(7,8),
(3,9),
(4,9),
(5,9),
(6,9),
(7,9),
(1,10),
(2,10),
(6,10),
(3,11),
(4,11),
(5,11),
(6,11),
(7,11),
(3,12),
(4,12),
(5,12),
(6,12),
(7,12),
(3,13),
(4,13),
(5,13),
(6,13),
(7,13),
(3,14),
(4,14),
(5,14),
(6,14),
(7,14),
(5,15),
(6,15),
(7,15),
(3,16),
(4,16),
(5,16),
(6,16),
(7,16),
(6,17),
(5,18),
(6,18),
(7,18),
(6,19),
(3,20),
(4,20),
(5,20),
(6,20),
(7,20),
(5,21),
(6,21),
(7,21),
(3,22),
(4,22),
(5,22),
(6,22),
(7,22),
(6,23),
(1,24),
(2,24),
(3,24),
(4,24),
(5,24),
(6,24),
(7,24),
(2,25),
(3,25),
(4,25),
(5,25),
(6,25),
(7,25),
(5,26),
(6,26),
(7,26),
(6,27),
(5,28),
(6,28),
(7,28),
(1,29),
(2,29),
(3,29),
(4,29),
(5,29),
(6,29),
(7,29),
(3,30),
(4,30),
(5,30),
(6,30),
(7,30),
(4,31),
(5,31),
(6,31),
(7,31),
(4,32),
(5,32),
(6,32),
(7,32),
(4,33),
(5,33),
(6,33),
(7,33),
(4,34),
(5,34),
(6,34),
(7,34),
(7,43);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `label` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'citizen','Citoyen','Citoyen utilisant la plateforme',1,1,'2026-07-15 14:01:35','2026-07-15 14:01:35'),
(2,'intervenant','Intervenant','Agent technique chargé du traitement',3,1,'2026-07-15 14:01:35','2026-07-19 09:48:11'),
(3,'chef_section','Chef de Section','Chef d une section',4,1,'2026-07-15 14:01:35','2026-07-19 09:48:11'),
(4,'chef_unite','Chef d Unité','Chef d une unité',5,1,'2026-07-15 14:01:35','2026-07-19 09:48:11'),
(5,'admin_local','Administrateur Local','Administrateur d un organisme',6,1,'2026-07-15 14:01:35','2026-07-19 09:48:11'),
(6,'admin_central','Administrateur Central','Administrateur central Wilaya Alger',7,1,'2026-07-15 14:01:35','2026-07-19 09:48:11'),
(7,'resp_central','Responsable Central',NULL,6,1,'2026-07-16 09:16:55','2026-07-16 11:04:06');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `section_communes`
--

DROP TABLE IF EXISTS `section_communes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_communes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT 'Chef de Section user',
  `commune_id` bigint(20) unsigned NOT NULL COMMENT 'Commune assigned to this chef_section',
  `organization_id` bigint(20) unsigned NOT NULL COMMENT 'Organization context',
  `daira_id` bigint(20) unsigned NOT NULL COMMENT 'Daira context',
  `assigned_by` bigint(20) unsigned NOT NULL COMMENT 'Chef d unite who assigned',
  `assigned_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`user_id`,`commune_id`),
  KEY `idx_org_daira` (`organization_id`,`daira_id`),
  KEY `commune_id` (`commune_id`),
  KEY `daira_id` (`daira_id`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `section_communes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `section_communes_ibfk_2` FOREIGN KEY (`commune_id`) REFERENCES `communes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `section_communes_ibfk_3` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `section_communes_ibfk_4` FOREIGN KEY (`daira_id`) REFERENCES `dairas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `section_communes_ibfk_5` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_communes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `section_communes` WRITE;
/*!40000 ALTER TABLE `section_communes` DISABLE KEYS */;
INSERT INTO `section_communes` VALUES
(1,3,1,2,1,2,'2026-07-19 10:06:16'),
(2,3,2,2,1,2,'2026-07-19 10:06:16'),
(4,12,4,2,1,2,'2026-07-19 10:06:16'),
(5,16,32,10,7,1,'2026-07-19 10:34:53'),
(7,16,28,10,7,15,'2026-07-20 09:50:34'),
(8,3,3,2,1,11,'2026-07-21 08:02:57'),
(9,59,56,2,13,60,'2026-07-29 15:07:33');
/*!40000 ALTER TABLE `section_communes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_last_activity` (`last_activity`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL DEFAULT 'general',
  `key_name` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `type` enum('text','textarea','number','boolean','json','image') NOT NULL DEFAULT 'text',
  `label` varchar(150) NOT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_key` (`group_name`,`key_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'general','app_name','Balagh Alger','text','Nom de l application',1,'2026-07-15 14:04:16','2026-07-15 14:04:16'),
(2,'general','app_name_ar','بلاغ الجزائر','text','Nom arabe',1,'2026-07-15 14:04:16','2026-07-15 14:04:16'),
(3,'general','app_version','2.0.0','text','Version',1,'2026-07-15 14:04:16','2026-07-27 18:18:53'),
(4,'general','contact_email','contact@balagh-alger.dz','text','Email de contact',1,'2026-07-15 14:04:16','2026-07-15 14:04:16'),
(5,'general','contact_phone','021 00 00 00','text','Téléphone de contact',1,'2026-07-15 14:04:16','2026-07-15 14:04:16'),
(6,'general','wilaya_name','Wilaya d Alger','text','Nom de la Wilaya',1,'2026-07-15 14:04:16','2026-07-15 14:04:16'),
(7,'general','privacy_policy','Politique de confidentialité - Balagh Alger','textarea','Politique de confidentialité',0,'2026-07-15 14:04:16','2026-07-15 14:04:16'),
(8,'landing','hero_image','https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=900&q=80','image','Image hero showcase',1,'2026-07-20 15:05:05','2026-07-20 15:05:05'),
(9,'landing','facebook_url','https://facebook.com','text','Facebook URL',1,'2026-07-20 15:05:05','2026-07-30 07:35:41'),
(10,'landing','twitter_url','https://facebook.com','text','Twitter URL',1,'2026-07-20 15:05:05','2026-07-30 07:35:41'),
(11,'landing','instagram_url','https://facebook.com','text','Instagram URL',1,'2026-07-20 15:05:05','2026-07-30 07:35:41'),
(12,'landing','youtube_url','https://facebook.com','text','YouTube URL',1,'2026-07-20 15:05:05','2026-07-30 07:35:41');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sla_alerts`
--

DROP TABLE IF EXISTS `sla_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sla_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `alert_type` enum('j2','j1','overdue') NOT NULL,
  `sent_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sla_once` (`report_id`,`alert_type`),
  KEY `idx_report_id` (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla_alerts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sla_alerts` WRITE;
/*!40000 ALTER TABLE `sla_alerts` DISABLE KEYS */;
INSERT INTO `sla_alerts` VALUES
(1,7,'overdue','2026-07-27 15:16:17'),
(2,12,'overdue','2026-07-27 15:16:17'),
(3,15,'overdue','2026-07-27 15:16:17'),
(4,16,'overdue','2026-07-27 15:16:17'),
(5,21,'overdue','2026-07-27 15:16:17'),
(6,1,'overdue','2026-07-27 15:16:17'),
(7,4,'overdue','2026-07-27 15:16:17'),
(8,17,'overdue','2026-07-27 15:16:17'),
(9,18,'overdue','2026-07-27 15:16:17');
/*!40000 ALTER TABLE `sla_alerts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcategories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cat_slug` (`category_id`,`slug`),
  CONSTRAINT `subcategories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `subcategories` WRITE;
/*!40000 ALTER TABLE `subcategories` DISABLE KEYS */;
INSERT INTO `subcategories` VALUES
(1,1,'مخلفات عشوائية','مخلفات عشوائية','makhalfat-eishwiya',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(2,1,'تأخر في رفع النفايات','تأخر في رفع النفايات','takhar-rif-nifayat',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(3,2,'نقص في عملية الكنس','نقص في عملية الكنس','naqs-amaliyat-kans',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(4,3,'غياب الحاويات','غياب الحاويات','ghiyab-alhawiyat',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(5,3,'نقص في الحاويات','نقص في الحاويات','naqs-alhawiyat',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(6,3,'إهتراء الحاويات','إهتراء الحاويات','ihtira-alhawiyat',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(7,4,'إهتراء السلة','إهتراء السلة','ihi-tira-alsilla',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(8,4,'غياب السلة','غياب السلة','ghiyab-alsilla',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(9,4,'نقص في السلات','نقص في السلات','naqs-alsalat',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(10,5,'أعشاب بحرية','أعشاب بحرية','ashab-bahariya',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(11,6,'مخلفات عشوائية','مخلفات عشوائية','makhalfat-khadraa',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(12,6,'تأخر في رفع النفايات','تأخر في رفع النفايات','takhar-khadraa',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(13,7,'مخلفات عشوائية','مخلفات عشوائية','makhalfat-saliba',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(14,7,'تأخر في رفع النفايات','تأخر في رفع النفايات','takhar-saliba',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(15,8,'مخلفات عشوائية','مخلفات عشوائية','makhalfat-mukhtalita',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(16,8,'تأخر في رفع النفايات','تأخر في رفع النفايات','takhar-mukhtalita',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(17,9,'مسدودة','مسدودة','masduda',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(18,9,'بدون غطاء','بدون غطاء','bidun-ghataya',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(19,9,'محطمة','محطمة','muhatama',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(20,10,'تسرب من الشبكة','تسرب من الشبكة','tasarrub-min-shabaka',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(21,11,'مجمع مياه الصرف الصحي','مجمع مياه الصرف الصحي','majmi-miyah-sayf',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(22,11,'مجمع مياه الصرف ومياه الأمطار','مجمع مياه الصرف ومياه الأمطار','majmi-miyah-amtar',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(23,11,'مجمع مياه الصرف للمسبح','مجمع مياه الصرف للمسبح','majmi-miyah-masbah',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(24,11,'تسرب الصرف الصحي الفردي','تسرب الصرف الصحي الفردي','tasarrub-sayf-fardi',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(25,11,'مجمع محطة الرفع','مجمع محطة الرفع','majmi-mahatta-rafa',NULL,1,5,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(26,12,'غياب الغطاء','غياب الغطاء','ghiyab-ghataya',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(27,12,'مهترئة','مهترئة','muhtari-a',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(28,12,'مسدودة','مسدودة','masduda-qanat',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(29,13,'المتدفق','المتدفق','almutadafiq',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(30,13,'غير المتدفق','غير المتدفق','ghayr-almutadafiq',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(31,14,'مياه راكدة','مياه راكدة','miyah-rakida',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(32,15,'حفرة في الرصيف','حفرة في الرصيف','hafra-rasif',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(33,15,'إهتراء','إهتراء','ihtira-rasif',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(34,15,'عدم صيانة بعد الأشغال','عدم صيانة بعد الأشغال','adam-siyana-bad-ashghal',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(35,15,'نقص في طلاء حواف الرصيف','نقص في طلاء حواف الرصيف','naqs-talaa-hawaf',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(36,15,'نقص في غسل الرصيف','نقص في غسل الرصيف','naqs-ghasl-rasif',NULL,1,5,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(37,16,'حفرة في الطريق','حفرة في الطريق','hafra-tarik',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(38,16,'إهتراء','إهتراء','ihtira-tarik',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(39,16,'عدم صيانة بعد إنتهاء الأشغال','عدم صيانة بعد إنتهاء الأشغال','adam-siyana-tarik',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(40,17,'نقص في الطلاء','نقص في الطلاء','naqs-talaa-isam',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(41,17,'حاجز مهترئ','حاجز مهترئ','hajiz-muhtari',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(42,17,'غياب الحواجز','غياب الحواجز','ghiyab-hawajiz-isam',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(43,18,'غطاء القبو محطم','غطاء القبو محطم','ghataya-alqabu-muhatam',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(44,18,'غياب الغطاء','غياب الغطاء','ghiyab-ghataya-aslak',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(45,18,'بروز الأسلاك','بروز الأسلاك','buruz-aslak-hatif',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(46,19,'مصابيح محطمة','مصابيح محطمة','masabih-muhatama',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(47,19,'مصابيح معطلة','مصابيح معطلة','masabih-muattala',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(48,19,'عمود إنارة مهترئ','عمود إنارة مهترئ','amud-inara-muhtari',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(49,19,'عمود إنارة آيل للسقوط','عمود إنارة آيل للسقوط','amud-inara-ail',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(50,19,'غياب الإنارة','غياب الإنارة','ghiyab-alinara',NULL,1,5,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(51,19,'نقص في طلاء عمود الإنارة','نقص في طلاء عمود الإنارة','naqs-talaa-amud',NULL,1,6,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(52,19,'بروز أسلاك الكهرباء من عمود الإنارة','بروز أسلاك الكهرباء من عمود الإنارة','buruz-aslak-amud',NULL,1,7,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(53,20,'ساعة معطلة','ساعة معطلة','saa-muattala',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(54,20,'ساعة مهترئة','ساعة مهترئة','saa-muhtari-a',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(55,21,'ساعة معطلة','ساعة معطلة','saa-amma-muattala',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(56,21,'ساعة مهترئة','ساعة مهترئة','saa-amma-muhtari',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(57,22,'عمود آيل للسقوط','عمود آيل للسقوط','amud-ail-kahraba',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(58,22,'بروز الأسلاك','بروز الأسلاك','buruz-aslak-kahraba',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(59,22,'عمود مهترئ','عمود مهترئ','amud-muhtari-kahraba',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(60,23,'نقص في العناية','نقص في العناية','naqs-enaya-fadaa',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(61,23,'نقص في الري','نقص في الري','naqs-ri-fadaa',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(62,23,'نقص في تقليم الأشجار','نقص في تقليم الأشجار','naqs-taqleem-ashjar',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(63,24,'نقص في تقليم الأشجار','نقص في تقليم الأشجار','naqs-taqleem-ashjar2',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(64,24,'غياب دواعم الأشجار','غياب دواعم الأشجار','ghiyab-dawaam',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(65,24,'شجرة آيلة للسقوط','شجرة آيلة للسقوط','shajara-aila',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(66,24,'نقص في تجيير جذوع الأشجار','نقص في تجيير جذوع الأشجار','naqs-tajir-judhu',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(67,24,'تجيير غير مطابق للمعايير','تجيير غير مطابق للمعايير','tajir-ghayr-mutabiq',NULL,1,5,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(68,25,'وجود حشائش ضارة','وجود حشائش ضارة','wujud-hashash',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(69,26,'إنهيار صخري','إنهيار صخري','inihar-sakhri2',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(70,27,'زحف الرمال','زحف الرمال','zahaf-arlamal2',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(71,28,'إنجراف التربة','إنجراف التربة','injiraf-alturba2',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(72,29,'نقص في العناية بالمنحدرات','نقص في العناية بالمنحدرات','naqs-enaya-manahid',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(73,30,'لوحة محطمة','لوحة محطمة','lawha-muhatama',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(74,30,'لوحة آيلة للسقوط','لوحة آيلة للسقوط','lawha-aila',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(75,30,'محجوب عن الرؤية','محجوب عن الرؤية','mahjub-ruya',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(76,31,'نقص في الطلاء','نقص في الطلاء','naqs-talaa-isharat',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(77,32,'تحطم الواقية','تحطم الواقية','tahattum-alwakiya',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(78,32,'غياب الواقية','غياب الواقية','ghiyab-alwakiya',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(79,32,'غياب لافتة إسم الموقف','غياب لافتة إسم الموقف','ghiyab-lafit',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(80,32,'وجود كتابات على الواقية','وجود كتابات على الواقية','wujud-kitabat',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(81,33,'نقص في الطلاء','نقص في الطلاء','naqs-talaa-hadid',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(82,33,'غياب الحواجز','غياب الحواجز','ghiyab-hawajiz-hadid',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(83,33,'حاجز مهترئ','حاجز مهترئ','hajiz-muhtari-hadid',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(84,34,'تحطم جزء من الجسر','تحطم جزء من الجسر','tahattum-juz-jasr',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(85,34,'إهتراء أرضية الجسر','إهتراء أرضية الجسر','ihtira-ardh-jasr',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(86,34,'إهتراء الدرج','إهتراء الدرج','ihtira-udruj',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(87,34,'إهتراء حاجز الحماية','إهتراء حاجز الحماية','ihtira-hajiz-himaya',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(88,35,'غياب اللافتة','غياب اللافتة','ghiyab-lafita-madkhal',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(89,35,'غير مهيأ','غير مهيأ','ghayr-muhaa',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(90,35,'لافتة مهترئة','لافتة مهترئة','lafita-muhtari',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(91,36,'إعاقة المرور','إعاقة المرور','iaqat-almarur',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(92,37,'محطة مهترئة','محطة مهترئة','mahatta-muhtari',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(93,38,'موقف مهترئ','موقف مهترئ','mauqif-muhtari',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(94,39,'أشغال مهملة','أشغال مهملة','ashghal-muhmala',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(95,40,'غياب الراية','غياب الراية','ghiyab-alriya',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(96,40,'راية ممزقة','راية ممزقة','riya-mumazzaqa',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(97,40,'عمود الراية مهترئ','عمود الراية مهترئ','amud-riya-muhtari',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(98,40,'عمود الراية آيل للسقوط','عمود الراية آيل للسقوط','amud-riya-ail',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(99,41,'نافورة معطلة','نافورة معطلة','nafura-muattala',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(100,41,'نافورة متسخة','نافورة متسخة','nafura-mutakhkha',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(101,41,'تسرب مياه النافورة','تسرب مياه النافورة','tasarrub-nafura',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(102,42,'الحماية المدنية','الحماية المدنية','himaya-madaniya',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(103,42,'الشرطة','الشرطة','shurta',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(104,42,'المتصرف','المتصرف','mutasarrif',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(105,42,'الدرك الوطني','الدرك الوطني','dark-watani',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(106,42,'مرحاض','مرحاض','mirhad',NULL,1,5,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(107,43,'نافورة عمومية معطلة','نافورة عمومية معطلة','nafura-amma-muattala',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(108,44,'بدون لوحة ترقيم','بدون لوحة ترقيم','bidun-lawha',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(109,44,'بلوحة ترقيم','بلوحة ترقيم','bilawha',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(110,45,'حواجز','حواجز','hawajiz-tarik',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(111,45,'بيع العشوائي للخضر والفواكه','بيع العشوائي للخضر والفواكه','bay-eishwi-khudar',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(112,45,'إستحواذ غير قانوني (تمديد البناية)','إستحواذ غير قانوني (تمديد البناية)','istihdid-ghayr-qanuni',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(113,46,'المظلات والكراسي','المظلات والكراسي','mazallat-kerasi',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(114,46,'مواقف السيارات','مواقف السيارات','mawaqif-sayarat-shati',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(115,47,'جدار آيل للسقوط','جدار آيل للسقوط','jidar-ail',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(116,47,'شرفة منزل آيلة للسقوط','شرفة منزل آيلة للسقوط','sharfa-manzil-aila',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(117,47,'جدار مهترئ','جدار مهترئ','jidar-muhtari',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(118,47,'كتابات على الجدران','كتابات على الجدران','kitabat-jidran',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(119,47,'نقص في الطلاء','نقص في الطلاء','naqs-talaa-wajihat',NULL,1,5,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(120,48,'بناية مهدمة','بناية مهدمة','binaya-muhadama2',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(121,49,'مصعد مهترئ','مصعد مهترئ','masad-muhtari',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(122,49,'مصعد معطل','مصعد معطل','masad-muattal',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(123,50,'ملعب مهترئ','ملعب مهترئ','malab-muhtari',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(124,51,'وجود بيوت قصديرية','وجود بيوت قصديرية','wujud-buyut-qasdir',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(125,52,'اهتراء العاب الأطفال','اهتراء العاب الأطفال','ihtira-alab-atfal',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(126,53,'قبو مهترئ','قبو مهترئ','qabu-muhtari',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(127,53,'غياب الغطاء','غياب الغطاء','ghiyab-ghataya-qabu',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(128,54,'منصبة','منصبة','mansuba',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(129,54,'غير منصبة','غير منصبة','ghayr-mansuba',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(130,55,'مهترئة','مهترئة','muhtari-salalim',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(131,55,'نقص في الغسل','نقص في الغسل','naqs-ghasl-salalim',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(132,56,'دعامة مهترئة','دعامة مهترئة','ddaama-muhtari',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(133,57,'غياب','غياب','ghiyab-lafita-ishh',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(134,57,'كتابة غير واضحة','كتابة غير واضحة','kitaba-ghayr-wadha',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(135,58,'شاطئ قذر','شاطئ قذر','shati-azir',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(136,58,'كورنيش متضرر','كورنيش متضرر','kurnish-mudawar',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(137,58,'مخلفات عشوائية على الشاطئ','مخلفات عشوائية على الشاطئ','makhalfat-shati',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(138,58,'حيوان ضال على الشاطئ','حيوان ضال على الشاطئ','hayawan-dal-shati',NULL,1,4,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(139,59,'كلاب','كلاب','kilab',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(140,59,'قطط','قطط','qitat',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(141,59,'خنازير','خنازير','khnazir',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(142,60,'وجود قوارب صيد','وجود قوارب صيد','wujud-qawarib',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(143,61,'قبر محطم','قبر محطم','qabr-muhatam',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(144,62,'إنسداد الأنابيب الإسمنتية','إنسداد الأنابيب الإسمنتية','insidad-anabib-isam',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(145,62,'الصب المباشر لمياه الوادي','الصب المباشر لمياه الوادي','sab-mubashar-awdiya',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(146,63,'صب مياه الينابيع','صب مياه الينابيع','sab-miyah-yanabi',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(147,64,'مهترئ','مهترئ','muhtari-mrashshat',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(148,65,'عمود آيل للسقوط','عمود آيل للسقوط','amud-ail-hatif',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(149,65,'بروز الأسلاك','بروز الأسلاك','buruz-aslak-hatif2',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(150,65,'عمود مهترئ','عمود مهترئ','amud-muhtari-hatif',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(151,66,'صخرة متدلية','صخرة متدلية','sakhra-mutadalla',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(152,67,'حفرة في الطريق السريع','حفرة في الطريق السريع','hafra-tarik-sari',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(153,68,'مقبرة قذرة','مقبرة قذرة','maqbara-azra',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(154,68,'سياج مقبرة متضرر','سياج مقبرة متضرر','siyaj-maqbara',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(155,68,'صيانة ضرورية','صيانة ضرورية','siyana-daruriya',NULL,1,3,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(156,69,'غياب','غياب','ghiyab-khazan',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(157,69,'مهترئ','مهترئ','muhtari-khazan',NULL,1,2,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(158,70,'أخرى','أخرى','ukhra-gen',NULL,1,1,'2026-07-22 10:34:10','2026-07-22 10:50:32'),
(162,12,'غياب الغطاء','غياب الغطاء','ghiyab-ghataya2',NULL,1,1,'2026-07-22 10:36:04','2026-07-22 10:50:32');
/*!40000 ALTER TABLE `subcategories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_badges`
--

DROP TABLE IF EXISTS `user_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `badge_key` varchar(50) NOT NULL,
  `badge_name` varchar(100) NOT NULL,
  `badge_icon` varchar(50) DEFAULT 'fa-trophy',
  `badge_color` varchar(20) DEFAULT '#f59e0b',
  `earned_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_badge` (`user_id`,`badge_key`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_badges`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_badges` WRITE;
/*!40000 ALTER TABLE `user_badges` DISABLE KEYS */;
INSERT INTO `user_badges` VALUES
(1,1,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-23 12:08:33'),
(2,1,'first_resolved','Résolution','fa-check-circle','#22c55e','2026-07-23 12:08:33'),
(3,48,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-23 12:08:47'),
(4,48,'first_resolved','Résolution','fa-check-circle','#22c55e','2026-07-23 12:08:47'),
(5,45,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-23 12:09:46'),
(6,45,'first_resolved','Résolution','fa-check-circle','#22c55e','2026-07-23 12:09:46'),
(7,67,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-23 12:10:12'),
(8,67,'first_resolved','Résolution','fa-check-circle','#22c55e','2026-07-23 12:10:12'),
(17,67,'resolved_5','Impact local','fa-award','#3b82f6','2026-07-23 12:10:54'),
(24,73,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-26 16:40:15'),
(26,1,'report_5','5 signalements','fa-fire','#ef4444','2026-07-27 19:13:59'),
(28,75,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-27 19:21:21'),
(30,45,'report_5','5 signalements','fa-fire','#ef4444','2026-07-29 14:34:37'),
(35,9,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-29 14:42:40'),
(36,9,'first_resolved','Résolution','fa-check-circle','#22c55e','2026-07-29 14:42:40'),
(40,78,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-29 17:05:21'),
(41,79,'first_report','Premier signalement','fa-star','#f59e0b','2026-07-30 08:30:00'),
(46,79,'report_5','5 signalements','fa-fire','#ef4444','2026-07-30 08:30:15');
/*!40000 ALTER TABLE `user_badges` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `assigned_by` bigint(20) unsigned DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES
(1,6,NULL,'2026-07-15 14:03:36'),
(2,4,1,'2026-07-15 14:03:36'),
(3,3,1,'2026-07-15 14:03:36'),
(4,2,1,'2026-07-15 14:03:36'),
(5,2,1,'2026-07-15 14:03:36'),
(6,1,NULL,'2026-07-15 14:14:29'),
(7,1,NULL,'2026-07-15 15:00:40'),
(8,1,NULL,'2026-07-15 15:00:53'),
(9,5,1,'2026-07-20 09:48:07'),
(10,7,1,'2026-07-19 09:34:50'),
(11,4,NULL,'2026-07-16 09:30:50'),
(12,3,NULL,'2026-07-16 09:30:50'),
(13,2,NULL,'2026-07-16 09:30:50'),
(14,7,NULL,'2026-07-16 09:30:50'),
(15,4,NULL,'2026-07-16 09:30:50'),
(16,3,NULL,'2026-07-16 09:30:50'),
(17,2,NULL,'2026-07-16 09:30:50'),
(18,7,NULL,'2026-07-16 09:30:50'),
(19,4,NULL,'2026-07-16 09:30:50'),
(20,2,NULL,'2026-07-16 09:30:50'),
(21,7,NULL,'2026-07-16 09:30:50'),
(22,2,NULL,'2026-07-16 09:30:50'),
(43,1,NULL,'2026-07-16 11:49:30'),
(44,1,NULL,'2026-07-19 10:14:28'),
(45,1,NULL,'2026-07-19 10:23:14'),
(46,5,1,'2026-07-20 09:45:52'),
(47,1,NULL,'2026-07-21 07:58:08'),
(48,1,NULL,'2026-07-21 11:43:25'),
(49,1,NULL,'2026-07-21 13:11:22'),
(50,1,1,'2026-07-22 10:11:58'),
(51,1,1,'2026-07-28 12:27:02'),
(57,1,NULL,'2026-07-22 11:43:37'),
(58,2,NULL,'2026-07-22 11:43:37'),
(59,3,NULL,'2026-07-22 11:43:37'),
(60,4,NULL,'2026-07-22 11:43:37'),
(61,7,NULL,'2026-07-22 11:43:37'),
(62,1,NULL,'2026-07-22 11:45:04'),
(63,2,NULL,'2026-07-22 11:45:04'),
(64,3,NULL,'2026-07-22 11:45:04'),
(65,4,NULL,'2026-07-22 11:45:04'),
(66,7,NULL,'2026-07-22 11:45:04'),
(67,1,NULL,'2026-07-22 11:46:01'),
(68,2,NULL,'2026-07-22 11:46:01'),
(69,3,NULL,'2026-07-22 11:46:01'),
(70,4,NULL,'2026-07-22 11:46:01'),
(71,7,NULL,'2026-07-22 11:46:01'),
(72,1,NULL,'2026-07-23 11:47:00'),
(73,1,NULL,'2026-07-26 14:37:45'),
(74,1,NULL,'2026-07-27 12:34:46'),
(75,1,NULL,'2026-07-27 17:17:00'),
(76,1,NULL,'2026-07-28 10:30:42'),
(77,1,NULL,'2026-07-28 12:28:12'),
(78,1,NULL,'2026-07-29 15:03:06'),
(79,1,NULL,'2026-07-30 06:25:56');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT 'default.png',
  `status` enum('active','inactive','suspended','pending') NOT NULL DEFAULT 'pending',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `login_attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `daira_id` bigint(20) unsigned DEFAULT NULL,
  `commune_id` bigint(20) unsigned DEFAULT NULL,
  `section` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`),
  KEY `daira_id` (`daira_id`),
  KEY `commune_id` (`commune_id`),
  KEY `idx_status` (`status`),
  KEY `idx_org` (`organization_id`),
  KEY `idx_users_status_daira` (`status`,`daira_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`daira_id`) REFERENCES `dairas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_ibfk_3` FOREIGN KEY (`commune_id`) REFERENCES `communes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11','Admin','Central','admin@balagh-alger.dz','0555000001','$2y$12$r5y.H8aoFkg4CRRK2vraneLuxk4fetpjlGXY8aMQMk3.tPZBWi5Ee','/uploads/avatars/avatar_1_1785242114.png','active','2026-07-15 14:03:36','2026-07-30 08:11:11',0,NULL,NULL,NULL,NULL,NULL,'2026-07-15 14:03:36','2026-07-30 08:11:11',NULL),
(2,'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a12','Mohamed','Ben Ali','mohamed@balagh-alger.dz','0555000002','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-15 14:03:36','2026-07-20 09:57:13',0,NULL,2,1,NULL,NULL,'2026-07-15 14:03:36','2026-07-20 09:57:13',NULL),
(3,'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380a13','Fatima','Boudiaf','fatima@balagh-alger.dz','0555000003','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-15 14:03:36','2026-07-29 15:13:40',0,NULL,2,1,NULL,NULL,'2026-07-15 14:03:36','2026-07-29 15:13:40',NULL),
(4,'d0eebc99-9c0b-4ef8-bb6d-6bb9bd380a14','Karim','Zeroual','karim@balagh-alger.dz','0555000004','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-15 14:03:36','2026-07-29 15:10:22',0,NULL,2,1,NULL,'Technique','2026-07-15 14:03:36','2026-07-29 15:10:22',NULL),
(5,'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380a15','Amina','Hadj','amina@balagh-alger.dz','0555000005','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-15 14:03:36','2026-07-29 12:39:37',0,NULL,2,1,NULL,NULL,'2026-07-15 14:03:36','2026-07-29 12:39:37',NULL),
(6,'b6750e31-a9c8-4661-8c03-4fb98d855d47','adem','hezil','usaplay1406@gmail.com','0798200171','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-15 14:14:29','2026-07-19 10:06:49',0,NULL,NULL,NULL,NULL,NULL,'2026-07-15 14:14:29','2026-07-19 10:06:49',NULL),
(7,'4021fc24-f2f5-408e-8ebc-8fa05e758f15','adem','hezil','heziladem@gmail.com','','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-15 15:00:40','2026-07-15 15:00:46',0,NULL,NULL,NULL,NULL,NULL,'2026-07-15 15:00:40','2026-07-19 09:53:16',NULL),
(8,'f7107af6-9ec2-4a42-929c-2de7934d12f1','abdou','cellule','technique.motos@gmail.com','065389969','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-15 15:00:53','2026-07-15 15:01:11',0,NULL,NULL,NULL,NULL,NULL,'2026-07-15 15:00:53','2026-07-19 09:53:16',NULL),
(9,'3809ffa7-dbce-47f2-a9f8-aedaa663dd11','test','test','test@test.com','0798200171','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-16 08:40:43','2026-07-29 12:46:55',0,NULL,2,1,NULL,NULL,'2026-07-16 08:40:43','2026-07-29 12:46:55',NULL),
(10,'6fd93090-6196-4338-bfd3-5a9280740d8e','Ahmed','Benmalek','resp.asrouter@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,'2026-07-29 15:13:04',0,NULL,2,1,NULL,NULL,'2026-07-16 09:30:50','2026-07-29 15:13:04',NULL),
(11,'cfad5176-f881-4a68-b7a4-78ff7c8dc2f6','Karim','Mansouri','chef.asr.bo@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,'2026-07-29 15:15:15',0,NULL,2,1,NULL,NULL,'2026-07-16 09:30:50','2026-07-29 15:15:15',NULL),
(12,'25b3b3e0-c052-4e2e-878b-c17562e55f50','Sofiane','Aitahmed','chefsec.asr.bo@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,'2026-07-20 13:06:20',0,NULL,2,1,NULL,'Technique','2026-07-16 09:30:50','2026-07-20 13:06:20',NULL),
(13,'1ac253ac-87f3-49dc-9f68-c2ca2cc55521','Youcef','Bouzidi','agent.asr.bo@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,'2026-07-29 14:53:49',0,NULL,2,1,NULL,'Technique','2026-07-16 09:30:50','2026-07-29 14:53:49',NULL),
(14,'72f78461-9890-44a5-829d-9b1d8fd19e87','Rachid','Hamidi','resp.dtp@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,10,7,NULL,NULL,'2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(15,'7618f622-7f7d-4726-bae5-58b70709986e','Nabil','Farhat','chef.dtp.baraki@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,'2026-07-20 09:49:26',0,NULL,10,7,NULL,NULL,'2026-07-16 09:30:50','2026-07-20 09:49:26',NULL),
(16,'1f1cd4b3-b4ab-4bb8-864c-3d89f718b63a','Omar','Slimani','chefsec.dtp.baraki@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,10,7,NULL,'Voirie','2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(17,'43838eb5-764f-4dfd-a46d-3e6f742ed44d','Amine','Kaci','agent.dtp.baraki@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,10,7,NULL,'Voirie','2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(18,'1d985330-55bd-4282-be9b-39b36fa3ca96','Brahim','Zeroual','resp.sonelgaz@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,8,10,NULL,NULL,'2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(19,'e27123d5-2f13-48ec-ac33-b51f1cb7155c','Samir','Aouiz','chef.son.bmr@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,8,10,NULL,NULL,'2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(20,'f1c602cf-d825-460e-a98f-465059e8bf1b','Riyad','Benmoussa','agent.son.bmr@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,8,10,NULL,'Eclairage','2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(21,'d789d4ff-1b99-45d0-9151-4e8263f7939e','Djamel','Bensaid','resp.seaal@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,7,8,NULL,NULL,'2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(22,'82bb2707-9dcc-40de-8047-35d0da25a97a','Tarek','Mebarki','agent.seaal.bir@balagh-alger.dz',NULL,'$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active',NULL,NULL,0,NULL,7,8,NULL,'Eau','2026-07-16 09:30:50','2026-07-19 09:53:16',NULL),
(43,'4cb36150-e7f3-43bf-95d7-f9de516ee800','Cellule','motocycles','babelouedapp@gmail.com','0656389969','$2y$12$aIVgeXnsg2VKgE1VPGiYoOW6.H1sZ5oYMy7m9pkpp.GWLOO9cxa82','default.png','active','2026-07-16 11:49:30','2026-07-16 11:49:48',0,NULL,NULL,NULL,NULL,NULL,'2026-07-16 11:49:30','2026-07-19 09:53:16',NULL),
(44,'f1c8265d-5bcd-4426-bc14-8f450888a57e','adem','hezil','x@gmail.com','0798200171','$2y$12$vByzWJ2gTqVAcUNNv703DeIvtvLptQZPJ4tJIBgPP8TOYTFoPMj0W','default.png','active','2026-07-19 10:14:28','2026-07-19 10:22:32',0,NULL,NULL,NULL,NULL,NULL,'2026-07-19 10:14:28','2026-07-19 10:22:32',NULL),
(45,'d743009a-835b-11f1-ba0b-080027c70393','Test','Citizen','citizen@test.com','0555 11 22 33','$2y$12$xyGY9OlIcUfxDj2VvXAuVeR3jplrOBBUnEnV8x93V4e09ldqoRPuq','/uploads/avatars/avatar_45_1784730451.png','active',NULL,'2026-07-30 07:10:48',0,NULL,NULL,10,52,NULL,'2026-07-19 10:23:10','2026-07-30 07:10:48',NULL),
(46,'8bbc4264-e2ac-4332-8ab1-b9a3477a2517','admin local','local ','adminlocal@balagh-alger.dz','0558953455','$2y$12$K1fW3Ll3Zgc76UmYaFXtO.5Q7A6DtY1z3fvjbATyET6p4qqtdKYUK','default.png','active',NULL,'2026-07-26 15:02:17',0,NULL,2,1,NULL,NULL,'2026-07-20 09:44:34','2026-07-26 15:02:17',NULL),
(47,'0c5f1dc5-2551-447f-bd43-223050ad618a','moh','dodo','dodo@gmail.com','0798200191','$2y$12$492biK3hljeAjiBg0N/IOOqHjktzAu3oO1cxry6N0gUQ3IM8lsjLm','default.png','active','2026-07-21 07:58:08','2026-07-29 12:47:39',0,NULL,NULL,NULL,NULL,NULL,'2026-07-21 07:58:08','2026-07-29 12:47:39',NULL),
(48,'60571199-e16a-4d24-9f14-8d45da3d0db0','mohamed','babouche','babou@balagh-alger.dz','0698140634','$2y$12$jLew1iktWyB1kIW7w56fu.BxR83KI7ksRSq8t5AyecQF7lOn3sGWu','default.png','active','2026-07-21 11:43:25','2026-07-23 11:17:13',0,NULL,NULL,NULL,NULL,NULL,'2026-07-21 11:43:25','2026-07-23 11:17:13',NULL),
(49,'4b2edaaa-d37d-4c4b-90c2-625433e7d1a4','ali','berkani','ali@balagh-alger.dz','0798200171','$2y$12$nFHlrvYRWT6bDp6wcdnnqOTYNqmAj4swe26UdNF6RrCANu4nvuXJO','default.png','active','2026-07-21 13:11:22','2026-07-21 13:11:29',0,NULL,NULL,NULL,NULL,NULL,'2026-07-21 13:11:22','2026-07-21 13:11:29',NULL),
(50,'195a1524-a86e-4d09-9bed-5500f01e82be','hamza','chb','hamzachabane292@gmail.com','0542926620','$2y$12$0wUFzkrdWZhmaLk.rAZwzOPMyfXUFef5bKtGrWbG1dmbGEDnE/oZ.','default.png','active','2026-07-22 10:08:17',NULL,5,'2026-07-22 10:26:04',NULL,NULL,NULL,NULL,'2026-07-22 10:08:17','2026-07-22 10:11:04',NULL),
(51,'35ccf48d-2853-4d4f-b008-db37f5d2f144','hamza','chb','hamza123@gmail.com','0542926620','$2y$12$LABj6/l995F9uiDV5zzwEuCoDsqKLEzNagKMXI56bnHy/rdnuzSbe','/uploads/avatars/avatar_51_1784732488.jpg','active','2026-07-22 10:14:04','2026-07-23 15:31:13',0,NULL,NULL,NULL,NULL,NULL,'2026-07-22 10:14:04','2026-07-23 15:31:13',NULL),
(57,'91492133-85c2-11f1-8ecb-080027c70393','أحمد','بن عمر','citizen_zeralda@test.com','0555123456','$2y$12$ZdcR6Aq6rKqrBD6AwsLw6OzBS7dQ4KiwIcDxyFbCnZ7.tiu0s1L52','default.png','active',NULL,NULL,0,NULL,NULL,13,57,NULL,'2026-07-22 11:43:37','2026-07-22 11:43:37',NULL),
(58,'914a3582-85c2-11f1-8ecb-080027c70393','كريم','بوزيد','agent_zeralda@test.com','0555234567','$2y$12$ZdcR6Aq6rKqrBD6AwsLw6OzBS7dQ4KiwIcDxyFbCnZ7.tiu0s1L52','default.png','active',NULL,NULL,0,NULL,2,13,57,NULL,'2026-07-22 11:43:37','2026-07-22 11:43:37',NULL),
(59,'914aad17-85c2-11f1-8ecb-080027c70393','فاطمة','الحسناوي','chef_section_zeralda@test.com','0555345678','$2y$12$ZdcR6Aq6rKqrBD6AwsLw6OzBS7dQ4KiwIcDxyFbCnZ7.tiu0s1L52','default.png','active',NULL,NULL,0,NULL,2,13,57,'voirie','2026-07-22 11:43:37','2026-07-22 11:43:37',NULL),
(60,'914aff10-85c2-11f1-8ecb-080027c70393','محمد','بن صالح','chef_unite_zeralda@test.com','0555456789','$2y$12$ZdcR6Aq6rKqrBD6AwsLw6OzBS7dQ4KiwIcDxyFbCnZ7.tiu0s1L52','default.png','active',NULL,'2026-07-29 15:07:19',0,NULL,2,13,57,NULL,'2026-07-22 11:43:37','2026-07-29 15:07:19',NULL),
(61,'914d9783-85c2-11f1-8ecb-080027c70393','عبد الرحمن','مقراني','resp_zeralda@test.com','0555567890','$2y$12$ZdcR6Aq6rKqrBD6AwsLw6OzBS7dQ4KiwIcDxyFbCnZ7.tiu0s1L52','default.png','active',NULL,NULL,0,NULL,2,13,57,NULL,'2026-07-22 11:43:37','2026-07-22 11:43:37',NULL),
(62,'c52adc25-85c2-11f1-8ecb-080027c70393','نور الدين','مراد','citizen_apc@test.com','0555611111','$2y$12$XyV9TEta8wwceMy/2KG/Pu1RpV2rPAc2TD.3GgFVuy76JMgtWbrOO','default.png','active',NULL,NULL,0,NULL,NULL,1,1,NULL,'2026-07-22 11:45:04','2026-07-22 11:45:04',NULL),
(63,'c52c0cc4-85c2-11f1-8ecb-080027c70393','سامي','بلقاسم','agent_apc@test.com','0555622222','$2y$12$XyV9TEta8wwceMy/2KG/Pu1RpV2rPAc2TD.3GgFVuy76JMgtWbrOO','default.png','active',NULL,'2026-07-22 12:05:18',0,NULL,9,1,1,NULL,'2026-07-22 11:45:04','2026-07-22 12:05:18',NULL),
(64,'c52c452d-85c2-11f1-8ecb-080027c70393','ليلى','بوزيد','chef_section_apc@test.com','0555633333','$2y$12$XyV9TEta8wwceMy/2KG/Pu1RpV2rPAc2TD.3GgFVuy76JMgtWbrOO','default.png','active',NULL,NULL,0,NULL,9,1,1,'proprete','2026-07-22 11:45:04','2026-07-22 11:45:04',NULL),
(65,'c52c7c37-85c2-11f1-8ecb-080027c70393','عمار','الهاشمي','chef_unite_apc@test.com','0555644444','$2y$12$XyV9TEta8wwceMy/2KG/Pu1RpV2rPAc2TD.3GgFVuy76JMgtWbrOO','default.png','active',NULL,'2026-07-22 12:24:46',0,NULL,9,1,1,NULL,'2026-07-22 11:45:04','2026-07-22 12:24:46',NULL),
(66,'c52cd10c-85c2-11f1-8ecb-080027c70393','رشيد','تيموشت','resp_apc@test.com','0555655555','$2y$12$XyV9TEta8wwceMy/2KG/Pu1RpV2rPAc2TD.3GgFVuy76JMgtWbrOO','default.png','active',NULL,'2026-07-22 11:52:05',0,NULL,9,1,1,NULL,'2026-07-22 11:45:04','2026-07-22 11:52:05',NULL),
(67,'e719f62c-85c2-11f1-8ecb-080027c70393','هبة الله','شرفي','citizen_apc_zeralda@test.com','0555711111','$2y$12$O4aMcXXacO0xVSEsEDD1MezW7KBABNGLf37V5KLUW/lSPwF2yntXC','default.png','active',NULL,'2026-07-22 13:32:11',0,NULL,NULL,13,57,NULL,'2026-07-22 11:46:01','2026-07-22 13:32:11',NULL),
(68,'e71cd5ed-85c2-11f1-8ecb-080027c70393','يوسف','гадيري','agent_apc_zeralda@test.com','0555722222','$2y$12$O4aMcXXacO0xVSEsEDD1MezW7KBABNGLf37V5KLUW/lSPwF2yntXC','default.png','active',NULL,'2026-07-22 13:16:55',0,NULL,9,13,57,NULL,'2026-07-22 11:46:01','2026-07-22 13:16:55',NULL),
(69,'e71d8b25-85c2-11f1-8ecb-080027c70393','منى','بوعلام','chef_section_apc_zeralda@test.com','0555733333','$2y$12$O4aMcXXacO0xVSEsEDD1MezW7KBABNGLf37V5KLUW/lSPwF2yntXC','default.png','active',NULL,'2026-07-22 13:17:06',0,NULL,9,13,57,'proprete','2026-07-22 11:46:01','2026-07-22 13:17:06',NULL),
(70,'e71dbe1d-85c2-11f1-8ecb-080027c70393','نabil','korichi','chef_unite_apc_zeralda@test.com','0555744444','$2y$12$O4aMcXXacO0xVSEsEDD1MezW7KBABNGLf37V5KLUW/lSPwF2yntXC','default.png','active',NULL,'2026-07-22 13:19:11',0,NULL,9,13,57,NULL,'2026-07-22 11:46:01','2026-07-22 13:19:11',NULL),
(71,'e71f5501-85c2-11f1-8ecb-080027c70393','طارق','بن ديبي','resp_apc_zeralda@test.com','0555755555','$2y$12$O4aMcXXacO0xVSEsEDD1MezW7KBABNGLf37V5KLUW/lSPwF2yntXC','default.png','active',NULL,'2026-07-22 13:12:32',0,NULL,9,13,57,NULL,'2026-07-22 11:46:01','2026-07-22 13:12:32',NULL),
(72,'8e48e3ec-59fd-4782-8577-d1dc64ac64db','Test','Citoyen','testcitizen2@test.com',NULL,'$2y$12$ngcgWRiz5XPUC/T6OehUSeUv310mObVFphvjRUbtukJqlJsN25hy6','default.png','active','2026-07-23 11:47:00','2026-07-23 12:24:27',0,NULL,NULL,NULL,NULL,NULL,'2026-07-23 11:47:00','2026-07-23 12:24:27',NULL),
(73,'1a4653b1-ac20-4b8f-8e53-f78c7fb310b7','Android','test','k@gmail.com','0785403321','$2y$12$bP7upb4zWrCa7qsmvTvKgeMgpy3VFcyahvvES2BcH/ZzZAdcLMIK.','default.png','active','2026-07-26 14:37:45','2026-07-26 14:38:07',0,NULL,NULL,NULL,NULL,NULL,'2026-07-26 14:37:45','2026-07-26 14:38:07',NULL),
(74,'8523d167-bc6f-41be-9dbb-ab765f0391a4','ZAP','ZAP','zaproxy@example.com','9999999999','$2y$12$IbbLagSMFm1qbN2Eh6JdAOnyTnUae/HyaDQeX1HjruJ7mgfNd2tKi','default.png','active','2026-07-27 12:34:46',NULL,5,'2026-07-27 12:49:49',NULL,NULL,NULL,NULL,'2026-07-27 12:34:46','2026-07-27 12:34:49',NULL),
(75,'4d5287bb-7cfa-4d55-85ba-8fb3c5c990d8','huawie','ademoo','yahiadex1406@gmail.com','0698140634','$2y$12$al99shj1eWQuWkJgJ2.5zup0A9Z6sVHuKfCu56Xjz5hKwuodq4ZQO','/uploads/avatars/avatar_75_1785172691.webp','active','2026-07-27 17:17:00','2026-07-27 17:28:22',0,NULL,NULL,NULL,NULL,NULL,'2026-07-27 17:17:00','2026-07-27 17:28:22',NULL),
(76,'5087e25c-6108-45f1-b629-f138a8a10adb','abdou','abdou','abdou@gmail.com','0656389969','$2y$12$QeYdVX1vIuY7PcKsHCMJOei8iYeN6b/Vn2hRuSu83/TVhJi082mKu','default.png','active','2026-07-28 10:30:42','2026-07-28 10:30:50',0,NULL,NULL,NULL,NULL,NULL,'2026-07-28 10:30:42','2026-07-28 10:30:50',NULL),
(77,'18da1352-8e32-4df1-bdd0-880037fcacee','d','d','d@gmail.com','0656389969','$2y$12$An756GW3WCTK.JIkyT1m7uSDuUz/VV8g7pZYmirRFJ6hjPEhUrMR6','default.png','active','2026-07-28 12:28:12','2026-07-28 12:28:28',0,NULL,NULL,NULL,NULL,NULL,'2026-07-28 12:28:12','2026-07-28 13:10:24','2026-07-28 13:10:24'),
(78,'d9ce26eb-5e78-417a-a1d7-432c2ac26e59','akrem','cellule','bouzareahapp@gmail.com','0798200171','$2y$12$eR7xNZISqCd05wBk2Jyf7uzxBailgxq6P028fBOjKIWcXy4uYp3P2','/uploads/avatars/avatar_78_1785337556.png','active','2026-07-29 15:03:06','2026-07-29 15:16:00',0,NULL,NULL,NULL,NULL,NULL,'2026-07-29 15:03:06','2026-07-29 15:16:00',NULL),
(79,'0ff08f52-1580-43c6-a776-900f81f480ef','Adem','Realme','adem@gmail.com','+213 550213126','$2y$12$V3bFG/mpvdtI8PzXCkqqZeUYu2AYVOx8n8M.WWCJQLqe5o3xP34C6','default.png','active','2026-07-30 06:25:56','2026-07-30 07:40:16',0,NULL,NULL,NULL,NULL,NULL,'2026-07-30 06:25:56','2026-07-30 07:40:16',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-07-30 10:18:43
